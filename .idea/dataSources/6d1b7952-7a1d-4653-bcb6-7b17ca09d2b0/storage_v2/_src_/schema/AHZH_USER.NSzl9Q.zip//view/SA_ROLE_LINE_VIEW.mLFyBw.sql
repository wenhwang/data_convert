create view SA_ROLE_LINE_VIEW as
    select srl.sa_role_line_id,
           srl.sa_role_head_id,
           srl.dept_id,
           2 monthn,
           srl.feb_amount amount
      from sa_role_line srl
    union all
    select srl.sa_role_line_id,
           srl.sa_role_head_id,
           srl.dept_id,
           3 monthn,
           srl.mar_amount
      from sa_role_line srl
    union all
    select srl.sa_role_line_id,
           srl.sa_role_head_id,
           srl.dept_id,
           4 monthn,
           srl.apr_amount
      from sa_role_line srl
    union all
    select srl.sa_role_line_id,
           srl.sa_role_head_id,
           srl.dept_id,
           5 monthn,
           srl.may_amount
      from sa_role_line srl
    union all
    select srl.sa_role_line_id,
           srl.sa_role_head_id,
           srl.dept_id,
           6 monthn,
           srl.jun_amount
      from sa_role_line srl
    union all
    select srl.sa_role_line_id,
           srl.sa_role_head_id,
           srl.dept_id,
           7 monthn,
           srl.jul_amount
      from sa_role_line srl
    union all
    select srl.sa_role_line_id,
           srl.sa_role_head_id,
           srl.dept_id,
           8 monthn,
           srl.aug_amount
      from sa_role_line srl
    union all
    select srl.sa_role_line_id,
           srl.sa_role_head_id,
           srl.dept_id,
           9 monthn,
           srl.sep_amount
      from sa_role_line srl
    union all
    select srl.sa_role_line_id,
           srl.sa_role_head_id,
           srl.dept_id,
           10 monthn,
           srl.oct_amount
      from sa_role_line srl
    union all
    select srl.sa_role_line_id,
           srl.sa_role_head_id,
           srl.dept_id,
           11 monthn,
           srl.nov_amount
      from sa_role_line srl
    union all
    select srl.sa_role_line_id,
           srl.sa_role_head_id,
           srl.dept_id,
           12 monthn,
           srl.dec_amount
      from sa_role_line srl
    union all
    select srl.sa_role_line_id,
           srl.sa_role_head_id,
           srl.dept_id,
           1 monthn,
           srl.next_jan_amount
      from sa_role_line srl
/

