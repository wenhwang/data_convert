create view VIEW_GL_CREDENCELINE as
select Km_Property,
       case
         when a.amount_debit_f > 0 then
          a.amount_debit_f
         when a.amount_credit_f < 0 and KM_PROPERTY = 1 then
          - (a.amount_credit_f)
         when KM_PROPERTY = 2 and a.amount_credit_f < 0 then
          - (a.amount_credit_f)
         else
          0
       end as amount_debit_f,
       case
         when a.amount_debit > 0 then
          a.amount_debit
         when a.amount_credit < 0 and KM_PROPERTY = 1 then
          - (a.amount_credit)
         when KM_PROPERTY = 2 and a.amount_credit < 0 then
          - (a.amount_credit)
         else
          0
       end as amount_debit,
       case
         when a.amount_credit_f > 0 then
          amount_credit_f
         when KM_PROPERTY = 2 and a.amount_debit_f < 0 then
          - (amount_debit_f)
         when KM_PROPERTY = 1 and a.amount_debit_f < 0 then
          - (a.amount_debit_f)
         else
          0
       end As amount_credit_f,
       case
         when a.amount_credit > 0 then
          amount_credit
         when KM_PROPERTY = 2 and a.amount_debit < 0 then
          - (amount_debit)
         when KM_PROPERTY = 1 and a.amount_debit < 0 then
          - (a.amount_debit)
         else
          0
       end As amount_credit,
       a.gl_credence_head_id,
       a.customer_id,
       a.vendor_id,
       a.dept_id,
       a.employee_id,
       a.base_project_id,
       a.item_id,
       a.gl_account_subject_id,
       a.base_ac_object_id,
       c.set_of_books_id,
       c.organization_id,
       c.year_month,
       c.credence_date,
       b.base_currency_id,
       c.tally_flag
  from gl_credence_line a, gl_credence_head c,gl_account_subject b
 where a.gl_credence_head_id = c.gl_credence_head_id and
       a.gl_account_subject_id = b.gl_account_subject_id
/

