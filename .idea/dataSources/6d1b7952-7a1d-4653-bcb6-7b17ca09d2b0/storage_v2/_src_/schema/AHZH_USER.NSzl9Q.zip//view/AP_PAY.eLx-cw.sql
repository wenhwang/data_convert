create view AP_PAY as
select fb.organization_id,
       fb.date_fund,
       fb.year_month,
       fb.Vendor_Id,
       fb.amount_debit,
       fb.is_credence,
       fb.credence_no,
       fb.exch_rate,
       fb.base_currency_id,
       fb.is_auditing,
       fb.amount_credit,
       fb.is_ap_fund,
       fb.bill_no,
       fb.record_type,
       fb.crm_entid,
       fb.entorgid
  from fd_fund_business fb
 where fb.Is_Ap_Fund= 2 and fb.record_type = 3
/

