create view CPCUSEROPINION_V as
    Select Wfid,
       Procid,
       Userid,
       Freq,
       Positionid,
       Isagent,
       Stat,
       Signtime,
       Opinion,
       Accopinion,
       Duetime,
       Period,
       Pstatime,
       Toprocid,
       Procchgflag,
       Rowid Row_Id
From   Cpcuseropinion
Union
Select Wfid,
       Procid,
       Userid,
       Freq,
       Positionid,
       Isagent,
       Stat,
       Signtime,
       Opinion,
       Accopinion,
       Duetime,
       Period,
       Pstatime,
       Toprocid,
       Procchgflag,
       Rowid Row_Id
From   Cpcuseropinionh
/

