create PROCEDURE PRO_DINGREMIND_RETURNED_MONEY(ADVANCE_DAYS  INTEGER, --提前天数
                                                          INTERVAL_DAYS INTEGER --间隔天数
                                                          ) IS
  --计数
  V_COUNT_NUM INTEGER;

  --接收人
  V_RECIPIENT   VARCHAR(512); --钉钉USERID
  V_RECIPIENTID VARCHAR(512);

  --提醒内容游标
  CURSOR V_REMINDS IS
    SELECT '4001' BILL_TYPE_CODE,
           '合伙人回款' BILL_TYPE_NAME,
           ORGANIZATION_ID,
           PAYMENT_NO BILL_NO,
           '合伙人回款提醒' BILL_NAME,
           
           SIGNER,
           
           CUSTOMER_ADD || SIGNER || ',协议《' || SALE_COMPACT_NUM || '》,' ||
           '签约金额:' || TOTAL_AMOUNT || '元,' || '已回款:' ||
           (SELECT SUM(PLAN_PAY_AMOUNT - UN_PAYMENT_AMOUNT)
              FROM SA_KACONTRACT_BILL_LINE LINE
             WHERE HEAD.SA_KACONTRACT_BILL_HEAD_ID =
                   LINE.SA_KACONTRACT_BILL_HEAD_ID) || '元;预计回款日期:' ||
           TO_CHAR(PLAN_PAY_TIME, 'YYYY-MM-DD') || ',预计回款金额:' ||
           UN_PAYMENT_AMOUNT MESSAGE,
           
           PLAN_PAY_TIME,
           CEIL(PLAN_PAY_TIME - SYSDATE) TIME_DIFFERENCE, --时间差
           
           TRUNC(SYSDATE - 1) + 33 / 24 SENDING_TIME, --默认第二天上午9点    
           0 SENDING_STAT,
           NULL SENDING_RESULT
      FROM SA_KACONTRACT_BILL_LINE LINE, SA_KACONTRACT_BILL_HEAD HEAD
     WHERE HEAD.SA_KACONTRACT_BILL_HEAD_ID =
           LINE.SA_KACONTRACT_BILL_HEAD_ID
       AND CONTRACT_STATUS = '签约'
       AND NVL(PAYMENT_STATUS, 0) <> 2 --未回款
       AND CEIL(PLAN_PAY_TIME - SYSDATE) <= ADVANCE_DAYS;

BEGIN

  --1、周六、周日不提醒
  V_COUNT_NUM := 0;
  SELECT COUNT(1)
    INTO V_COUNT_NUM
    FROM DUAL
   WHERE TRIM(TO_CHAR(SYSDATE, 'DAY', 'NLS_DATE_LANGUAGE=AMERICAN')) IN
         ('SATURDAY', 'SUNDAY');
  IF (V_COUNT_NUM > 0) THEN
    RETURN;
  END IF;

  --2.产生提醒内容
  FOR REMIND IN V_REMINDS LOOP
    BEGIN
      --2.1判断间隔时间
      V_COUNT_NUM := 0;
      SELECT NVL(CEIL(SYSDATE -
                      (SELECT MAX(HEAD.SENDING_TIME)
                         FROM DINGTALK_REMIND HEAD
                        WHERE HEAD.BILL_TYPE_CODE = '4001'
                          AND HEAD.BILL_NO = REMIND.BILL_NO)),
                 0)
        INTO V_COUNT_NUM
        FROM DUAL;
    
      --间隔天数小于指定天数,退出循环
      IF (V_COUNT_NUM < INTERVAL_DAYS) AND (V_COUNT_NUM <> 0) THEN
        CONTINUE;
      END IF;
    
      --2.2提取提醒对象
      SELECT WMSYS.WM_CONCAT(RECIPIENT), WMSYS.WM_CONCAT(RECIPIENTID)
        INTO V_RECIPIENT, V_RECIPIENTID
        FROM (SELECT DISTINCT 'DIFFAREAVAT' RECIPIENT_TYPE,
                              USERID RECIPIENT,
                              HEAD.DINGTALK_USERID RECIPIENTID
                FROM EMPLOYEE_HEADER HEAD
               WHERE HEAD.USERID = REMIND.SIGNER --业务员
                  OR HEAD.USERID IN
                     (SELECT USERID
                        FROM CPCORGPOSITION, CPCUSER
                       WHERE CPCORGPOSITION.SYSUSERID = CPCUSER.SYSUSERID
                         AND POSITIONID IN ('销售内勤', '营销总监')))
       GROUP BY RECIPIENT_TYPE;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_RECIPIENT   := '';
        V_RECIPIENTID := '';
    END;
  
    IF (REMIND.TIME_DIFFERENCE < 0) THEN
      REMIND.MESSAGE := REMIND.MESSAGE || ',已逾期,' ||
                        ABS(REMIND.TIME_DIFFERENCE) || '日';
    ELSE
      REMIND.MESSAGE := REMIND.MESSAGE || ',将于' ||
                        ABS(REMIND.TIME_DIFFERENCE) || '日,后到期';
    END IF;
  
    --2.1生成提醒内容
    INSERT INTO DINGTALK_REMIND
      (DINGTALK_REMIND_ID,
       BILL_TYPE_CODE,
       BILL_TYPE_NAME,
       ORGANIZATION_ID,
       BILL_NO,
       BILL_NAME,
       MESSAGE,
       RECIPIENT,
       RECIPIENTID,
       SENDING_TIME,
       SENDING_STAT,
       SENDING_RESULT)
    VALUES
      (SQ_DINGTALK_REMIND_ID.NEXTVAL,
       REMIND.BILL_TYPE_CODE,
       REMIND.BILL_TYPE_NAME,
       REMIND.ORGANIZATION_ID,
       REMIND.BILL_NO,
       REMIND.BILL_NAME,
       REMIND.MESSAGE,
       V_RECIPIENT,
       V_RECIPIENTID,
       REMIND.SENDING_TIME,
       REMIND.SENDING_STAT,
       REMIND.SENDING_RESULT);
    --提交
    COMMIT;
  
  END LOOP;

END;

  /*********************************************\
  * NAME(名称): PRO_DINGREMIND_RETURNED_MONEY
  * PURPOSE(功能说明):  钉钉消息提醒-合伙人回款提醒
                                    通知人:业务负责人、发展中心总监、销售内勤
    PARAMETER(参数):  ADVANCE_DAYS:提前天数
                                 INTERVAL_DAYS:间隔天数
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2019-05-17
  \*********************************************/
/

