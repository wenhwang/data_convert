create FUNCTION FUN_GET_SALE_AREA_CTRL(P_CPCUSERID INTEGER --用户ID
                                                  )
  RETURN SALE_AREA_CTRL_TABLE
  PIPELINED IS
  RESULT SALE_AREA_CTRL_ROW; --定义RESULT为行对象类型

BEGIN

  FOR V_SALE_AREA_CTRL IN (SELECT AREAID, AREACODE, AREANAME
                             FROM CPCAREA
                            WHERE CPCAREA.AREATYPE <= 5 --区域级别:市区及以上
                            START WITH SUPERID IN
                                       (SELECT SALE_AREA_ID
                                          FROM INV_SALEAREA_CTRL
                                         WHERE CPCUSERID = P_CPCUSERID)
                           CONNECT BY PRIOR CPCAREA.AREAID = CPCAREA.SUPERID) LOOP
  
    RESULT := SALE_AREA_CTRL_ROW(V_SALE_AREA_CTRL.AREAID,
                                 V_SALE_AREA_CTRL.AREACODE,
                                 V_SALE_AREA_CTRL.AREANAME);
  
    PIPE ROW(RESULT);
  END LOOP;

  -- 返回数据
  RETURN;

END;

  /*********************************************\
  * NAME(名称): FUN_GET_SALE_DISCOUNT
  * PURPOSE(功能说明):  区域权限控制
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-12-13
  \*********************************************/
/

