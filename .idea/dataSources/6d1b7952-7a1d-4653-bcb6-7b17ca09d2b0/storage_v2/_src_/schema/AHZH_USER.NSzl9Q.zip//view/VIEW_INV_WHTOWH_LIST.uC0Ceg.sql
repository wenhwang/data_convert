create view VIEW_INV_WHTOWH_LIST as
select iwwh.organization_id,
        iwwh.bill_date, iwwl.qty_moved,
        iwwl.price_bill_f, iwwl.amount_bill_f,
        c.customer_code,
        c.customer_name,
        i.item_code,
        i.item_name,
        Wout.Warehouse_Name Warehouse_Name_out,
        Win.Warehouse_Name Warehouse_Name_in
   from inv_whtowh_head iwwh,
        inv_whtowh_line iwwl,
        customer        c,
        item            i,
        Warehouse       Win,
        Warehouse       Wout
  where iwwh.inv_whtowh_head_id = iwwl.inv_whtowh_head_id
    and iwwl.Item_Id = i.Item_Id
    and iwwh.customer_id = c.customer_id
    and iwwl.Warehouse_Id_In = Win.Warehouse_Id(+)
    and iwwl.Warehouse_Id_Out = Wout.Warehouse_Id(+)
/

