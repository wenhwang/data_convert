create TYPE "SALE_AREA_CTRL_ROW" AS OBJECT
(
  AREAID   INTEGER, --区域ID
  AREACODE VARCHAR2(16), --区域编码
  AREANAME VARCHAR2(64) --区域名称
)

/*********************************************\
  * NAME(名称): SALE_AREA_CTRL
  * PURPOSE(功能说明):  区域权限控制类型
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-12-13
  \*********************************************/
/

