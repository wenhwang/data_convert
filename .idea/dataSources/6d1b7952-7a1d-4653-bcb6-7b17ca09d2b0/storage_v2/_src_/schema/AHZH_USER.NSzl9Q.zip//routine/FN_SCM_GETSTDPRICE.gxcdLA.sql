create Function           Fn_Scm_GetSTDPrice(p_Item_Id         Number,
                                              p_Organization_Id Number,
                                              p_Date            Varchar2)
  Return Number Is
  Result Number;

  /*
  获取标准定额成本
  p_Organization_Id  产品组织ID
  p_Item_Id  物料ID
  p_Date
  */
Begin
  declare
    price  Number;
    intcount  Number;
  begin
  price:=0;
  intcount:=0;

   select count(*)
     into intcount
     from SC_STD_RATION_PRICE sc
    where sc.year_month=
       (select max(year_month)
         from SC_STD_RATION_PRICE ssrp
         where ssrp.year_month<=p_Date
         AND ssrp.item_id=p_Item_Id
         and ssrp.Organization_Id=p_Organization_Id
         AND ssrp.PRICE>0)
     AND sc.item_id=p_Item_Id
     and sc.Organization_Id=p_Organization_Id;


  if (intcount is null) or (intcount = 0) then
    price:=0;
  else
   select nvl(sc.price,0)--Decode(sc.price,null,0,sc.price)
     into price
     from SC_STD_RATION_PRICE sc
    where sc.year_month=
       (select max(year_month)
         from SC_STD_RATION_PRICE ssrp
         where ssrp.year_month<=p_Date
         AND ssrp.item_id=p_Item_Id
         and ssrp.Organization_Id=p_Organization_Id
         AND ssrp.PRICE>0)
     AND sc.item_id=p_Item_Id
     and sc.Organization_Id=p_Organization_Id;
  end if;

  Result:=price;


  RETURN NVL(Result, 0);
  exception
    when others then
       rollback;
      -- raise_application_error(-20001,sqlerrm);
  end;
End Fn_Scm_GetSTDPrice;
/

