create view CPCENT_CHECK as
select organization_id,includecompany,entname,SET_OF_BOOKS_ID,SET_OF_BOOKS_NAME
  from cpcent
 where nvl(cpcent.isdisabled,1)<>2
/

