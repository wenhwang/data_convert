create view CRMCUST as
select c.customer_id custid,c.customer_code code ,c.customer_name shortname
,co.organization_id,co.dept_id
from customer c,customer_org co
where c.customer_id=co.customer_id
/

