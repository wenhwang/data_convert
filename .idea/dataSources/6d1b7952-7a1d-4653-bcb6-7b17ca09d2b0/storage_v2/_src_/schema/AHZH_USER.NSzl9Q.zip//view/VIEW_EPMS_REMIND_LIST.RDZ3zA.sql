create view VIEW_EPMS_REMIND_LIST as
    SELECT 101           BILL_TYPE, --员工转正
       EMPLOYEE_ID   BILL_ID,
       EMPLOYEE_CODE BILL_NO,
       1111          OBJTYPEID,
       /*'【' || HEAD.EMPLOYEE_NAME || '】' || '还有<span class=''text-danger''>' ||
                            ROUND(FORMAL_DATE - TRUNC(SYSDATE)) || '</span>天转正' BILL_MSG,*/
       ROUND(FORMAL_DATE - TRUNC(SYSDATE)) reminddate,
       case
         when ROUND(FORMAL_DATE - TRUNC(SYSDATE)) = 0 then
          '【' || HEAD.EMPLOYEE_NAME || '】' ||
          '预计今天转正,最后一次提醒！<span class=''text-danger''>' || '</span>'
         else
          '【' || HEAD.EMPLOYEE_NAME || '】' ||
          '预计还有<span class=''text-danger''>' ||
          ROUND(FORMAL_DATE - TRUNC(SYSDATE)) || '</span>天转正'
       end BILL_MSG
  FROM EMPLOYEE_HEADER HEAD
 WHERE stat=1
   and ROUND(FORMAL_DATE - TRUNC(SYSDATE)) <= 14 --14天以内
   and ROUND(FORMAL_DATE - TRUNC(SYSDATE)) >=0

UNION ALL

SELECT 102            BILL_TYPE, --员工合同预警
       HR_CONTRACT_ID BILL_ID,
       CONTRACT_NO    BILL_NO,
       1111           OBJTYPEID,
       /*'【' || EMPLOYEE.EMPLOYEE_NAME || '】' || '的' ||
              DECODE(CONTRACT_TYPE,
                     1,
                     '劳动合同',
                     2,
                     '竞业协议',
                     3,
                     '保密协议',
                     '其它',
                     9,
                     '') || '还有<span class=''text-danger''>' || ROUND(END_DATE - TRUNC(SYSDATE)) || '</span>天到期' BILL_MSG,*/
       ROUND(END_DATE - TRUNC(SYSDATE)) reminddate,
       case
         when ROUND(END_DATE - TRUNC(SYSDATE)) >= -6 and
              ROUND(END_DATE - TRUNC(SYSDATE)) < 0then
          '【' || EMPLOYEE.EMPLOYEE_NAME || '】' || '的' ||
              DECODE(CONTRACT_TYPE,
                     1,
                     '劳动合同',
                     2,
                     '竞业协议',
                     3,
                     '保密协议',
                     '其它',
                     9,
                     '') || '已到期<span class=''text-danger''>' ||
              -ROUND(END_DATE - TRUNC(SYSDATE)) || '</span>天' when
          ROUND(END_DATE - TRUNC(SYSDATE)) = -7 then
          '【' || EMPLOYEE.EMPLOYEE_NAME || '】' || '的' ||
          DECODE(CONTRACT_TYPE,
                 1,
                 '劳动合同',
                 2,
                 '竞业协议',
                 3,
                 '保密协议',
                 '其它',
                 9,
                 '') || '已到期7天,最后一次提醒！<span class=''text-danger''>' ||
          '</span>'
           when ROUND(END_DATE - TRUNC(SYSDATE)) = 0 then
          '【' || EMPLOYEE.EMPLOYEE_NAME || '】' || '的' ||
          DECODE(CONTRACT_TYPE,
                 1,
                 '劳动合同',
                 2,
                 '竞业协议',
                 3,
                 '保密协议',
                 '其它',
                 9,
                 '') || '明天将过期！<span class=''text-danger''>' ||
          '</span>'
         else
          '【' || EMPLOYEE.EMPLOYEE_NAME || '】' || '的' ||
          DECODE(CONTRACT_TYPE,
                 1,
                 '劳动合同',
                 2,
                 '竞业协议',
                 3,
                 '保密协议',
                 '其它',
                 9,
                 '') || '还有<span class=''text-danger''>' ||
          ROUND(END_DATE - TRUNC(SYSDATE)) || '</span>天到期'
       end BILL_MSG
  FROM HR_CONTRACT HEAD, EMPLOYEE_HEADER EMPLOYEE
 WHERE HEAD.EMPLOYEE_ID = EMPLOYEE.EMPLOYEE_ID(+)
   AND HEAD.CONTRACT_STAT IN (1, 2, 5) --合同状态:1-当前,2-过期,3-解除,4-终止,5-已续签
   AND ROUND(END_DATE - TRUNC(SYSDATE)) <= 30 --30以内
   and ROUND(END_DATE - TRUNC(SYSDATE)) > -8

UNION ALL

SELECT 103           BILL_TYPE, --生日提醒
       EMPLOYEE_ID   BILL_ID,
       EMPLOYEE_CODE BILL_NO,
       1111          OBJTYPEID,
       /*'【' || HEAD.EMPLOYEE_NAME || '】' || '还有<span class=''text-danger''>' ||
                     ROUND((ADD_MONTHS(BIRTHDAY,
                                       (EXTRACT(YEAR FROM SYSDATE) -
                                       EXTRACT(YEAR FROM BIRTHDAY)) * 12) - SYSDATE)) ||
                     '天生日' BILL_MSG,*/
       ROUND(BIRTHDAY - TRUNC(SYSDATE)) reminddate,
       case
         when (ADD_MONTHS(BIRTHDAY,
                          (EXTRACT(YEAR FROM SYSDATE) -
                          EXTRACT(YEAR FROM BIRTHDAY)) * 12) - SYSDATE) = 0 then
          '【' || HEAD.EMPLOYEE_NAME || '】' ||
          '，生日快乐！happy birthday to you！<span class=''text-danger''>' || '</span>'
         else
          '【' || HEAD.EMPLOYEE_NAME || '】' ||
          '还有<span class=''text-danger''>' ||
          ROUND((ADD_MONTHS(BIRTHDAY,
                            (EXTRACT(YEAR FROM SYSDATE) -
                            EXTRACT(YEAR FROM BIRTHDAY)) * 12) - SYSDATE)) ||
          '</span>天生日'
       end BILL_MSG
  FROM EMPLOYEE_HEADER HEAD
 WHERE (ADD_MONTHS(BIRTHDAY,
                   (EXTRACT(YEAR FROM SYSDATE) - EXTRACT(YEAR FROM BIRTHDAY)) * 12) -
       SYSDATE) <= 3 --3天以内
   and (ADD_MONTHS(BIRTHDAY,
                   (EXTRACT(YEAR FROM SYSDATE) - EXTRACT(YEAR FROM BIRTHDAY)) * 12) -
       SYSDATE) >= 0

UNION ALL

SELECT 201                    BILL_TYPE, --外经证
       DIFF_AREA_VAT_APPLY_ID BILL_ID,
       APPLY_BILL_NO          BILL_NO,
       170927                 OBJTYPEID,
       /*'【' || HEAD.APPLY_BILL_NO || '】' || '外经证还有<span class=''text-danger''>' ||
              ROUND(END_DATE - SYSDATE) || '</span>天到期' BILL_MSG,*/
       ROUND(END_DATE - TRUNC(SYSDATE)) reminddate,
       case
         when ROUND(END_DATE - TRUNC(SYSDATE)) >= -6 and
              ROUND(END_DATE - TRUNC(SYSDATE)) < 0 then
          '【' || HEAD.APPLY_BILL_NO || '】' ||
          '外经证已到期<span class=''text-danger''>' || -ROUND(END_DATE - SYSDATE) ||
          '</span>天'
         when ROUND(END_DATE - TRUNC(SYSDATE)) = -7 then
          '【' || HEAD.APPLY_BILL_NO || '】' ||
          '外经证已到期7天,最后一次提醒！<span class=''text-danger''>' || '</span>'
          when ROUND(END_DATE - TRUNC(SYSDATE)) = 0 then
          '【' || HEAD.APPLY_BILL_NO || '】' ||
          '外经证明天将过期！<span class=''text-danger''>' || '</span>'
         else
          '【' || HEAD.APPLY_BILL_NO || '】' ||
          '外经证还有<span class=''text-danger''>' || ROUND(END_DATE - SYSDATE) ||
          '</span>天到期'
       end BILL_MSG
  FROM FD_DIFF_AREA_VAT_APPLY HEAD
 WHERE HEAD.STAT = 5
   AND NVL(IS_PRINT_INVOICE, 0) = 1
   AND ROUND(END_DATE - SYSDATE) <= 30 --一个月
   and ROUND(END_DATE - TRUNC(SYSDATE)) > -8

UNION ALL

SELECT 301                 BILL_TYPE, --公司证照预警
       RESOUCE_ARCHIVES_ID BILL_ID,
       RESOURCE_IDENTIFIER BILL_NO,
       1000270             OBJTYPEID,
       /*'【' || HEAD.RESOURCE_NAME || '】' || '还有<span class=''text-danger''>' ||
              ROUND(EXP_DATE - TRUNC(SYSDATE)) || '</span>天到期' BILL_MSG,*/
       ROUND(EXP_DATE - TRUNC(SYSDATE)) reminddate,
       case
         when ROUND(EXP_DATE - TRUNC(SYSDATE)) >= -6 and
              ROUND(EXP_DATE - TRUNC(SYSDATE)) < 0 then
          '【' || HEAD.RESOURCE_NAME || '】' ||
          '已到期<span class=''text-danger''>' ||
          -ROUND(EXP_DATE - TRUNC(SYSDATE)) || '</span>天'
         when ROUND(EXP_DATE - TRUNC(SYSDATE)) = -7 then
          '【' || HEAD.RESOURCE_NAME || '】' ||
          '已到期7天,最后一次提醒<span class=''text-danger''>' || '</span>'
          when ROUND(EXP_DATE - TRUNC(SYSDATE)) = 0 then
          '【' || HEAD.RESOURCE_NAME || '】' ||
          '明天将过期<span class=''text-danger''>' || '</span>'
         else
          '【' || HEAD.RESOURCE_NAME || '】' ||
          '还有<span class=''text-danger''>' ||
          ROUND(EXP_DATE - TRUNC(SYSDATE)) || '</span>天到期'
       end BILL_MSG
  FROM EPM_RESOUCE_ARCHIVES HEAD
 WHERE RESOUCE_TYPE = 1 --公司证照
   AND ROUND(EXP_DATE - TRUNC(SYSDATE)) <= 60 --两个月以内
   and ROUND(EXP_DATE - TRUNC(SYSDATE)) > -8

UNION ALL

SELECT 302                 BILL_TYPE, --人员证照预警
       RESOUCE_ARCHIVES_ID BILL_ID,
       RESOURCE_IDENTIFIER BILL_NO,
       1111                OBJTYPEID,
       /*'【' || EMPLOYEE.EMPLOYEE_NAME || '】' || '的' || '[' ||
              HEAD.RESOURCE_NAME || ']' || '还有<span class=''text-danger''>' || ROUND(EXP_DATE - SYSDATE) ||
              '</span>天到期' BILL_MSG,*/
       ROUND(EXP_DATE - TRUNC(SYSDATE)) reminddate,
       case
         when ROUND(EXP_DATE - TRUNC(SYSDATE)) >= -6 and
              ROUND(EXP_DATE - TRUNC(SYSDATE)) < 0 then
          '【' || EMPLOYEE.EMPLOYEE_NAME || '】' || '的' || '[' ||
          HEAD.RESOURCE_NAME || ']' || '已到期<span class=''text-danger''>' ||
          -ROUND(EXP_DATE - SYSDATE) || '</span>天'
         when ROUND(EXP_DATE - TRUNC(SYSDATE)) = -7 then
          '【' || EMPLOYEE.EMPLOYEE_NAME || '】' || '的' || '[' ||
          HEAD.RESOURCE_NAME || ']' ||
          '已到期7天,最后一次提醒！<span class=''text-danger''>' || '</span>'
          when ROUND(EXP_DATE - TRUNC(SYSDATE)) = 0 then
          '【' || EMPLOYEE.EMPLOYEE_NAME || '】' || '的' || '[' ||
          HEAD.RESOURCE_NAME || ']' ||
          '明天将过期！<span class=''text-danger''>' || '</span>'
         else
          '【' || EMPLOYEE.EMPLOYEE_NAME || '】' || '的' || '[' ||
          HEAD.RESOURCE_NAME || ']' || '还有<span class=''text-danger''>' ||
          ROUND(EXP_DATE - SYSDATE) || '</span>天到期'
       end BILL_MSG
  FROM EPM_RESOUCE_ARCHIVES HEAD, EMPLOYEE_HEADER EMPLOYEE
 WHERE HEAD.HR_EMPLOYEE_HEAD_ID = EMPLOYEE.EMPLOYEE_ID(+)
   AND RESOUCE_TYPE = 2 --人员证照
   AND ROUND(EXP_DATE - TRUNC(SYSDATE)) <= 60 --两个月以内
   and ROUND(EXP_DATE - TRUNC(SYSDATE)) > -8

UNION ALL

SELECT 303                    BILL_TYPE, --招投标账户
       RESOUCE_ARCHIVES_ID    BILL_ID,
       RESOURCE_ARCHIVES_CODE BILL_NO,
       1111                   OBJTYPEID,
       /*'【' || HEAD.RESOURCE_NAME || '】' || '账号还有<span class=''text-danger''>' ||
                     ROUND(EXP_DATE - SYSDATE) || '</span>天到期' BILL_MSG,*/
       ROUND(EXP_DATE - TRUNC(SYSDATE)) reminddate,
       case
         when ROUND(EXP_DATE - TRUNC(SYSDATE)) >= -6 and
              ROUND(EXP_DATE - TRUNC(SYSDATE)) < 0 then
          '【' || HEAD.RESOURCE_NAME || '】' ||
          '账号已到期<span class=''text-danger''>' || -ROUND(EXP_DATE - SYSDATE) ||
          '</span>天'
         when ROUND(EXP_DATE - TRUNC(SYSDATE)) = -7 then
          '【' || HEAD.RESOURCE_NAME || '】' ||
          '账号已到期7天,最后一次提醒！<span class=''text-danger''>' || '</span>'
          when ROUND(EXP_DATE - TRUNC(SYSDATE)) = 0 then
          '【' || HEAD.RESOURCE_NAME || '】' ||
          '账号明天将过期！<span class=''text-danger''>' || '</span>'
         else
          '【' || HEAD.RESOURCE_NAME || '】' ||
          '账号还有<span class=''text-danger''>' || ROUND(EXP_DATE - SYSDATE) ||
          '</span>天到期'
       end BILL_MSG
  FROM EPM_RESOUCE_ARCHIVES HEAD
 WHERE RESOUCE_TYPE = 5 --招投标账户
   AND ROUND(EXP_DATE - SYSDATE) <= 60 --两个月以内
   and ROUND(EXP_DATE - TRUNC(SYSDATE)) > -8

UNION ALL

SELECT 304                 BILL_TYPE, --内部系统账号预警
       RESOUCE_ARCHIVES_ID BILL_ID,
       RESOURCE_IDENTIFIER BILL_NO,
       1111                OBJTYPEID,
       /*'【' || HEAD.RESOURCE_NAME || '】' || '还有<span class=''text-danger''>' ||
              ROUND(EXP_DATE - TRUNC(SYSDATE)) || '</span>天到期' BILL_MSG,*/
       ROUND(EXP_DATE - TRUNC(SYSDATE)) reminddate,
       case
         when ROUND(EXP_DATE - TRUNC(SYSDATE)) >= -6 and
              ROUND(EXP_DATE - TRUNC(SYSDATE)) < 0 then
          '【' || HEAD.RESOURCE_NAME || '】' ||
          '账号已到期<span class=''text-danger''>' || -ROUND(EXP_DATE - SYSDATE) ||
          '</span>天'
         when ROUND(EXP_DATE - TRUNC(SYSDATE)) = -7 then
          '【' || HEAD.RESOURCE_NAME || '】' ||
          '账号已到期7天,最后一次提醒！<span class=''text-danger''>' || '</span>'
          when ROUND(EXP_DATE - TRUNC(SYSDATE)) = 0 then
          '【' || HEAD.RESOURCE_NAME || '】' ||
          '账号明天将过期！<span class=''text-danger''>' || '</span>'
         else
          '【' || HEAD.RESOURCE_NAME || '】' ||
          '账号还有<span class=''text-danger''>' || ROUND(EXP_DATE - SYSDATE) ||
          '</span>天到期'
       end BILL_MSG
  FROM EPM_RESOUCE_ARCHIVES HEAD
 WHERE RESOUCE_TYPE = 6 --内部系统账户;
 and ROUND(EXP_DATE - TRUNC(SYSDATE)) > -8
/

