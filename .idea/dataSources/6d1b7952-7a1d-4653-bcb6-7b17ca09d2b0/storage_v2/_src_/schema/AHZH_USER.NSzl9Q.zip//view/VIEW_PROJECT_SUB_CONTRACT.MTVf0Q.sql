create view VIEW_PROJECT_SUB_CONTRACT as
SELECT PROJECT_ID, --项目ID
       PROJECT_CONTRACT_CODE, --合同编号
       PROJECT_CONTRACT_NAME, --合同名称
       PROJECT_CONTRACT_CHARACTER, --合同性质(1|项目(总包)合同,2|分包合同,3|维保合同)
       PROJECT_CONTRACT_TYPE, --合同类型(来源词汇值，如：劳务、专业、委托设计等)
       CONTRACT_AMOUNT, --合同金额
       CONTRACT_NUMBER, --合同份数
       INVOICE_TYPE, --开票类型
       CONTRACT_CONTENT, --工程内容
       DECODE(INVOICE_TYPE,
              1,
              '专票-清包工',
              2,
              '专票-劳务派遣',
              3,
              '建筑劳务',
              '') INVOICE_TYPE_NAME,
       TAX_RATE, --税点
       SECOND_PARTY_NAME, -- 乙方
       SECOND_PARTY_LINKMAN, --乙方授权人
       SECOND_PARTY_PHONENO, --乙方联系方式
       SECOND_PARTY_BANK, --乙方开户银行
       SECOND_PARTY_USERNAME, --乙方开户名称
       SECOND_PARTY_ACCOUNT, --乙方开户账号
       APPROACH_TIME, --  乙方进场时间
       SIGNUP_DATE, --签订时间
       SIGNUP_ADDRESS, --签订地址
       FILE_NUMBER, --归档档案号
       PROJECT_MANAGER_ID, --项目经理
       START_TIME, --工期
       ACCEPTANCE_CRITERIA, --验收标准
       GUARANTEE_PERIOD, --质保期
       GUARANTEE_AMOUNT, --质保金
       REMARK --备注
  FROM EPM_PROJECT_CONTRACT
 WHERE NVL(PROJECT_CONTRACT_CHARACTER, 0) = 2 --分包合同
   AND STAT = 5
/*********************************************\
  * NAME(名称): VIEW_PROJECT_SUB_CONTRACT
  * PURPOSE(功能说明):  分包合同明细
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2019-09-06
  \*********************************************/
/

