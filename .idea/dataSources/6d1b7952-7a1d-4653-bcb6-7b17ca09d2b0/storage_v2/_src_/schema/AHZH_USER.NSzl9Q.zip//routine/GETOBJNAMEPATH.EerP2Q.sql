create function           getobjnamepath(idpath  varchar2, typepath   varchar2) return
varchar2
is
  typetmp number;
  idtmp number;
  namepath varchar2(200);

begin
   if idpath is null or typepath is null then
      return '';
   end if;
      namepath:='';
     if typepath is not null then
        typetmp:=to_number(substr(typepath,1,instr(typepath,'\',1,1)-1));
        idtmp:=to_number(substr(idpath,1,instr(idpath,'\',1,1)-1));

         if typetmp=1 then
            select namepath||wsname||'\'
            into namepath
            from cpcworkspace
            where wsid=idtmp;
         elsif typetmp=2 then
            select namepath||fdrname||'\'
            into namepath
            from cpcfdr
            where fdrname=idtmp;
         elsif typetmp=3 then
            select namepath||projname||'\'
            into namepath
            from cpcproj
            where projid=idtmp;
         elsif typetmp in(4,10,11) then
            select namepath||tssname||'\'
            into namepath
            from cpctss
            where tssid=idtmp;
         elsif typetmp=5 then
            select namepath||dssname||'\'
            into namepath
            from cpcdss
            where dssid=idtmp;
         elsif typetmp=6 then
            select namepath||docname||'\'
            into namepath
            from cpcdoc
            where docid=idtmp;
         elsif typetmp=7 then
            select namepath||wftempname||'\'
            into namepath
            from cpcwftemp
            where wftempid=idtmp;
         else
            namepath:=namepath||'<未?>\';
        end if;
      end if;

  return namepath;

end getobjnamepath;
/

