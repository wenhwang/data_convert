create view USP_PURCHASEPRICEFORCPC as
select aa.item_code,
       aa.PRICE_TAX_min,
       aa.PRICE_TAX_max,
       um1.uom_name as uom_name1,
       case
         when uc.uom_tax is null then
          1
         else
          uc.uom_tax
       end as rate,
       case
         when um2.uom_name is null then
          um1.uom_name
         else
          um2.uom_name
       end as uom_name2
  from (SELECT it.item_code,
               it.item_id,
               min(SP.PRICE_TAX) PRICE_TAX_min,
               Max(SP.PRICE_TAX) PRICE_TAX_max
          FROM SRM_PURCHASE_PRICE SP, item it
         WHERE SP.PRICE_STATUS = 2
           and sp.item_id = it.item_id
         GROUP BY it.item_code, it.item_id) aa,
       uom_item_conversion uc,
       item it,
       uom um1,
       uom um2
 where aa.item_id = uc.item_id(+)
   and it.item_id = aa.item_id
   and it.uom_id = um1.uom_id
   and uc.assistant_uom_id = um2.uom_id(+)
/

