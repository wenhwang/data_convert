create view VIEW_FAX_RECINOUT as
    select 4 as flag,
       fr.sysuserid,
       fr.recinout_id,
       fr.organization_id,
       fr.t_fax_code,
       fr.t_telpho_code,
       fr.s_fax_code,
       fr.s_fax_name,
       fr.t_fax_name,
       fr.fax_date,
       fr.year_month,
       fr.is_direct,
       fr.obj_type,
       fr.obj_id,
       fr.fax_type,
       fr.is_stamp,
       fr.fax_subject,
       fr.is_confirm,
       fr.op_type,
       fr.remark,
       fr.fax_sort,
       fr.fax_status,
       fr.err_code,
       fr.last_update_date
  from fax_recinout fr
 where is_direct = 2 --宸叉？？朵？？?-链？‘璁?   and fr.is_confirm = 1
   and fr.op_type = 1
   and fr.sysuserid > 0
union all
select 5 as flag,
       fr.sysuserid,
       fr.recinout_id,
       fr.organization_id,
       fr.t_fax_code,
       fr.t_telpho_code,
       fr.s_fax_code,
       fr.s_fax_name,
       fr.t_fax_name,
       fr.fax_date,
       fr.year_month,
       fr.is_direct,
       fr.obj_type,
       fr.obj_id,
       fr.fax_type,
       fr.is_stamp,
       fr.fax_subject,
       fr.is_confirm,
       fr.op_type,
       fr.remark,
       fr.fax_sort,
       fr.fax_status,
       fr.err_code,
       fr.last_update_date
  from fax_recinout fr
 where is_direct = 2 --宸叉？？朵？？?-宸茬‘璁?   and fr.is_confirm = 2
   --and fr.op_type = 1
   and fr.sysuserid > 0
union all
select 9 as flag,
       fr.sysuserid,
       fr.recinout_id,
       fr.organization_id,
       fr.t_fax_code,
       fr.t_telpho_code,
       fr.s_fax_code,
       fr.s_fax_name,
       fr.t_fax_name,
       fr.fax_date,
       fr.year_month,
       fr.is_direct,
       fr.obj_type,
       fr.obj_id,
       fr.fax_type,
       fr.is_stamp,
       fr.fax_subject,
       fr.is_confirm,
       fr.op_type,
       fr.remark,
       fr.fax_sort,
       fr.fax_status,
       fr.err_code,
       fr.last_update_date
  from fax_recinout fr
 where fr.is_direct = 1 --宸插？阃？？？?？？？?   and fr.fax_sort = 1
   and fr.is_confirm = 1
   --and fr.op_type = 1
   and fr.sysuserid > 0
union all
select 10 as flag,
       fr.sysuserid,
       fr.recinout_id,
       fr.organization_id,
       fr.t_fax_code,
       fr.t_telpho_code,
       fr.s_fax_code,
       fr.s_fax_name,
       fr.t_fax_name,
       fr.fax_date,
       fr.year_month,
       fr.is_direct,
       fr.obj_type,
       fr.obj_id,
       fr.fax_type,
       fr.is_stamp,
       fr.fax_subject,
       fr.is_confirm,
       fr.op_type,
       fr.remark,
       fr.fax_sort,
       fr.fax_status,
       fr.err_code,
       fr.last_update_date
  from fax_recinout fr
 where fr.is_direct = 1 --宸插？阃？？？?绯荤？
   and fr.fax_sort = 2
   and fr.is_confirm = 1
   --and fr.op_type = 1
   and fr.sysuserid > 0
union all
select 8 as flag,
       fs.sysuserid,
       fr.recinout_id,
       fr.organization_id,
       fr.t_fax_code,
       fr.t_telpho_code,
       fr.s_fax_code,
       fr.s_fax_name,
       fr.t_fax_name,
       fr.fax_date,
       fr.year_month,
       fr.is_direct,
       fr.obj_type,
       fr.obj_id,
       fr.fax_type,
       fr.is_stamp,
       fr.fax_subject,
       fr.is_confirm,
       fr.op_type,
       fr.remark,
       fr.fax_sort,
       fr.fax_status,
       fr.err_code,
       fr.last_update_date
  from fax_shared fs, fax_recinout fr
 where fs.organization_id = fr.organization_id
   and fs.recinout_id = fr.recinout_id --？变韩缁？？镄？？？?   and fr.sysuserid > 0
union all
select 7 as flag,
       fr.sysuserid,
       fr.recinout_id,
       fr.organization_id,
       fr.t_fax_code,
       fr.t_telpho_code,
       fr.s_fax_code,
       fr.s_fax_name,
       fr.t_fax_name,
       fr.fax_date,
       fr.year_month,
       fr.is_direct,
       fr.obj_type,
       fr.obj_id,
       fr.fax_type,
       fr.is_stamp,
       fr.fax_subject,
       fr.is_confirm,
       fr.op_type,
       fr.remark,
       fr.fax_sort,
       fr.fax_status,
       fr.err_code,
       fr.last_update_date
  from fax_recinout fr
 where fr.op_type  = 4 --？变韩缁椤？浜虹？浼？？
   and fr.sysuserid > 0
union all
select 6 as flag,
       fr.sysuserid,
       fr.recinout_id,
       fr.organization_id,
       fr.t_fax_code,
       fr.t_telpho_code,
       fr.s_fax_code,
       fr.s_fax_name,
       fr.t_fax_name,
       fr.fax_date,
       fr.year_month,
       fr.is_direct,
       fr.obj_type,
       fr.obj_id,
       fr.fax_type,
       fr.is_stamp,
       fr.fax_subject,
       fr.is_confirm,
       fr.op_type,
       fr.remark,
       fr.fax_sort,
       fr.fax_status,
       fr.err_code,
       fr.last_update_date
  from fax_recinout fr
 where fr.sysuserid = 0
/

