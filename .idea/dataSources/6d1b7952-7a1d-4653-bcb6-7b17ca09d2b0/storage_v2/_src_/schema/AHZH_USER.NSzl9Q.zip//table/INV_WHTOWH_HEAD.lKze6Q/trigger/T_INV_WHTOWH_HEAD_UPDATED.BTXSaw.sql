create trigger T_INV_WHTOWH_HEAD_UPDATED
    after update
    on INV_WHTOWH_HEAD
    for each row
declare
  v_count number := 0;
  head_id number := 0;
begin
  if updating then
    --查询是否配置帐套对照关系
    select count(1)
      into v_count
      from CCS_BMS_ORG_COMPARE c
     where nvl(c.usable, 0) = 2
       and c.organization_id = :new.organization_id;
    --存在则写入接口表
    if v_count = 1 then
      --调拨单审核时写入接口表
      if (:new.is_checked = 2) and (nvl(:old.is_checked, 0) <> 2) then
        --取序列
        select sq_inv_out_to_ccs__head.nextval into head_id from dual;

        --插入接口表
        insert into inv_out_to_ccs_head
          (INV_OUT_TO_CCS_HEAD_ID,
           ORGANIZATION_ID,
           SOURCE_HEAD_ID,
           INVBILLNO,
           WAREHOUSE_ID,
           WAREHOUSE_CODE,
           DATE_INVBILL,
           VENDOR_ID,
           VENDOR_CODE,
           CUSTOMER_ID,
           CUSTOMER_CODE,
           DEPT_ID,
           DEPT_CODE,
           AMOUNT_TOTAL_F,
           NOTE,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           ATTRIBUTE1,
           ATTRIBUTE2,
           ATTRIBUTE3,
           ATTRIBUTE4,
           ATTRIBUTE5,
           INV_OUT_TYPE,
           QTY_SUM,
           PHONE_CODE,
           ADDRESS1,
           EMPLOYEE_NAME,
           TOTAL_CUBAGE,
           SEND_TIME,
           CUST_ORDER_NO,
           STATUS,
           ERROR_MES,
           BILL_TYPE,
           TO_DEPT_ID,
           TO_DEPT_CODE,
           TO_WAREHOUSE_ID,
           TO_WAREHOUSE_CODE)
          select head_id,
                 (select c.ccs_organization_id
                    from CCS_BMS_ORG_COMPARE c
                   where nvl(c.usable, 0) = 2
                     and c.organization_id = :new.organization_id) ORGANIZATION_ID,
                 :new.inv_whtowh_head_id SOURCE_HEAD_ID,
                 :new.INV_WHTOWH_HEAD_NO INVBILLNO,
                 :new.from_wh_id WAREHOUSE_ID,
                 (select w.warehouse_code
                    from warehouse w
                   where w.warehouse_id = :new.from_wh_id
                     and w.organization_id = :new.organization_id
                     and rownum = 1) WAREHOUSE_CODE,
                 :new.BILL_DATE DATE_INVBILL,
                 0 VENDOR_ID,
                 '' VENDOR_CODE,
                 :new.CUSTOMER_ID,
                 (select c.customer_code
                    from customer c
                   where c.customer_id = :new.customer_id
                     and rownum = 1) CUSTOMER_CODE,
                 :new.from_dept_id DEPT_ID,
                 (select d.dept_code
                    from dept d
                   where d.dept_id = :new.from_dept_id) DEPT_CODE,
                 :new.AMOUNT_TOTAL_F AMOUNT_TOTAL_F,
                 :new.REMARK NOTE,
                 :new.CREATED_BY,
                 :new.CREATION_DATE,
                 'admin' LAST_UPDATED_BY,
                 sysdate LAST_UPDATE_DATE,
                 :new.ATTRIBUTE1,
                 :new.ATTRIBUTE2,
                 :new.ATTRIBUTE3,
                 :new.ATTRIBUTE4,
                 :new.ATTRIBUTE5,
                 :new.MOVE_TYPE INV_OUT_TYPE,
                 :new.QTY_SUM,
                 :new.PHONE_CODE,
                 :new.ADDRESS1,
                 :new.EMPLOYEE_NAME,
                 :new.TOTAL_CUBAGE,
                 :new.SEND_TIME,
                 :new.CUST_ORDER_NO,
                 0 STATUS,
                 '' ERROR_MES,
                 10 BILL_TYPE,
                 :new.TO_DEPT_ID,
                 (select d.dept_code
                    from dept d
                   where d.dept_id = :new.to_dept_id) DEPT_CODE,
                 :new.to_wh_id TO_WAREHOUSE_ID,
                 (select w.warehouse_code
                    from warehouse w
                   where w.warehouse_id = :new.to_wh_id
                     and w.organization_id = :new.organization_id
                     and rownum = 1) to_WAREHOUSE_CODE
            from dual;

        --插入明细接口表
        insert into inv_out_to_ccs_line
          (INV_OUT_TO_CCS_LINE_ID,
           INV_OUT_TO_CCS_HEAD_ID,
           SOURCE_HEAD_ID,
           SOURCE_LINE_ID,
           LINENO,
           ITEM_ID,
           ITEM_CODE,
           QTY_BILL,
           PRICE_BILL_F,
           AMOUNT_BILL_F,
           REMARK,
           WAREHOUSE_ID,
           WAREHOUSE_CODE,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           ATTRIBUTE11,
           ATTRIBUTE21,
           ATTRIBUTE31,
           ATTRIBUTE41,
           ATTRIBUTE51,
           WTPRICEC_BILL_F,
           WTAMOUNT_BILL_F,
           WAREHOUSE_ID_OUT,
           WAREHOUSE_CODE_OUT)
          select sq_inv_out_to_ccs_line.nextval INV_OUT_TO_CCS_LINE_ID,
                 head_id INV_OUT_TO_CCS_HEAD_ID,
                 bl.INV_WHTOWH_HEAD_ID SOURCE_HEAD_ID,
                 bl.INV_WHTOWH_LINE_ID SOURCE_LINE_ID,
                 bl.LINE_NO LINENO,
                 bl.ITEM_ID,
                 (select i.item_code
                    from item i
                   where i.item_id = bl.item_id) ITEM_CODE,
                 bl.QTY_MOVED QTY_BILL,
                 bl.PRICE_BILL_F,
                 bl.AMOUNT_BILL_F,
                 bl.REMARK,
                 bl.WAREHOUSE_ID_IN WAREHOUSE_ID,
                 (select w.warehouse_code
                    from warehouse w
                   where w.warehouse_id = bl.WAREHOUSE_ID_IN
                     and w.organization_id = :new.organization_id) WAREHOUSE_CODE,
                 bl.CREATED_BY,
                 bl.CREATION_DATE,
                 'admin' LAST_UPDATED_BY,
                 sysdate LAST_UPDATE_DATE,
                 bl.ATTRIBUTE1,
                 bl.ATTRIBUTE2,
                 bl.ATTRIBUTE3,
                 bl.ATTRIBUTE4,
                 bl.attribute5,
                 bl.PRICE_BILL_F WTPRICEC_BILL_F,
                 bl.AMOUNT_BILL_F WTAMOUNT_BILL_F,
                 bl.warehouse_id_out WAREHOUSE_ID,
                 (select w.warehouse_code
                    from warehouse w
                   where w.warehouse_id = bl.warehouse_id_out
                     and w.organization_id = :new.organization_id) WAREHOUSE_CODE
            from inv_whtowh_line bl
           where bl.inv_whtowh_head_id = :old.inv_whtowh_head_id;

      end if;
    end if;
  end if;
end;
/

