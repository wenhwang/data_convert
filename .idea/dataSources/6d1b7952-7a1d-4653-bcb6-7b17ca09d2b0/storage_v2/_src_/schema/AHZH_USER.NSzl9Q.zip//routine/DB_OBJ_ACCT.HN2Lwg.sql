create Function           Db_Obj_Acct(P_KM_CODEs         Varchar2,
                                   P_GET_TYPE         VARCHAR2,
                                   P_S_YEAR_MONTH     VARCHAR2,
                                   P_E_YEAR_MONTH     VARCHAR2,
                                   P_Organization_Ids Varchar2,
                                   P_Object_Type      Varchar2,
                                   P_Object_Id        Integer)
  Return Number Is
  Result Number;
  /*l_str     VARCHAR2(1000) := P_KM_CODEs || '\';
  l_n       NUMBER;*/
  kmcodes   VARCHAR2(1000);
  orgids    VARCHAR2(300);
  Sqlwhere  VARCHAR2(2000);
  fieldname VARCHAR2(30);
  fieldname2 VARCHAR2(30);
  tablename VARCHAR2(30);
  intflag   number;
  S_YEAR_MONTH  VARCHAR2(7);
  E_YEAR_MONTH  VARCHAR2(7);
  /*
  銮峰？杈？？镙哥？瀵硅薄浣？？？版？

  p_Organization_Id  浜у？缁？？ID
  P_KM_CODE           绉？？浠ｇ？,
  P_GET_TYPE  C 链？？？般？？F ？？？？？？？般？？F 璐锋？？？？？般？？ 链？汤？般？？C 骞村？？般？？Y 骞存汤？?
  P_S_YEAR_MONTH    寮？濮？？浠?
  P_E_YEAR_MONTH   缁？？链？唤,
  p_Object_Type    瀵硅薄绫诲？:？？l_a_curr_account琛？？？？？涓昏？？?Crm_EntId？？ntOrgId
  P_Object_Id      瀵硅薄ID
  */

Begin

  --Sqlwhere := '';
  --瑙ｆ？绉？？
  /*IF instr(l_str, '\') = 1 THEN
    l_str := SUBSTR(l_str, 2);
  END IF;
  LOOP
    l_n := instr(l_str, '\');
    EXIT WHEN(NVL(l_n, 0) = 0);
    if kmcodes is null or length(kmcodes) = 0 then
      kmcodes := '''' || SUBSTR(l_str, 1, l_n - 1) || '''';
    else
      kmcodes := kmcodes || ',' || '''' || SUBSTR(l_str, 1, l_n - 1) || '''';

    end if;
    l_str := SUBSTR(l_str, l_n + 1);
  END LOOP;*/

  --瑙ｆ？绉？？
  select replace(P_KM_CODEs, '\', ''',''') into kmcodes from dual;
  --瑙ｆ？缁？？
  select replace(P_Organization_Ids, '\', ',') into orgids from dual;

  --骞存？澶？？
  S_YEAR_MONTH:=P_S_YEAR_MONTH;
  E_YEAR_MONTH:=P_E_YEAR_MONTH;

  --镙规？？？？？ゆ？？？？？ユ？ definecelltall Tall_Flag 1 gl_account_subject_balances 2 gl_account_subject_balance
  Sqlwhere :='select Tall_Flag from definecelltall '||
             ' where organization_id in (' || orgids || ') and rownum = 1';
   execute immediate sqlwhere
    into intflag;

  if (intflag is not null) And (intflag=1) then
     tablename:='gl_a_current_accounts';
  else
     tablename:='gl_a_current_account';
  end if;

  --C 链？？ JF ？？？？？？？?DF璐锋？？？？？?Y链？汤
  if P_GET_TYPE = 'C' then
    fieldname := '(gsb.AMOUNT_DEBIT_FIRST-gsb.amount_credit_first) as amount_first ';
    fieldname2 := '(gsb.amount_credit_first-gsb.AMOUNT_DEBIT_FIRST) as amount_first ';
  elsif P_GET_TYPE = 'JF' then
    fieldname := 'gsb.amount_this_debit';
    fieldname2 := 'gsb.amount_this_debit';
  elsif P_GET_TYPE = 'DF' then
    fieldname := 'gsb.amount_this_credit ';
    fieldname2 := 'gsb.amount_this_credit ';
  elsif P_GET_TYPE = 'Y' then
    fieldname := '(gsb.amount_debit_end-gsb.amount_credit_end) as gsb.amount_end ';
    fieldname2 := '(gsb.amount_credit_end-gsb.amount_debit_end) as gsb.amount_end ';
  elsif P_GET_TYPE = 'YC' then
  begin
    fieldname := '(gsb.AMOUNT_DEBIT_FIRST-gsb.amount_credit_first) as amount_first ';
    fieldname2 := '(gsb.amount_credit_first-gsb.AMOUNT_DEBIT_FIRST) as amount_first ';
    S_YEAR_MONTH := substr(P_S_YEAR_MONTH,0,4)||'-01';
    E_YEAR_MONTH := substr(P_S_YEAR_MONTH,0,4)||'-01';
  end;
  elsif P_GET_TYPE = 'YY' then
  begin
    fieldname := '(gsb.amount_debit_end-gsb.amount_credit_end) as gsb.amount_end ';
    fieldname2 := '(gsb.amount_credit_end-gsb.amount_debit_end) as gsb.amount_end ';
    S_YEAR_MONTH := substr(P_E_YEAR_MONTH,0,4)||'-12';
    E_YEAR_MONTH := substr(P_E_YEAR_MONTH,0,4)||'-12';
  end;
  end if;

  Sqlwhere := 'select sum(decode(gs.KM_PROPERTY,1,' || fieldname || ','||fieldname2||')) amount ' ||
              '  from '||tablename||' gsb,'||
              '     (select gl_account_subject_id, KM_PROPERTY'||
              '        from gl_account_subject'||
              '       start with km_code in (''' || kmcodes || ''')'||
              '     Connect By Prior Gl_Account_Subject_Id = Gl_Account_Subject_Pid'||
              '     ) gs' ||
              ' where gsb.gl_account_subject_id=gs.gl_account_subject_id' ||
              '   and gsb.year_month between ''' || S_YEAR_MONTH ||
              ''' and ''' || E_YEAR_MONTH || '''' ||
              ' and gsb.organization_id in (' || orgids || ')'||
              ' and gsb.object_type = '''||P_Object_Type||''''||
              ' And gsb.object_id = '||p_object_id;
  --Dbms_Output.Put_Line('Sqlwhere:' || Sqlwhere);
  execute immediate sqlwhere into Result;

  Return Nvl(Result, 0);

End Db_Obj_Acct;
/

