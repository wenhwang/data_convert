create view VIEW_INITIAL_CHANGE_CROSSWISE as
SELECT "PROJECT_ID","PROJECT_RECEIVE_AMOUNT","PROJECT_PAYMENT_AMOUNT","PROJECT_INVEST_AMOUNT","AGENT_PURCHASE_OUT_AMOUNT","IN_MARGIN_AMOUNT","OUT_MARGIN_AMOUNT","TRANSFER_IN_AMOUNT","TRANSFER_OUT_AMOUNT","BORROW_AMOUNT","LOAN_AMOUNT","OUTPUT_VAT_AMOUNT","OUTPUT_INVOICE_AMOUNT","INPUT_VAT_AMOUNT","INPUT_INVOICE_AMOUNT","WITHHOLD_MANAGEMENT_AMOUNT","WITHHOLD_YEAR_AMOUNT","WITHHOLD_TAX_AMOUNT","WITHHOLD_OTHER_AMOUNT","PROJECT_FINE_AMOUNT","OTHER_IN_AMOUNT","OTHER_OUT_AMOUNT"
  FROM (SELECT PROJECT_ID, ACCT_BLNC_FIELD_NAME, SUM(CHANGE_AMOUNT) AMOUNT
          FROM EPM_PROJECT_BALANCE_CHANGE
         WHERE STAT = 5
         GROUP BY PROJECT_ID, ACCT_BLNC_FIELD_NAME) PIVOT(SUM(AMOUNT) FOR ACCT_BLNC_FIELD_NAME IN (

         'PROJECT_RECEIVE_AMOUNT' PROJECT_RECEIVE_AMOUNT,
         'PROJECT_PAYMENT_AMOUNT' PROJECT_PAYMENT_AMOUNT,
         'PROJECT_INVEST_AMOUNT' PROJECT_INVEST_AMOUNT,
         'AGENT_PURCHASE_OUT_AMOUNT' AGENT_PURCHASE_OUT_AMOUNT,
         'IN_MARGIN_AMOUNT' IN_MARGIN_AMOUNT,
         'OUT_MARGIN_AMOUNT' OUT_MARGIN_AMOUNT,
         'TRANSFER_IN_AMOUNT' TRANSFER_IN_AMOUNT,
         'TRANSFER_OUT_AMOUNT' TRANSFER_OUT_AMOUNT,
         'BORROW_AMOUNT' BORROW_AMOUNT,
         'LOAN_AMOUNT' LOAN_AMOUNT,
         'OUTPUT_VAT_AMOUNT' OUTPUT_VAT_AMOUNT,
         'OUTPUT_INVOICE_AMOUNT' OUTPUT_INVOICE_AMOUNT,
         'INPUT_VAT_AMOUNT' INPUT_VAT_AMOUNT,
         'INPUT_INVOICE_AMOUNT' INPUT_INVOICE_AMOUNT,
         'WITHHOLD_MANAGEMENT_AMOUNT' WITHHOLD_MANAGEMENT_AMOUNT,
         'WITHHOLD_YEAR_AMOUNT' WITHHOLD_YEAR_AMOUNT,
         'WITHHOLD_TAX_AMOUNT' WITHHOLD_TAX_AMOUNT,
         'WITHHOLD_OTHER_AMOUNT' WITHHOLD_OTHER_AMOUNT,
         'PROJECT_FINE_AMOUNT' PROJECT_FINE_AMOUNT,
         'OTHER_IN_AMOUNT' OTHER_IN_AMOUNT,
         'OTHER_OUT_AMOUNT' OTHER_OUT_AMOUNT))

/*********************************************\
  * NAME(名称): VIEW_INITIAL_CHANGE_CROSSWISE
  * PURPOSE(功能说明):  余额初始化及变更横向列表
                                    收工程款  PROJECT_RECEIVE_AMOUNT
                                    付工程款  PROJECT_PAYMENT_AMOUNT

                                    收投资款  PROJECT_INVEST_AMOUNT
                                    付投资款  AGENT_PURCHASE_OUT_AMOUNT

                                    收保证金  IN_MARGIN_AMOUNT
                                    付保证金  OUT_MARGIN_AMOUNT

                                    往来调拨收款  TRANSFER_IN_AMOUNT
                                    往来调拨付款  TRANSFER_OUT_AMOUNT

                                    公司借支  BORROW_AMOUNT
                                    公司借入  LOAN_AMOUNT

                                    累计开票金额  OUTPUT_VAT_AMOUNT
                                    销项票税额  OUTPUT_INVOICE_AMOUNT
                                    累计收票金额  INPUT_VAT_AMOUNT
                                    进项票税额  INPUT_INVOICE_AMOUNT

                                    项目扣款金额(管理费)  WITHHOLD_MANAGEMENT_AMOUNT
                                    项目扣款金额(年费)  WITHHOLD_YEAR_AMOUNT
                                    项目扣款金额(税费)  WITHHOLD_TAX_AMOUNT
                                    项目扣款金额(其他)  WITHHOLD_OTHER_AMOUNT

                                    项目罚款金额  PROJECT_FINE_AMOUNT

                                    其他回款  OTHER_IN_AMOUNT
                                    其他付款  OTHER_OUT_AMOUNT


  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2017-12-19
  \*********************************************/
/

