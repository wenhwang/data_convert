create Procedure           Usp_Inv_Monthcheck(Int_Organization_Id Number) As

  --月末处理
  --wsx
  --2005.05.11
  --Modified BY: DingHua 06.05.07
  --modify by zks 060515 结存金额=上月结存金额+本月入库金额-本月出库金额。结存单价=round(结存金额/结存数量,6)
  --modify by zks 060607 解决"物料结存表中结存单价和结存金额一致？"
  Str_Premonth      Varchar2(7);
  Str_Currmonth     Varchar2(7);
  Str_Monthdealwith Varchar2(200);
  --str_monthdealwithtime varchar2(300);
  Str_Sql                Varchar2(10000);
  Str_Tcltable_Tmp       Varchar2(50);
  Str_Vendortable_Tmpsum Varchar2(50);
  Str_Vendortable_Tmpinv Varchar2(50);
  Str_Tmp                Varchar2(50);
  Intcount               Integer;
Begin
  Intcount := 0;
  -- Int_ORGANIZATION_ID := 1; ---传入组织id
  Str_Monthdealwith := To_Char(Sysdate, 'yyyy-mm-dd hh24:mi:ss');

  --取上期间
  Select To_Char(To_Date(max(Gd.Year_Month) || '-01', 'yyyy-mm-dd') - 1,
                 'yyyy-mm')
    Into Str_Premonth
    From Gl_Account_Period Gd
   Where Gd.Organization_Id = Int_Organization_Id
     And Gd.Is_Current_Period_Inv = 2;

  --取当前期间--yyyy-mm
  Select max(Gd.Year_Month)
    Into Str_Currmonth
    From Gl_Account_Period Gd
   Where Gd.Organization_Id = Int_Organization_Id
     And Gd.Is_Current_Period_Inv = 2;

 /* --取当前期间--yyyymm
  Select To_Char(To_Date(Str_Currmonth || '-01', 'yyyy-mm-dd'), 'yyyymm')
    Into Str_Tmp
    From Dual;

  --设置临时表
  Str_Tcltable_Tmp       := 'tcl' || Str_Tmp || '_' || Int_Organization_Id;
  Str_Vendortable_Tmpsum := 'vd' || Str_Tmp || 'sum_' ||
                            Int_Organization_Id;
  Str_Vendortable_Tmpinv := 'vd' || Str_Tmp || 'inv_' ||
                            Int_Organization_Id;*/

  --取当前期间--yyyy+6位毫秒数
  Select To_Char(To_Date(Str_Currmonth, 'yyyy-mm'), 'yyyy') || To_Char(systimestamp, 'ff')
    Into Str_Tmp
    From Dual;

  --设置临时表
  Str_Tcltable_Tmp       := 'tcl' || Str_Tmp;
  Str_Vendortable_Tmpsum := 'vd' || Str_Tmp || '_sum';
  Str_Vendortable_Tmpinv := 'vd' || Str_Tmp || '_inv';

  Select Count(*)
    Into Intcount
    From Tab
   Where Tname = Upper(Str_Tcltable_Tmp)
     And Tabtype = 'TABLE';
  If (Intcount > 0) Then
    Str_Sql := 'Drop table ' || Upper(Str_Tcltable_Tmp);
    Execute Immediate Str_Sql;
  End If;

  Select Count(*)
    Into Intcount
    From Tab
   Where Tname = Upper(Str_Vendortable_Tmpsum)
     And Tabtype = 'TABLE';
  If Intcount > 0 Then
    Str_Sql := 'Drop table ' || Upper(Str_Vendortable_Tmpsum);
    Execute Immediate Str_Sql;
  End If;

  Select Count(*)
    Into Intcount
    From Tab
   Where Tname = Upper(Str_Vendortable_Tmpinv)
     And Tabtype = 'TABLE';
  If Intcount > 0 Then
    Str_Sql := 'Drop table ' || Upper(Str_Vendortable_Tmpinv);
    Execute Immediate Str_Sql;
  End If;

  --1、取发生入库数
  --union all
  --2、取委外材料费，仅取金额，不能取数量
  --union all
  --3、取发生出库数
  --统计数量、金额
  Str_Sql := 'Create table ' || Str_Tcltable_Tmp ||
             ' as select ORGANIZATION_ID, YEAR_MONTH, WAREHOUSE_ID, nvL(Inv_Batch_Id,0) inv_batch_id, ITEM_ID,' ||
             '       SUM(QTY_IN) QTY_IN, SUM(QTY_OUT) QTY_OUT, sum(amount_in) amount_in, sum(amount_out) amount_out' ||
             '  from (select /*+ USE_CONCAT */ ' || Int_Organization_Id ||
             ' ORGANIZATION_ID,''' || Str_Currmonth || ''' year_month,' ||
             '               ibl.warehouse_id,ibl.Inv_Batch_Id, ibl.item_id, sum(ibl.qty_invbill) qty_in,' ||
             '               SUM(decode(ibh.billtypecode,'||''''||'0103'||''''||',ibl.amount_out_material+IBL.AMOUNT_BILL_NOTAX, IBL.AMOUNT_BILL_NOTAX)) AS AMOUNT_IN, 0 qty_out, 0 AMOUNT_out' ||
             '          from inv_in_bill_line ibl, inv_in_bill_head ibh' ||
             '         where ibh.inv_in_bill_head_id = ibl.inv_in_bill_head_id' ||
             '           and ibh.is_auditing_wh = 2' ||
             '           and nvl(ibh.Is_Init_Bill,1)<>2' ||
             '           and ibh.organization_id = ' || Int_Organization_Id ||
             '           and ibh.year_month = ''' || Str_Currmonth || '''' ||
             '         group by ibl.warehouse_id,ibl.Inv_Batch_Id, ibl.item_id' ||
/*
Modified by duan guijun 2012.08.23
Description: 委外材料费直接从委外入库 amount_out_material中取，故屏蔽
             '        union all' || '        select ' ||
             Int_Organization_Id || ' ORGANIZATION_ID,''' || Str_Currmonth ||
             ''' year_month,' ||
             '               iibl.warehouse_id, iibl.Inv_Batch_Id, iibl.item_id, 0 qty_in,' ||
             '               SUM(nvl(iobl.AMOUNT_BILL_NOTAX,0)) AS AMOUNT_IN, 0 qty_out, 0 AMOUNT_out' ||
             '          from inv_out_bill_line iobl, inv_out_bill_head iobh, inv_in_bill_line iibl, inv_in_bill_head iibh' ||
             '         where iobh.inv_out_bill_head_id = iobl.inv_out_bill_head_id' ||
             '           and iobh.parentbillid = iibl.inv_in_bill_line_id' ||
             '           and iibh.inv_in_bill_head_id = iibl.inv_in_bill_head_id' ||
             '           and iobh.billtypecode = ''1201'' and iobh.is_auditing_wh = 2' ||
             '           and nvl(iobh.Is_Init_Bill,1)<>2' ||
             '           and iobh.year_month = ''' || Str_Currmonth ||
             ''' and iobh.organization_id = ' || Int_Organization_Id ||
             '           and iibh.billtypecode = ''0103'' and iibh.is_auditing_wh = 2' ||
             '           and iibh.year_month = ''' || Str_Currmonth ||
             ''' and iibh.organization_id = ' || Int_Organization_Id ||
             '         group by iibl.warehouse_id, iibl.Inv_Batch_Id, iibl.item_id' ||*/
             '        union all' || '        select ' ||
             Int_Organization_Id || ' ORGANIZATION_ID,''' || Str_Currmonth ||
             ''' year_month,' ||
             '               iol.warehouse_id, iol.Inv_Batch_Id, iol.item_id, 0 qty_in,' ||
             '               0 AMOUNT_in, sum(iol.qty_bill) as qty_out, SUM(IOL.AMOUNT_BILL_NOTAX) AMOUNT_out' ||
             '          from inv_out_bill_line iol, inv_out_bill_head ioh' ||
             '         where ioh.inv_out_bill_head_id = iol.inv_out_bill_head_id' ||
             '           and ioh.is_auditing_wh = 2' ||
             '           And nvl(ioh.Is_Init_Bill,1)<>2' ||
             '           and ioh.year_month = ''' || Str_Currmonth ||
             ''' and ioh.organization_id = ' || Int_Organization_Id ||
             '         group by iOl.warehouse_id, iol.Inv_Batch_Id, iOl.item_id' ||
             '        )' ||
             ' group by ORGANIZATION_ID, YEAR_MONTH, WAREHOUSE_ID,Inv_Batch_Id, ITEM_ID';
  Execute Immediate Str_Sql;

  --创建index
  Str_Sql := 'create index ix_' || Str_Tcltable_Tmp || '01 on ' || Str_Tcltable_Tmp || ' (organization_id, year_month)';
  Execute Immediate Str_Sql;

  Str_Sql := 'create unique index ix_' || Str_Tcltable_Tmp || '02 on ' || Str_Tcltable_Tmp ||' (ORGANIZATION_ID,YEAR_MONTH,WAREHOUSE_ID,Inv_Batch_Id,ITEM_ID)';
  Execute Immediate Str_Sql;
  --删除当前期间的数据;
  Delete Inv_Monthsum Im
   Where Im.Organization_Id = Int_Organization_Id
     And Im.Year_Month = Str_Currmonth;
  Commit;

  --把前一个期间的数据插入当前期间的数据
  Insert Into Inv_Monthsum
    (Organization_Id,
     Year_Month,
     Warehouse_Id,
     Inv_Batch_Id,
     Item_Id,
     Qty_Lm,
     Qty_In,
     Qty_Out,
     Qty_Blnc,
     Price_Lm,
     Price_In,
     Price_Out,
     Price_Blnc,
     Amount_Lm,
     Amount_In,
     Amount_Out,
     Amount_Blnc)
    Select Int_Organization_Id,
           Str_Currmonth,
           Warehouse_Id,
           Inv_Batch_Id,
           Item_Id,
           Qty_Blnc,
           0,
           0,
           0,
           Price_Blnc,
           0,
           0,
           0,
           Amount_Blnc,
           0,
           0,
           0
      From Inv_Monthsum
     Where Organization_Id = Int_Organization_Id
       And Year_Month = Str_Premonth;
  Commit;

  --插入新的本期入库量、本期出库量、本位币本期入库金额（未税）、本位币本期出库金额（未税）
  Str_Sql := 'INSERT INTO inv_monthsum ISM' ||
             '    (ORGANIZATION_ID, YEAR_MONTH, WAREHOUSE_ID, Inv_Batch_Id, ITEM_ID,' ||
             '     QTY_LM, QTY_IN, QTY_OUT, QTY_BLNC,' ||
             '     PRICE_LM, PRICE_IN, PRICE_OUT, PRICE_BLNC,' ||
             '     AMOUNT_LM, AMOUNT_IN, AMOUNT_OUT, AMOUNT_BLNC)' ||
             '    SELECT IMM2.ORGANIZATION_ID, Imm2.Year_Month, imm2.warehouse_id, imm2.Inv_Batch_Id,imm2.item_id,' ||
             '           0 qty_lm, imm2.qty_in, imm2.qty_out, 0 qty_blnc,' ||
             '           0 price_lm, 0 price_in, 0 price_out, 0 price_blnc,' ||
             '           0 amount_lm, imm2.amount_in, imm2.amount_out, 0 amount_blnc' ||
            --zks write'    SELECT IMM2.ORGANIZATION_ID,Imm2.Year_Month,imm2.warehouse_id,imm2.Inv_Batch_Id,imm2.item_id,0,0,0,0,0,0,0,' ||
            --zks write'    0,0,0,0,0'||
             '      FROM ' || Str_Tcltable_Tmp || ' IMM2, inv_monthsum ism' ||
             '     WHERE IMM2.WAREHOUSE_ID = ISM.WAREHOUSE_ID(+)' ||
             '       AND IMM2.ITEM_ID = ISM.ITEM_ID(+)' ||
             '       AND IMM2.Inv_Batch_Id = ISM.Inv_Batch_Id(+)' ||
             '       and IMM2.year_month = ''' || Str_Currmonth ||
             ''' and IMM2.organization_id = ' || Int_Organization_Id ||
             '       and ISM.year_month (+)= ''' || Str_Currmonth ||
             ''' and ISM.organization_id (+)= ' || Int_Organization_Id ||
             '       and ism.organization_id is null';
  Execute Immediate Str_Sql;
  Commit;

  --修改原来的本期入库量、本期出库量、本位币本期入库金额（未税）、本位币本期出库金额（未税）
  Str_Sql := 'update inv_monthsum ism' ||
             '   set (ism.qty_in, ISM.QTY_OUT, ISM.AMOUNT_IN, ISM.AMOUNT_OUT)' ||
             '     = (select IMM2.qty_in, IMM2.QTY_OUT, IMM2.AMOUNT_IN, IMM2.AMOUNT_OUT' ||
             '          FROM ' || Str_Tcltable_Tmp || ' IMM2' ||
             '         where ISM.WAREHOUSE_ID = IMM2.WAREHOUSE_ID' ||
             '           AND ISM.Inv_Batch_Id = IMM2.Inv_Batch_Id' ||
             '           AND ISM.ITEM_ID = IMM2.ITEM_ID' ||
             '           AND IMM2.ORGANIZATION_ID =' || Int_Organization_Id ||
             '           and IMM2.YEAR_MONTH =''' || Str_Currmonth || ''')' ||
             '   where ism.organization_id = ' || Int_Organization_Id ||
             '     and ism.year_month = ''' || Str_Currmonth || '''' ||
             '     and exists (select 1 from ' || Str_Tcltable_Tmp || ' IMM2' ||
             '         where ISM.WAREHOUSE_ID = IMM2.WAREHOUSE_ID' ||
             '           AND ISM.Inv_Batch_Id = IMM2.Inv_Batch_Id' ||
             '           AND ISM.ITEM_ID = IMM2.ITEM_ID' ||
             '           AND IMM2.ORGANIZATION_ID =' || Int_Organization_Id ||
             '           and IMM2.YEAR_MONTH =''' || Str_Currmonth || ''')';
  Execute Immediate Str_Sql;
  Commit;

  --从新计算本期结存量、本位币本期入库价格（未税）、本位币本期出库价格（未税）
  Update /*+ parallel(ISM) */ Inv_Monthsum Ism
     Set Ism.Qty_Blnc  = Ism.Qty_Lm + Ism.Qty_In - Ism.Qty_Out,
         Ism.Price_In  = Decode(Ism.Qty_In,
                                0,
                                0,
                                Round(Ism.Amount_In / Ism.Qty_In, 8)),
         Ism.Price_Out = Decode(Ism.Qty_Out,
                                0,
                                0,
                                Round(Ism.Amount_Out / Ism.Qty_Out, 8))
   Where Ism.Organization_Id = Int_Organization_Id
     And Ism.Year_Month = Str_Currmonth;
  Commit;

  /*--从新计算再价格表中存在价格的本位币本期结存价格（未税）、本位币本期结存金额（未税）
  Update Inv_Monthsum Ism
  Set    (Ism.Price_Blnc, Ism.Amount_Blnc) = (Select Stk.Price,
                                                     Round(Stk.Price *
                                                           Ism.Qty_Blnc,
                                                           2) As Amount_Blnc
                                              From   Inv_Item_Stk_Price Stk
                                              Where  Stk.Organization_Id =
                                                     Int_Organization_Id
                                              And    Stk.Year_Month =
                                                     Str_Currmonth
                                              And    Stk.Item_Id =
                                                     Ism.Item_Id)
  Where  Ism.Organization_Id = Int_Organization_Id
  And    Ism.Year_Month = Str_Currmonth
  And    Exists
   (Select 1
          From   Inv_Item_Stk_Price Stk
          Where  Stk.Organization_Id = Int_Organization_Id
          And    Stk.Year_Month = Str_Currmonth
          And    Stk.Item_Id = Ism.Item_Id);
  --提交本部结存
  Commit;
  */
  --modify by zks 060515 结存金额=上月结存金额+本月入库金额-本月出库金额。 结存单价=round(结存金额/结存数量,6)
  Update Inv_Monthsum Ism
     Set Ism.Amount_Blnc = Ism.Amount_Lm + Ism.Amount_In - Ism.Amount_Out,
         Ism.Price_Blnc  = Decode(Ism.Qty_Blnc,
                                  0,
                                  0,
                                  Round((Ism.Amount_Lm + Ism.Amount_In - Ism.Amount_Out) / Ism.Qty_Blnc, 8))
   Where Ism.Organization_Id = Int_Organization_Id
     And Ism.Year_Month = Str_Currmonth;
  Commit;

  Update Inv_Param Ipm
     Set Ipm.Param_Value = Str_Monthdealwith
   Where Ipm.Organization_Id = Int_Organization_Id
     And Ipm.Param_Code = 'INV_MONTH_DEALWITH';
  Commit;

  Select Count(*)
    Into Intcount
    From Tab
   Where Tname = Upper(Str_Tcltable_Tmp)
     And Tabtype = 'TABLE';
  If (Intcount > 0) Then
    Str_Sql := 'Drop table ' || Upper(Str_Tcltable_Tmp);
    Execute Immediate Str_Sql;
  End If;

  Select Count(*)
    Into Intcount
    From Tab
   Where Tname = Upper(Str_Vendortable_Tmpsum)
     And Tabtype = 'TABLE';
  If Intcount > 0 Then
    Str_Sql := 'Drop table ' || Upper(Str_Vendortable_Tmpsum);
    Execute Immediate Str_Sql;
  End If;

  Select Count(*)
    Into Intcount
    From Tab
   Where Tname = Upper(Str_Vendortable_Tmpinv)
     And Tabtype = 'TABLE';
  If Intcount > 0 Then
    Str_Sql := 'Drop table ' || Upper(Str_Vendortable_Tmpinv);
    Execute Immediate Str_Sql;
  End If;

End;
/

