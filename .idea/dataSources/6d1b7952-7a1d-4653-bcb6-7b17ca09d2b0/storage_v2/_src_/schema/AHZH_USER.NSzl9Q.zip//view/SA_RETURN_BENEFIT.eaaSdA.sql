create view SA_RETURN_BENEFIT as
select sh.sa_return_benefit_h_id as sa_return_benefit_id,
       sh.organization_id,
       sh.filiale_id,
       sh.sa_return_no,
       sh.bill_date,
       sh.base_currency_id,
       sh.customer_id,
       sh.year_month,
       sh.return_amount,
       sl.fee_type,
       sl.base_return_type_id,
       sh.stat,
       sl.remark
  from sa_return_benefit_h sh, sa_return_benefit_l sl
 where sh.sa_return_benefit_h_id = sl.sa_return_benefit_h_id
/

