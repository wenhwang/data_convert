create PACKAGE BODY           cux_oa_org_pkg IS
  /*==================================================
  Copyright (C) Jugend Co.,Ltd.
             AllRights Reserved
  ==================================================*/
  /*=============================================
  FUNCTION  Name:
      get_org_path
  Description:
      获取组织路径
  Argument:

  Return:

  History:
      1.00  2016-07-07 OA    Creation
  =============================================*/
  FUNCTION get_org_path(p_idpath IN VARCHAR2) RETURN VARCHAR2 IS
    lv_orgid_val   VARCHAR2(500);
    lv_orgname_val VARCHAR2(500);
    lv_org_path    VARCHAR2(500);
    lv_split_str   VARCHAR2(3) := '/';

    CURSOR csr_id_path(c_idpath IN VARCHAR2) IS
      SELECT regexp_substr(c_idpath, '[^\]+', 1, rownum) id_val
        FROM dual
      CONNECT BY rownum <= length(c_idpath) - length(REPLACE(c_idpath, '\', '')) + 1;

  BEGIN
    IF p_idpath IS NULL
       OR TRIM(p_idpath) IS NULL THEN
      RETURN NULL;
    ELSE
      FOR rec_id_path IN csr_id_path(p_idpath) LOOP
        -- 分割组织ID
        lv_orgid_val   := rec_id_path.id_val;
        lv_orgname_val := '';

        -- 排除-16
        IF lv_orgid_val IS NOT NULL
           AND TRIM(lv_orgid_val) IS NOT NULL
           AND lv_orgid_val NOT IN (-16) THEN
          -- 获取ID对应的名称
          BEGIN
            SELECT cg.orgname INTO lv_orgname_val FROM cpcorg cg WHERE cg.orgid = lv_orgid_val;
          EXCEPTION
            WHEN OTHERS THEN
              lv_orgname_val := '';
              -- 如果ID不存在，是否直接退出？
              lv_org_path := NULL;
              EXIT;
          END;

          -- 拼接组织路径
          IF lv_orgname_val IS NOT NULL
             AND TRIM(lv_orgname_val) IS NOT NULL THEN
            IF lv_org_path IS NULL THEN
              lv_org_path := lv_orgname_val;
            ELSE
              lv_org_path := lv_org_path || lv_split_str || lv_orgname_val;
            END IF;
          END IF;
        END IF;
      END LOOP;
    END IF;

    RETURN lv_org_path;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END get_org_path;

  /*=============================================
  FUNCTION  Name:
      get_user_orgpath
  Description:
      获取用户组织路径
  Argument:

  Return:

  History:
      1.00  2016-07-07 OA    Creation
  =============================================*/
  FUNCTION get_user_orgpath(p_sysuserid IN NUMBER) RETURN VARCHAR2 IS
    lv_user_orgpath VARCHAR2(500);
    lv_split_str    VARCHAR2(3) := ',';
    lv_org_path     VARCHAR2(500);
    CURSOR csr_user_orgpath(c_sysuserid IN NUMBER) IS
      SELECT substr(t.idpath,7) idpath
        FROM cpcorg     t,
             cpcorguser u0
       WHERE t.orgid = u0.orgid
         AND u0.sysuserid = c_sysuserid order by t.orgid;

  BEGIN
    IF p_sysuserid IS NULL THEN
      RETURN NULL;
    END IF;

    FOR rec_user_orgpath IN csr_user_orgpath(p_sysuserid) LOOP
      lv_org_path := get_org_path(rec_user_orgpath.idpath);
      IF lv_org_path IS NOT NULL
         AND TRIM(lv_org_path) IS NOT NULL THEN
        IF lv_user_orgpath IS NULL THEN
          lv_user_orgpath := lv_org_path;
        ELSE
          lv_user_orgpath := lv_user_orgpath || lv_split_str || lv_org_path;
        END IF;
      END IF;
    END LOOP;

    RETURN lv_user_orgpath;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END get_user_orgpath;

  /*=============================================
  FUNCTION  Name:
      get_user_positions
  Description:
      获取用户职位
  Argument:

  Return:

  History:
      1.00  2016-07-07 OA    Creation
  =============================================*/
  FUNCTION get_user_positions(p_sysuserid IN NUMBER) RETURN VARCHAR2 IS
    lv_user_positions VARCHAR2(500);
    lv_split_str    VARCHAR2(3) := ',';
    lv_user_position     VARCHAR2(100);
    CURSOR csr_user_positions(c_sysuserid IN NUMBER) IS
      select positionid from cpcorgposition where sysuserid = c_sysuserid;

  BEGIN
    IF p_sysuserid IS NULL THEN
      RETURN NULL;
    END IF;

    FOR rec_user_positions IN csr_user_positions(p_sysuserid) LOOP
      lv_user_position := rec_user_positions.positionid;
      IF lv_user_position IS NOT NULL
         AND TRIM(lv_user_position) IS NOT NULL THEN
        IF lv_user_positions IS NULL THEN
          lv_user_positions := lv_user_position;
        ELSE
          lv_user_positions := lv_user_positions || lv_split_str || lv_user_position;
        END IF;
      END IF;
    END LOOP;

    RETURN lv_user_positions;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END get_user_positions;

  /*=============================================
  FUNCTION  Name:
      get_user_orgids
  Description:
      获取用户机构ids
  Argument:

  Return:

  History:
      1.00  2016-07-07 OA    Creation
  =============================================*/
  FUNCTION get_user_orgids(p_sysuserid IN NUMBER) RETURN VARCHAR2 IS
    lv_orgid VARCHAR2(500);
    lv_split_str    VARCHAR2(3) := ',';
    lv_orgids     VARCHAR2(500);
    CURSOR csr_user_orgids(p_sysuserid IN NUMBER) IS
      SELECT t.orgid
        FROM cpcorg     t,
             cpcorguser u0
       WHERE t.orgid = u0.orgid
         AND u0.sysuserid = p_sysuserid order by t.orgid;

  BEGIN
    IF p_sysuserid IS NULL THEN
      RETURN NULL;
    END IF;

    FOR rec_user_orgids IN csr_user_orgids(p_sysuserid) LOOP
      lv_orgid := rec_user_orgids.orgid;
      IF lv_orgid IS NOT NULL
         AND TRIM(lv_orgid) IS NOT NULL THEN
        IF lv_orgids IS NULL THEN
          lv_orgids := lv_orgid;
        ELSE
          lv_orgids := lv_orgids || lv_split_str || lv_orgid;
        END IF;
      END IF;
    END LOOP;

    RETURN lv_orgids;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END get_user_orgids;
END cux_oa_org_pkg;
/

