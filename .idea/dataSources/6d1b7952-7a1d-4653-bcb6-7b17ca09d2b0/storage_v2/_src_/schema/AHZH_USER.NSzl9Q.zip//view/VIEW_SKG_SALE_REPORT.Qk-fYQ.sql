create view VIEW_SKG_SALE_REPORT as
select iobh.organization_id,
      -- iobh.customer_id,
      -- iobh.year_month,
       ct.customer_code as item_class_name,
      -- ct.customer_name ,
        item.specs,
       iobl.item_id,
       item.item_code,
       item.item_name,
       sum(iobl.qty_bill) as qty_bill,99999999999 amount_bill,99999999999 as saledays,
       99999999999 saleinvrate,99999999999 sale7dayqty,99999999999 sale14dayqty,
       99999999999 replenishment7day,99999999999 replenishment14day/*,
       fn_skg_getmonthsaleqty(iobh.organization_id,
                              iobh.customer_id,
                              iobl.item_id,
                              iobh.year_month) as monthsaleqty,
       decode(fn_skg_getmonthsaleqty(iobh.organization_id,
                                     iobh.customer_id,
                                     iobl.item_id,
                                     iobh.year_month),
              0,
              0,
              round(sum(iobl.qty_bill) /
                    fn_skg_getmonthsaleqty(iobh.organization_id,
                                           iobh.customer_id,
                                           iobl.item_id,
                                           iobh.year_month),
                    2)) as planqty*/
  from inv_out_bill_head iobh, inv_out_bill_line iobl, customer ct, item
 where iobh.inv_out_bill_head_id = iobl.inv_out_bill_head_id
   and iobh.organization_id=1
   and iobh.customer_id = ct.customer_id
   and iobl.item_id = item.item_id
   and to_char(iobh.date_invbill, 'YYYY-MM') = to_char(sysdate,'yyyy-mm')
 group by iobh.organization_id,
          --iobh.customer_id,
          --iobh.year_month,
          ct.customer_code,
          item.specs,
          iobl.item_id,
          item.item_code,
          item.item_name
/

