create view VIEW_BCS_CORP as
Select Entid Corp_Id,
       Entname Corp_Name,
       Ent_Type Corp_Type,
       Set_Of_Books_Id,
       Set_Of_Books_Name,
       0 Pcorp_Id,
       Isdisabled,
       2 Is_Valid,
       2 Scanbc_Control,
       Creator,
       Createtime,
       Updator,
       Updatetime,
       Creator Created_By,
       Createtime Creation_Date,
       Updator Last_Updated_By,
       Updatetime Last_Update_Date
From   Cpcent
/

