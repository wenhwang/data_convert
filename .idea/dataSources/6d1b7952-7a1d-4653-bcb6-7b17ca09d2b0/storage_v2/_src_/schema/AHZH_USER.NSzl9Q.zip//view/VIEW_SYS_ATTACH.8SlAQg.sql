create view VIEW_SYS_ATTACH as
    SELECT OBJTYPE,
       UPPER(OBJNAME) OBJNAME,
       BILLNAME,
       OBJID,
       ATTACH.DOCID,
       DOCNAME,
       CRC32,
       'http://epms.zhonghui365.com:8082/downloadfile.do?docid=' || ATTACH.DOCID ||
       '&crc32=' || CRC32 URL
  FROM (

        SELECT 'BASE01' OBJTYPE, OBJNAME, '客户资料' BILLNAME, OBJID, DOCID
          FROM ERPOBJATTACH
         WHERE UPPER(OBJNAME) = 'CUSTOMER_ORG'

        UNION ALL

        SELECT 'BASE02' OBJTYPE, OBJNAME, '供应商资料' BILLNAME, OBJID, DOCID
          FROM ERPOBJATTACH
         WHERE UPPER(OBJNAME) = 'VENDOR_ORG'

        UNION ALL

        --财务管理--------------------------------------------------------------------------
        SELECT 'FIN01' OBJTYPE, OBJNAME, '回款单' BILLNAME, OBJID, DOCID
          FROM ERPOBJATTACH
         WHERE UPPER(OBJNAME) = 'FIN_RECEIPT_VOUCHER'

        UNION ALL

        --行政管理--------------------------------------------------------------------------
        SELECT 'HR01' OBJTYPE, OBJNAME, '行政合同' BILLNAME, OBJID, DOCID
          FROM ERPOBJATTACH
         WHERE UPPER(OBJNAME) = 'HR_ADM_CONTRACT'

        UNION ALL

        --费用管理--------------------------------------------------------------------------
        SELECT 'MKT01' OBJTYPE, OBJNAME, '借款单' BILLNAME, OBJID, DOCID
          FROM ERPOBJATTACH
         WHERE UPPER(OBJNAME) = 'MKT_LOAN_HEADER'

        UNION ALL

        --供应链--------------------------------------------------------------------------
        SELECT 'PUR01' OBJTYPE, OBJNAME, '采购合同' BILLNAME, OBJID, DOCID
          FROM ERPOBJATTACH
         WHERE UPPER(OBJNAME) = 'PUR_CONTRACT_HEAD'

        UNION ALL

        SELECT 'PUR02' OBJTYPE,
               OBJNAME,
               '采购付款申请' BILLNAME,
               OBJID,
               DOCID
          FROM ERPOBJATTACH
         WHERE UPPER(OBJNAME) = 'PUR_PAYMENT_APPLY_HEAD'

        ) ATTACH,
       CPCDOC
 WHERE ATTACH.DOCID = CPCDOC.DOCID

UNION ALL

--工程管理--------------------------------------------------------------------------
SELECT OBJTYPE,
       OBJNAME,
       BILLNAME,
       OBJID,
       DOCID,
       DOCNAME,
       CRC32,
       URL
  FROM VIEW_PROJECT_ATTACH

/*********************************************\
   * NAME(名称): VIEW_SYS_ATTACH
   * PURPOSE(功能说明):  系统附件汇总
   * AUTHOR(作者): NY
   * CREATE AT(创建时间): 2019-10-16
\*********************************************/
/

