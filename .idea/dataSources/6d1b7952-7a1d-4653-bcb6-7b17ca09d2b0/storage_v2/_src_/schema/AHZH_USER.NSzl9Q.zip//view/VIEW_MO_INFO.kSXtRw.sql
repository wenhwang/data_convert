create view VIEW_MO_INFO as
SELECT DISTINCT MO.ORGANIZATION_ID,
                MO.MO_TYPE,
                MO.PRIMARY_ITEM_ID,
                MO.PRIMARY_ITEM_CODE,
                MO.PRIMARY_ITEM_NAME,
                MO.QTY_MO,
                MO.MOSTATUS,
                ML.ITEM_ID,
                ML.ITEM_CODE,
                ML.ITEM_NAME,
                ML.PM_CODE,
                NVL(MO.MOSTARTDATE, MO.MOENDDATE) MOSTARTDATE,
                NVL(MO.PREPARE_LDTIME, 0) PREPARE_LDTIME,
                NVL(ML.QC_LDTIME, 0) QC_LDTIME,
                (NVL(MO.MOSTARTDATE, MO.MOENDDATE) -
                NVL(MO.PREPARE_LDTIME, 0) - NVL(ML.QC_LDTIME, 0)) NEED_DATE,
                ML.MOCTRLQTY,
                ML.MOREALQTY,
                ML.MOCTRLQTY - ML.MOREALQTY SHORT_QTY,
                MO.CREATION_DATE,
                MO.LAST_UPDATE_DATE,
                MO.REMARK,
                MO.MONO,
                MO.INV_BATCH_ID,
                MO.INV_BATCH_CODE,
                MO.INV_BATCH_NAME
  FROM (SELECT M.          *,
               NVL(PREPARE_LDTIME, 0)         PREPARE_LDTIME,
               I.ITEM_ID   PRIMARY_ITEM_ID,
               I.ITEM_CODE PRIMARY_ITEM_CODE,
               I.ITEM_NAME PRIMARY_ITEM_NAME,
               IB.INV_BATCH_CODE,IB.INV_BATCH_NAME
          FROM MES_MO M, ITEM_ORG IO, ITEM I,INV_BATCH IB
         WHERE M.ORGANIZATION_ID = IO.ORGANIZATION_ID AND
               M.ITEM_ID = IO.ITEM_ID AND IO.ITEM_ID = I.ITEM_ID
               AND M.INV_BATCH_ID=IB.INV_BATCH_ID) MO,
       (SELECT M. *,
               NVL(QC_LDTIME, 0) QC_LDTIME,
               IO.PM_CODE,
               I.ITEM_CODE,
               I.ITEM_NAME
          FROM MNITEMLIST M, ITEM_ORG IO, ITEM I
         WHERE M.ORGANIZATION_ID = IO.ORGANIZATION_ID AND
               M.ITEM_ID = IO.ITEM_ID AND IO.ITEM_ID = I.ITEM_ID) ML
 WHERE MO.MES_MO_ID = ML.MES_MO_ID AND
       MO.ORGANIZATION_ID = ML.ORGANIZATION_ID
/

