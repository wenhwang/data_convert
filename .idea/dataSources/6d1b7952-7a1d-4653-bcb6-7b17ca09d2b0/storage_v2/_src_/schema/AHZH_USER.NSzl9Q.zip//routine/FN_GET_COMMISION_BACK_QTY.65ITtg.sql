create Function           Fn_Get_Commision_Back_Qty(p_Sa_Out_Bill_Line_Id Number)
  Return Number Is
  Result Number;
  --取得委托代销出库已做委托代销退货的数量
  --Sa_Saleorder_Line_Id保存着委托代销开单Sa_Out_Bill_Line_Id
Begin
  Select Nvl(Sum(Sobl.Qty_Bill), 0)
    Into Result
    From Sa_Out_Bill_Line Sobl, Sa_Out_Bill_Head Sobh
   Where Sobl.Sa_Out_Bill_Head_Id = Sobh.Sa_Out_Bill_Head_Id
     And Sobh.Stat = 5
     And Sobh.Is_Auditing_Wh = 2
     And Sobl.Sa_Saleorder_Line_Id = p_Sa_Out_Bill_Line_Id;
  Return Nvl(Result, 0);
End Fn_Get_Commision_Back_Qty;
/

