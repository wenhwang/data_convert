create view ERPEMPLOYEE_ORG as
select distinct a.sysuserid  as EMPLOYEE_ID,
       a.userid     as EMPLOYEE_CODE,
       a.username   as EMPLOYEE_NAME,
       a.Telo,
       a.Mobil,
       a.creator    as CREATED_BY,
       a.createtime as CREATION_DATE,
       (select cu.orgid from cpcorguser cu where cu.sysuserid=a.sysuserid and cu.isdefault=2 and rownum=1 ) as dept_id,
       a.actived
  from cpcuser a, cpcorguser b
 where a.sysuserid  = b.sysuserid (+)
/

