create view VIEW_SECURITY as
SELECT "PROJECT_CODE","PROJECT_NAME","BID_SECURITY","BID_SECURITY_END_DATE"   FROM (SELECT PROJECT_CODE,
                       PROJECT_NAME,
                       BID_SECURITY,
                       BID_SECURITY_END_DATE
                  FROM EPM_PROJECT_BID_HEAD HEAD, EPM_PROJECT
                 WHERE HEAD.PROJECT_ID = EPM_PROJECT.PROJECT_ID
                   AND HEAD.STAT = 5)  WHERE 1 = 1
/*********************************************\
  * NAME(名称): VIEW_SECURITY
  * PURPOSE(功能说明):  钉钉智能报表-保证金明细
                                    取自项目评审
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-11-14
  \*********************************************/
/

