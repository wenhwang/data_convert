create view VIEW_CUST_EMP_CRMENTID as
select distinct c.customer_code,
                c.customer_name,
                t.saleprice_type_code,
                t.saleprice_type_name,
                b.SALE_EMPLOYEE_CODE,
                b.SALE_EMPLOYEE_NAME,
                dd.dept_code,
                dd.DEPT_NAME,
                dtt.dictname,
                co.organization_id
  from customer c,
       customer_org co,
       customer_saleprice s,
       sa_saleprice_type t,
       base_view_sale_employee b,
       dept dd,
       (select d.dictname, d.dictvalue,d.entid
          from cpcdict d
         where d.dictcode like '%crm_entid%'
           and d.entid = 16) dtt
 where c.customer_id = co.customer_id
   and c.customer_id = s.customer_id
   and s.sa_saleprice_type_id = t.sa_saleprice_type_id(+)
   and s.sale_employee_id = b.SALE_EMPLOYEE_ID(+)
   and s.dept_id = dd.dept_id(+)
   and s.crm_entid = dtt.dictvalue(+)
/

