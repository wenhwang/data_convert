create Procedure           Usp_Reexccurqty(Int_Organization_Id Number) As
  --以明细单据数据重新计算库存第一步
  --建立明细表
  --zhuzhongfu
  --2004.12.08
  Str_Currmonth    Varchar2(7);
  Str_Tmpcurrmonth Varchar2(7);
  --Modified By: zks
  --Modified Date: 2006-04-11
  --在计算计划库存之前把全部计划库存清为0 .

  --Modified By: zks
  --Modified Date: 2006-03-06
  --Description: 1.重算库存中去掉备件和外租仓的业务
  --             2.加上库存组织区分数据.
  --             3.加上批次ID,仓库从出入库表体中取.
  --             4.更新库存前保留计划库存,更新库存后更新计划库存

Begin
  -- Int_ORGANIZATION_ID := 1;  ---传入组织id

  -- 写正在算库存的标志 是
  Update Inv_Param
     Set Param_Value = 2
   Where Param_Code = 'INVEXECUTING'
     And Organization_Id = Int_Organization_Id;
  --算当前期间库存
  /*
  drop table  TMPCIV1
  create table Tmpciv3 (
         ORGANIZATION_ID NUMBER not null,
         WAREHOUSE_ID    NUMBER not null,
         ITEM_ID         NUMBER not null,
         INV_BATCH_ID    NUMBER not null,
         QTY_PLAN        NUMBER(20,8) not null,
     Qty_Lm  NUMBER(20,8) not null,
     Qty_In  NUMBER(20,8) not null,
     Qty_Out  NUMBER(20,8) not null,
     Qty_Blnc  NUMBER(20,8) not null)
  */
  delete from tmpciv1 where Organization_Id = Int_Organization_Id;
  -- 汇总
  delete from tmpciv2 where Organization_Id = Int_Organization_Id;
  --计算计划库存用的临时表tmpciv3.
  delete from tmpciv3 where Organization_Id = Int_Organization_Id;
  --dgj 2014.01.06 CCS没有用到计划库存，则重算库存很慢，故暂时屏蔽
  /*  Execute Immediate 'delete from tmpciv4 where Organization_Id =' ||
  Int_Organization_Id;*/

  commit;
  --取上个月份
  Select To_Char(To_Date(max(Gd.Year_Month) || '-01', 'yyyy-mm-dd') - 1,
                 'yyyy-mm')
    Into Str_Currmonth
    From Gl_Account_Period Gd
   Where Gd.Organization_Id = Int_Organization_Id
     And Gd.Is_Current_Period_Inv = 2;

  --插入期初结存数据
  Insert Into Tmpciv1
    (Organization_Id,
     Warehouse_Id,
     Inv_Batch_Id,
     Item_Id,
     Qty_Lm,
     Qty_In,
     Qty_Out,
     Qty_Blnc)
    Select Int_Organization_Id,
           Warehouse_Id,
           Inv_Batch_Id,
           Item_Id,
           Qty_Blnc,
           0,
           0,
           0
      From Inv_Monthsum Ims
     Where Ims.Year_Month = Str_Currmonth
       And Ims.Organization_Id = Int_Organization_Id
       And Ims.Qty_Blnc <> 0;

  --取存货期间
  Select max(Gd.Year_Month)
    Into Str_Currmonth
    From Gl_Account_Period Gd
   Where Gd.Organization_Id = Int_Organization_Id
     And Gd.Is_Current_Period_Inv = 2;

  --插入入库数据
  Insert Into Tmpciv1
    (Organization_Id,
     Warehouse_Id,
     Inv_Batch_Id,
     Item_Id,
     Qty_Lm,
     Qty_In,
     Qty_Out,
     Qty_Blnc)
    Select Int_Organization_Id,
           Ibl.Warehouse_Id,
           Ibl.Inv_Batch_Id,
           Ibl.Item_Id,
           0,
           Sum(Ibl.Qty_Invbill) As Qty_Invbill,
           0,
           0
      From Inv_In_Bill_Line Ibl, Inv_In_Bill_Head Ibh
     Where Ibl.Inv_In_Bill_Head_Id = Ibh.Inv_In_Bill_Head_Id
       And Ibh.Is_Auditing_Wh = 2
       And ibh.Is_Init_Bill <> 2
       And Ibh.Year_Month = Str_Currmonth
       And Ibh.Organization_Id = Int_Organization_Id
     Group By Ibl.Warehouse_Id, Ibl.Inv_Batch_Id, Ibl.Item_Id;

  --插入出库数据
  Insert Into Tmpciv1
    (Organization_Id,
     Warehouse_Id,
     Inv_Batch_Id,
     Item_Id,
     Qty_Lm,
     Qty_In,
     Qty_Out,
     Qty_Blnc)
    Select Int_Organization_Id,
           Ibl.Warehouse_Id,
           Ibl.Inv_Batch_Id,
           Ibl.Item_Id,
           0,
           0,
           Sum(Ibl.Qty_Bill) As Qty_Invbill,
           0
      From Inv_Out_Bill_Line Ibl, Inv_Out_Bill_Head Ibh
     Where Ibl.Inv_Out_Bill_Head_Id = Ibh.Inv_Out_Bill_Head_Id
       And Ibh.Is_Auditing_Wh = 2
       And ibh.Is_Init_Bill <> 2
       And Ibh.Year_Month = Str_Currmonth
       And Ibh.Organization_Id = Int_Organization_Id
     Group By Ibl.Warehouse_Id, Ibl.Inv_Batch_Id, Ibl.Item_Id;

  --汇总结存数据
  Insert Into Tmpciv2
    (Organization_Id,
     Warehouse_Id,
     Inv_Batch_Id,
     Item_Id,
     Qty_Lm,
     Qty_In,
     Qty_Out,
     Qty_Blnc)
    Select Int_Organization_Id,
           t.Warehouse_Id,
           t.Inv_Batch_Id,
           t.Item_Id,
           Sum(t.Qty_Lm),
           Sum(t.Qty_In),
           Sum(t.Qty_Out),
           Sum(t.Qty_Lm + t.Qty_In - t.Qty_Out)
      From Tmpciv1 t
     Where t.Organization_Id = Int_Organization_Id
     Group By t.Warehouse_Id, t.Inv_Batch_Id, t.Item_Id;

  --更新库存前保留计划库存TmpInv_Currentperiod_Inv,更新库存后更新计划库存
  delete from TmpInv_Currentperiod_Inv
   where Organization_Id = Int_Organization_Id;

  Insert Into Tmpinv_Currentperiod_Inv
    Select *
      From Inv_Currentperiod_Inv Ici
     Where Ici.Organization_Id = Int_Organization_Id;

  Delete Inv_Currentperiod_Inv Iv
   Where Iv.Organization_Id = Int_Organization_Id;

  --更新库存并更新计划库存
  Insert Into Inv_Currentperiod_Inv
    (Organization_Id,
     Warehouse_Id,
     Inv_Batch_Id,
     Item_Id,
     Qty_Onhand,
     Qty_Plan)
    Select Int_Organization_Id,
           T2.Warehouse_Id,
           T2.Inv_Batch_Id,
           T2.Item_Id,
           Sum(T2.Qty_Blnc) Qty_Blnc,
           Sum(Nvl(T3.Qty_Plan, 0)) Qty_Plan
      From Tmpciv2 T2, Tmpinv_Currentperiod_Inv T3
     Where T2.Organization_Id = T3.Organization_Id(+)
       And T2.Warehouse_Id = T3.Warehouse_Id(+)
       And T2.Inv_Batch_Id = T3.Inv_Batch_Id(+)
       And T2.Item_Id = T3.Item_Id(+)
       And T2.Organization_Id = Int_Organization_Id
     Group By T2.Warehouse_Id, T2.Inv_Batch_Id, T2.Item_Id;
  --插入临时表(Tmpinv_Currentperiod_Inv)中存在但Inv_Currentperiod_Inv不存在的记录(计划库存)
  Insert Into Inv_Currentperiod_Inv
    (Organization_Id,
     Warehouse_Id,
     Inv_Batch_Id,
     Item_Id,
     Qty_Onhand,
     Qty_Plan)
    Select Int_Organization_Id,
           T3.Warehouse_Id,
           T3.Inv_Batch_Id,
           T3.Item_Id,
           Sum(Nvl(T2.Qty_Onhand, 0)) Qty_Onhand,
           Sum(Nvl(T3.Qty_Plan, 0)) Qty_Plan
      From Inv_Currentperiod_Inv T2, Tmpinv_Currentperiod_Inv T3
     Where T3.Organization_Id = T2.Organization_Id(+)
       And T3.Warehouse_Id = T2.Warehouse_Id(+)
       And T3.Inv_Batch_Id = T2.Inv_Batch_Id(+)
       And T3.Item_Id = T2.Item_Id(+)
       And T2.Item_Id Is Null
       And T3.Organization_Id = Int_Organization_Id
     Group By T3.Warehouse_Id, T3.Inv_Batch_Id, T3.Item_Id;
  Commit;
  ---把计划库存清为0
  --dgj 2014.01.06 CCS没有用到计划库存，则重算库存很慢，故暂时屏蔽
  /*  Update Inv_Currentperiod_Inv Icpi
     Set Icpi.Qty_Plan = 0
   Where Icpi.Organization_Id = Int_Organization_Id;
  Commit;*/
  --- 1.1增加更新计划库存:(如果物料是可销售,把当前库存写计划库存)
  --dgj 2014.01.06 CCS没有用到计划库存，则重算库存很慢，故暂时屏蔽
  /*  Update Inv_Currentperiod_Inv Icpi
     Set Icpi.Qty_Plan = Icpi.Qty_Onhand
   Where Exists (Select 1
            From Base_View_Item_Org Ii
           Where Ii.Item_Id = Icpi.Item_Id
             And Ii.Can_Sale = 2
             and Ii.Organization_Id = Int_Organization_Id)
     And Icpi.Organization_Id = Int_Organization_Id;
  Commit;*/

  --1.2把当前会计存货期间月份的销售发货通知的数据写入Tmpciv3
  Insert Into Tmpciv3
    (Organization_Id, Warehouse_Id, Item_Id, Inv_Batch_Id, Qty_Plan)
    Select Tmp.Organization_Id,
           Tmp.Warehouse_Id,
           Tmp.Item_Id,
           Tmp.Inv_Batch_Id,
           Sum(Nvl(Qty, 0)) Qty
      From (Select Sobh.Organization_Id Organization_Id,
                   Sobl.Warehouse_Id Warehouse_Id,
                   Sobl.Item_Id Item_Id,
                   0 Inv_Batch_Id,
                   Sobl.Qty_Bill - Sobl.Audit_Qty Qty
              From Sa_Out_Bill_Line Sobl, Sa_Out_Bill_Head Sobh
             Where Sobh.Sa_Out_Bill_Head_Id = Sobl.Sa_Out_Bill_Head_Id
               And Sobh.Is_Auditing_Wh = 2
               And Sobh.Bill_Stats = 1
               And Sobh.Year_Month = Str_Currmonth
               And Sobh.Organization_Id = Int_Organization_Id
            Union All
            Select Cobh.Organization_Id Organization_Id,
                   Cobl.Warehouse_Id Warehouse_Id,
                   Cobl.Item_Id Item_Id,
                   0 Inv_Batch_Id,
                   Cobl.Qty_Bill - Cobl.Audit_Qty Qty
              From Css_Out_Bill_Line Cobl, Css_Out_Bill_Head Cobh
             Where Cobh.Css_Out_Bill_Head_Id = Cobl.Css_Out_Bill_Head_Id
               And Cobh.Is_Auditing_Wh = 2
               And Cobh.Organization_Id = Int_Organization_Id
               And Cobh.Year_Month = Str_Currmonth
               And Cobh.Bill_Stats = 1) Tmp
     Group By Tmp.Organization_Id,
              Tmp.Warehouse_Id,
              Tmp.Item_Id,
              Tmp.Inv_Batch_Id;
  Commit;

  --1.3 计划库存-
  --dgj 2014.01.06 CCS没有用到计划库存，则重算库存很慢，故暂时屏蔽
  /*  Execute Immediate 'Update Inv_Currentperiod_Inv Icpi ' ||
                      '   Set Icpi.Qty_Plan = Nvl(Icpi.Qty_Plan, 0) -' ||
                      '       (Select Aa.Qty_Plan' ||
                      '        From   Tmpciv3 Aa' ||
                      '        Where  Icpi.Organization_Id = Aa.Organization_Id' ||
                      '        And    Icpi.Warehouse_Id = Aa.Warehouse_Id' ||
                      '        And    Icpi.Item_Id = Aa.Item_Id' ||
                      '        And    Icpi.Inv_Batch_Id = Aa.Inv_Batch_Id' ||
                      '        And    Icpi.Organization_Id =' ||
                      Int_Organization_Id || ')' ||
                      ' Where  Exists (Select 1' ||
                      '         From   Tmpciv3 Aa' ||
                      '         Where  Icpi.Organization_Id = Aa.Organization_Id' ||
                      '         And    Icpi.Warehouse_Id = Aa.Warehouse_Id' ||
                      '         And    Icpi.Item_Id = Aa.Item_Id' ||
                      '         And    Icpi.Inv_Batch_Id = Aa.Inv_Batch_Id' ||
                      '         And    Icpi.Organization_Id = ' ||
                      Int_Organization_Id || ')' ||
                      '  And    Exists (Select 1' ||
                      '         From   Base_View_Item_Org Ii' ||
                      '         Where  Ii.Item_Id = Icpi.Item_Id' ||
                      '         And    Ii.Can_Sale = 2)';
    Commit;
  */
  --取出入库及发货通知单上最大的月份
  Select Max(Year_Month)
    Into Str_Tmpcurrmonth
    From Inv_In_Bill_Head
   Where Is_Auditing_Wh = 2
     And Organization_Id = Int_Organization_Id;
  If (Str_Tmpcurrmonth) <= Str_Currmonth Then
    Select Max(Year_Month)
      Into Str_Tmpcurrmonth
      From Inv_Out_Bill_Head
     Where Is_Auditing_Wh = 2
       And Organization_Id = Int_Organization_Id;
  End If;

  If (Str_Tmpcurrmonth) <= Str_Currmonth Then
    Select Max(Year_Month)
      Into Str_Tmpcurrmonth
      From Sa_Out_Bill_Head
     Where Is_Auditing_Wh = 2
       And Organization_Id = Int_Organization_Id;
  End If;

  If (Str_Tmpcurrmonth) <= Str_Currmonth Then
    Select Max(Year_Month)
      Into Str_Tmpcurrmonth
      From Css_Out_Bill_Head
     Where Is_Auditing_Wh = 2
       And Organization_Id = Int_Organization_Id;
  End If;

  If (Str_Tmpcurrmonth > Str_Currmonth) Then
    --出入库单据中最大的月份 > 当前会计存货期间月份
    --追加插入大于当前存货期间入库数据
    Insert Into Tmpciv1
      Select Int_Organization_Id,
             Ibl.Warehouse_Id,
             Ibl.Inv_Batch_Id,
             Ibl.Item_Id,
             0,
             Sum(Ibl.Qty_Invbill) As Qty_Invbill,
             0,
             0
        From Inv_In_Bill_Line Ibl, Inv_In_Bill_Head Ibh
       Where Ibl.Inv_In_Bill_Head_Id = Ibh.Inv_In_Bill_Head_Id
         And Ibh.Is_Auditing_Wh = 2
         And Ibh.Year_Month > Str_Currmonth
         And Ibh.Organization_Id = Int_Organization_Id
       Group By Ibl.Warehouse_Id, Ibl.Inv_Batch_Id, Ibl.Item_Id;
    commit;
    --追加插入大于当前存货期间出库数据
    Insert Into Tmpciv1
      Select Int_Organization_Id,
             Ibl.Warehouse_Id,
             Ibl.Inv_Batch_Id,
             Ibl.Item_Id,
             0,
             0,
             Sum(Ibl.Qty_Bill) As Qty_Invbill,
             0
        From Inv_Out_Bill_Line Ibl, Inv_Out_Bill_Head Ibh
       Where Ibl.Inv_Out_Bill_Head_Id = Ibh.Inv_Out_Bill_Head_Id
         And Ibh.Is_Auditing_Wh = 2
         And Ibh.Year_Month > Str_Currmonth
         And Ibh.Organization_Id = Int_Organization_Id
       Group By Ibl.Warehouse_Id, Ibl.Inv_Batch_Id, Ibl.Item_Id;
    commit;

    Delete From Tmpciv2 Where Organization_Id = Int_Organization_Id;
    commit;

    --汇总结存数据( 大于等于当前存货期间的所有出入库数据）
    Insert Into Tmpciv2
      Select Int_Organization_Id,
             t.Warehouse_Id,
             t.Inv_Batch_Id,
             t.Item_Id,
             Sum(t.Qty_Lm),
             Sum(t.Qty_In),
             Sum(t.Qty_Out),
             Sum(t.Qty_Lm + t.Qty_In - t.Qty_Out)
        From Tmpciv1 t
       Where t.Organization_Id = Int_Organization_Id
       Group By t.Warehouse_Id, t.Inv_Batch_Id, t.Item_Id;
    commit;
    --更新库存前保留计划库存TmpInv_Current_Inv,更新库存后更新计划库存
    Execute Immediate 'delete from TmpInv_Current_Inv where Organization_Id =' ||
                      Int_Organization_Id;
    commit;

    Insert Into Tmpinv_Current_Inv
      Select organization_id,
             warehouse_id,
             item_id,
             inv_batch_id,
             qty_onhand,
             qty_plan
        From Inv_Current_Inv Ici
       Where Ici.Organization_Id = Int_Organization_Id;

    Delete Inv_Current_Inv Iv
     Where Iv.Organization_Id = Int_Organization_Id;

    --更新库存并更新计划库存
    Insert Into Inv_Current_Inv
      (Organization_Id,
       Warehouse_Id,
       Inv_Batch_Id,
       Item_Id,
       Qty_Onhand,
       Qty_Plan)
      Select Int_Organization_Id,
             T2.Warehouse_Id,
             T2.Inv_Batch_Id,
             T2.Item_Id,
             Sum(Nvl(T2.Qty_Blnc, 0)) Qty_Blnc,
             Sum(Nvl(T3.Qty_Plan, 0)) Qty_Plan
        From Tmpciv2 T2, Tmpinv_Current_Inv T3
       Where T2.Organization_Id = T3.Organization_Id(+)
         And T2.Warehouse_Id = T3.Warehouse_Id(+)
         And T2.Inv_Batch_Id = T3.Inv_Batch_Id(+)
         And T2.Item_Id = T3.Item_Id(+)
         And T2.Organization_Id = Int_Organization_Id
       Group By T2.Warehouse_Id, T2.Inv_Batch_Id, T2.Item_Id;

    --插入临时表(TmpInv_Current_Inv)中存在但Inv_Current_Inv不存在的记录(计划库存)
    Insert Into Inv_Current_Inv
      (Organization_Id,
       Warehouse_Id,
       Inv_Batch_Id,
       Item_Id,
       Qty_Onhand,
       Qty_Plan)
      Select Int_Organization_Id,
             T3.Warehouse_Id,
             T3.Inv_Batch_Id,
             T3.Item_Id,
             Sum(Nvl(T2.Qty_Onhand, 0)) Qty_Onhand,
             Sum(Nvl(T3.Qty_Plan, 0)) Qty_Plan
        From Inv_Current_Inv T2, Tmpinv_Current_Inv T3
       Where T3.Organization_Id = T2.Organization_Id(+)
         And T3.Warehouse_Id = T2.Warehouse_Id(+)
         And T3.Inv_Batch_Id = T2.Inv_Batch_Id(+)
         And T3.Item_Id = T2.Item_Id(+)
         And T2.Item_Id Is Null
         And T3.Organization_Id = Int_Organization_Id
       Group By T3.Warehouse_Id, T3.Inv_Batch_Id, T3.Item_Id;
    Commit;

    --- 增加更新计划库存
    --- 把计划库存清为0
    --dgj 2014.01.06 CCS没有用到计划库存，则重算库存很慢，故暂时屏蔽
    /*    Update Inv_Current_Inv Icpi Set Icpi.Qty_Plan = 0 where Icpi.Organization_Id = Int_Organization_Id;
    commit;*/
    --1.1. 用实际库存更新计划库存
    --dgj 2014.01.06 CCS没有用到计划库存，则重算库存很慢，故暂时屏蔽
    /*    Update Inv_Current_Inv Ici
       Set Ici.Qty_Plan = Ici.Qty_Onhand
     Where Exists (Select 1
              From Base_View_Item_Org Ii
             Where Ii.Item_Id = Ici.Item_Id
               And Ii.Can_Sale = 2)
       And Ici.Organization_Id = Int_Organization_Id;
    Commit;*/
    --1.2把销售发货通知单据中最大的月份 > 当前会计存货期间月份的销售发货通知的数据追加写入Tmpciv3
    Insert Into Tmpciv3
      (Organization_Id, Warehouse_Id, Item_Id, Inv_Batch_Id, Qty_Plan)
      Select Tmp.Organization_Id,
             Tmp.Warehouse_Id,
             Tmp.Item_Id,
             Tmp.Inv_Batch_Id,
             Sum(Nvl(Qty, 0)) Qty
        From (Select Sobh.Organization_Id,
                     Sobl.Warehouse_Id,
                     Sobl.Item_Id,
                     0 Inv_Batch_Id,
                     Sobl.Qty_Bill - Sobl.Audit_Qty Qty
                From Sa_Out_Bill_Line Sobl, Sa_Out_Bill_Head Sobh
               Where Sobh.Sa_Out_Bill_Head_Id = Sobl.Sa_Out_Bill_Head_Id
                 And Sobh.Is_Auditing_Wh = 2
                 And Sobh.Bill_Stats = 1
                 And Sobh.Year_Month > Str_Currmonth
                 And Sobh.Organization_Id = Int_Organization_Id
              Union All
              Select Cobh.Organization_Id Organization_Id,
                     Cobl.Warehouse_Id Warehouse_Id,
                     Cobl.Item_Id Item_Id,
                     0 Inv_Batch_Id,
                     Cobl.Qty_Bill - Cobl.Audit_Qty Qty
                From Css_Out_Bill_Line Cobl, Css_Out_Bill_Head Cobh
               Where Cobh.Css_Out_Bill_Head_Id = Cobl.Css_Out_Bill_Head_Id
                 And Cobh.Is_Auditing_Wh = 2
                 And Cobh.Organization_Id = Int_Organization_Id
                 And Cobh.Year_Month > Str_Currmonth
                 And Cobh.Bill_Stats = 1) Tmp
       Group By Tmp.Organization_Id,
                Tmp.Warehouse_Id,
                Tmp.Item_Id,
                Tmp.Inv_Batch_Id;
    Commit;
    --dgj 2014.01.06 CCS没有用到计划库存，则重算库存很慢，故暂时屏蔽
    /*    Delete From Tmpciv4 Where Organization_Id = Int_Organization_Id;
    Commit;*/
    --汇总结存数据
    --dgj 2014.01.06 CCS没有用到计划库存，则重算库存很慢，故暂时屏蔽
    /*    Insert Into Tmpciv4
    (Organization_Id, Warehouse_Id, Inv_Batch_Id, Item_Id, Qty_Plan)
    Select Int_Organization_Id,
           t.Warehouse_Id,
           t.Inv_Batch_Id,
           t.Item_Id,
           Sum(t.Qty_Plan)
      From Tmpciv3 t
     Where t.Organization_Id = Int_Organization_Id
     Group By t.Warehouse_Id, t.Inv_Batch_Id, t.Item_Id;*/
    --1.3 计划库存-
    --dgj 2014.01.06 CCS没有用到计划库存，则重算库存很慢，故暂时屏蔽
    /*    Execute Immediate 'Update Inv_Current_Inv Icpi ' ||
                      '   Set Icpi.Qty_Plan = Nvl(Icpi.Qty_Plan, 0) -' ||
                      '       (Select Aa.Qty_Plan' ||
                      '        From   Tmpciv4 Aa' ||
                      '        Where  Icpi.Organization_Id = Aa.Organization_Id' ||
                      '        And    Icpi.Warehouse_Id = Aa.Warehouse_Id' ||
                      '        And    Icpi.Item_Id = Aa.Item_Id' ||
                      '        And    Icpi.Inv_Batch_Id = Aa.Inv_Batch_Id' ||
                      '        And    Icpi.Organization_Id =' ||
                      Int_Organization_Id || ')' ||
                      ' Where  Exists (Select 1' ||
                      '        From   Tmpciv4 Aa' ||
                      '        Where  Icpi.Organization_Id = Aa.Organization_Id' ||
                      '            And    Icpi.Warehouse_Id = Aa.Warehouse_Id' ||
                      '            And    Icpi.Item_Id = Aa.Item_Id' ||
                      '            And    Icpi.Inv_Batch_Id = Aa.Inv_Batch_Id' ||
                      '            And    Icpi.Organization_Id = ' ||
                      Int_Organization_Id || ')' ||
                      '    And    Exists (Select 1' ||
                      '            From   Base_View_Item_Org Ii' ||
                      '            Where  Ii.Item_Id = Icpi.Item_Id' ||
                      '            And    Ii.Can_Sale = 2)';
    Commit;*/
  Else

    -- 出入库单据中最大的月份＝当前会计存货期间月份
    Delete Inv_Current_Inv Iv
     Where Iv.Organization_Id = Int_Organization_Id;

    Insert Into Inv_Current_Inv
      (Organization_Id,
       Warehouse_Id,
       Inv_Batch_Id,
       Item_Id,
       Qty_Onhand,
       Qty_Plan)
      Select Organization_Id,
             Warehouse_Id,
             Inv_Batch_Id,
             Item_Id,
             Qty_Onhand,
             Qty_Plan
        From Inv_Currentperiod_Inv
       Where Organization_Id = Int_Organization_Id;
    Commit;
    /*  Modified By: DingHua 2006.07.21
    Delete From Tmpciv3 Where Organization_Id = Int_Organization_Id;
    Commit;

    --1.2把销售发货通知单据中最大的月份 > 当前会计存货期间月份的销售发货通知的数据写入Tmpciv3
    Insert Into Tmpciv3
    (Organization_Id,
     Warehouse_Id,
     Item_Id,
     Inv_Batch_Id,
     Qty_Plan)
    Select Tmp.Organization_Id, Tmp.Warehouse_Id, Tmp.Item_Id,
           Tmp.Inv_Batch_Id, Sum(Nvl(Qty, 0)) Qty
    From   (Select Sobh.Organization_Id,  Sobl.Warehouse_Id, Sobl.Item_Id,
                    0 Inv_Batch_Id, Sobl.Qty_Bill - Sobl.Audit_Qty Qty
            From   Sa_Out_Bill_Line Sobl, Sa_Out_Bill_Head Sobh
            Where  Sobh.Sa_Out_Bill_Head_Id = Sobl.Sa_Out_Bill_Head_Id
            And    Sobh.Is_Auditing_Wh = 2
            And    Sobh.Bill_Stats = 1
            And    Sobh.Year_Month > Str_Currmonth
            And    Sobh.Organization_Id = Int_Organization_Id
            Union All
            Select Cobh.Organization_Id, Cobl.Warehouse_Id,  Cobl.Item_Id,
                   0 Inv_Batch_Id, Cobl.Qty_Bill - Cobl.Audit_Qty Qty
            From   Css_Out_Bill_Line Cobl, Css_Out_Bill_Head Cobh
            Where  Cobh.Css_Out_Bill_Head_Id = Cobl.Css_Out_Bill_Head_Id
            And    Cobh.Is_Auditing_Wh = 2
            And    Cobh.Organization_Id = Int_Organization_Id
            And    Cobh.Year_Month > Str_Currmonth
            And    Cobh.Bill_Stats = 1) Tmp
    Group  By Tmp.Organization_Id,
              Tmp.Warehouse_Id,
              Tmp.Item_Id,
              Tmp.Inv_Batch_Id;
    Commit;
    --1.3 计划库存-
    Execute Immediate 'Update Inv_Current_Inv Icpi' ||
                    '    Set    Icpi.Qty_Plan = Nvl(Icpi.Qty_Plan, 0) -' ||
                    '                           (Select Aa.Qty_Plan' ||
                    '                            From   Tmpciv3 Aa' ||
                    '                            Where  Icpi.Organization_Id =' ||
                    '                                   Aa.Organization_Id' ||
                    '                            And    Icpi.Warehouse_Id = Aa.Warehouse_Id' ||
                    '                            And    Icpi.Item_Id = Aa.Item_Id' ||
                    '                            And    Icpi.Inv_Batch_Id = Aa.Inv_Batch_Id' ||
                    '                            And    Icpi.Organization_Id =' ||Int_Organization_Id || ')' ||
                    '    Where  Exists (Select 1' ||
                    '            From   Tmpciv3 Aa' ||
                    '            Where  Icpi.Organization_Id = Aa.Organization_Id' ||
                    '            And    Icpi.Warehouse_Id = Aa.Warehouse_Id' ||
                    '            And    Icpi.Item_Id = Aa.Item_Id' ||
                    '            And    Icpi.Inv_Batch_Id = Aa.Inv_Batch_Id' ||
                    '            And    Icpi.Organization_Id = ' ||Int_Organization_Id || ')' ||
                    '    And    Exists (Select 1' ||
                    '            From   Base_View_Item_Org Ii' ||
                    '            Where  Ii.Item_Id = Icpi.Item_Id' ||
                    '            And    Ii.Can_Sale = 2)';

    Commit; */
  End If;

  delete from tmpciv1 where Organization_Id = Int_Organization_Id;
  -- 汇总
  delete from tmpciv2 where Organization_Id = Int_Organization_Id;
  --计算计划库存用的临时表tmpciv3.
  delete from tmpciv3 where Organization_Id = Int_Organization_Id;

  delete from TmpInv_Current_Inv
   where Organization_Id = Int_Organization_Id;

  delete from TmpInv_Currentperiod_Inv
   where Organization_Id = Int_Organization_Id;

  -- 写正在算库存的标志 否
  Update Inv_Param
     Set Param_Value = 1
   Where Param_Code = 'INVEXECUTING'
     And Organization_Id = Int_Organization_Id;

  Commit;

End;
/

