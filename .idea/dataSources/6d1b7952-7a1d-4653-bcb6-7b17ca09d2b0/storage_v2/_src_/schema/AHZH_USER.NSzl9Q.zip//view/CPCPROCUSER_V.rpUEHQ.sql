create view CPCPROCUSER_V as
    SELECT "WFID",
       "PROCID",
       "USERID",
       "POSITIONID",
       "AGENT",
       "STAT",
       "ISSIGNED",
       "FREQ",
       "RATE",
       "TEMPUSER",
       "ISREAD",
       "ISMAJOR",
       "NOTE"
  FROM CPCPROCUSER
UNION
SELECT "WFID",
       "PROCID",
       "USERID",
       "POSITIONID",
       "AGENT",
       "STAT",
       "ISSIGNED",
       "FREQ",
       "RATE",
       "TEMPUSER",
       "ISREAD",
       "ISMAJOR",
       "NOTE"
  FROM CPCPROCUSERH
/

