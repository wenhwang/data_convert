create view VIEW_PROJECT_BID_RESULT as
SELECT PROJECT_ID, --项目ID
       IS_BID_WIN, --是否中标(枚举:1 否|2 是)
       BID_WINNER, --中标单位
       BID_WIN_AMOUNT, --中标金额
       BID_WIN_TIME, -- 中标时间
       PM_PUBLICITY_TIME, --项目经理公示时间
       PUBLICITY_PM, --公示项目经理
       PUBLICITY_PM_NAME, --公示项目经理
       BID_WIN_LOSS_REASON --输赢原因分析
  FROM EPM_PROJECT_BID_RESULT
/

