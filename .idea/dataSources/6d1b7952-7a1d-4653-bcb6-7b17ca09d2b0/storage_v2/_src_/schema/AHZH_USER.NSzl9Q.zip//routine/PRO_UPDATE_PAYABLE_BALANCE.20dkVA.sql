create PROCEDURE PRO_UPDATE_PAYABLE_BALANCE(P_PROJECT_ID IN EPM_PROJECT_ACCOUNT_BALANCE.PROJECT_ID%TYPE) IS

  /*********************************************\
  * NAME(名称): PRO_UPDATE_PROJECT_BALANCE
  * PURPOSE(功能说明):  更新项目剩余应付
  *PARAM(参数说明)： P_PROJECT_ID 项目ID
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-01-25
  \*********************************************/

BEGIN

  /*
  合伙人实际应付余额=(回款合计-付款合计-扣罚款合计+收保证金-付保证金+借入金额-借支金额)
  回款合计=投资款+工程回款+往来调拨收款+其他回款；
  付款合计=已支付项目款+往来调拨付款+代采购付款+其他付款；
  扣罚款合计=扣管理费+扣年费+扣税费+扣其他+罚款金额；
  业主应收余额(累计开票金额-项目回款金额)
  */
  UPDATE EPM_PROJECT_ACCOUNT_BALANCE
     SET PAYABLE_BALANCE    = ((NVL(PROJECT_INVEST_AMOUNT, 0) +
                              NVL(PROJECT_RECEIVE_AMOUNT, 0) +
                              NVL(TRANSFER_IN_AMOUNT, 0) +
                              NVL(OTHER_IN_AMOUNT, 0)) -
                              (NVL(PROJECT_PAYMENT_AMOUNT, 0) +
                              NVL(TRANSFER_OUT_AMOUNT, 0) +
                              NVL(AGENT_PURCHASE_OUT_AMOUNT, 0) +
                              NVL(OTHER_OUT_AMOUNT, 0)) -
                              (NVL(WITHHOLD_MANAGEMENT_AMOUNT, 0) +
                              NVL(WITHHOLD_YEAR_AMOUNT, 0) +
                              NVL(WITHHOLD_TAX_AMOUNT, 0) +
                              NVL(WITHHOLD_OTHER_AMOUNT, 0) +
                              NVL(PROJECT_FINE_AMOUNT, 0)) +
                              (NVL(IN_MARGIN_AMOUNT, 0) -
                              NVL(OUT_MARGIN_AMOUNT, 0)) +
                              (NVL(LOAN_AMOUNT, 0) - NVL(BORROW_AMOUNT, 0))),
         RECEIVABLE_BALANCE = (NVL(OUTPUT_INVOICE_AMOUNT, 0) -
                              NVL(PROJECT_RECEIVE_AMOUNT, 0))
   WHERE PROJECT_ID = P_PROJECT_ID;

END;
/

