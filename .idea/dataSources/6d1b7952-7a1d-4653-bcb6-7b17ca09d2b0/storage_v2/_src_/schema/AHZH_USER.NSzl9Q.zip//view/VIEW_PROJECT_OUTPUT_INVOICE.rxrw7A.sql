create view VIEW_PROJECT_OUTPUT_INVOICE as
SELECT HEAD.PROJECT_ID, --项目ID
       HEAD.APPLY_BILL_NO, --申请单号
       HEAD.APPLY_DATE, --申请日期
       HEAD.APPLY_PEOPLE, --申请人
       HEAD.TAXPAYER_NAME, --纳税人名称
       HEAD.TAXPAYER_NUMBER, --纳税人识别号
       HEAD.TAXPAYER_ADDRESS, --地址
       HEAD.TAXPAYER_PHONENO, --电话
       HEAD.TAXPAYER_BANK_NAME, --开户行
       HEAD.TAXPAYER_BANK_ACCOUNT, --银行账号
       HEAD.REMARK, --备注
       LINE.INVOICE_TYPE, --发票类型(枚举:1|专用发票（纸）、2|普通发票(纸)、3|专用发票（电）、4|普通发票(电))
       LINE.INVOICE_NUMBER, --发票号
       LINE.INVOICE_DATE, --发票日期
       LINE.INVOICE_CONTENT, --开票内容
       LINE.INVOICE_AMOUNT, --发票金额
       LINE.TAX_RATE, --税率（17%、11%、6%、3%）
       LINE.TAX_AMOUNT --发票税额=发票金额/(1+税率%)*税率%
  FROM FD_OUTPUT_INVOICE_LIST LINE, FD_OUTPUT_INVOICE_APPLY HEAD
 WHERE HEAD.OUTPUT_INVOICE_APPLY_ID = LINE.OUTPUT_INVOICE_APPLY_ID
   AND HEAD.STAT = 5
   AND LINE.IS_USABLE = 2

/*********************************************\
  * NAME(名称): VIEW_PROJECT_OUTPUT_INVOICE
  * PURPOSE(功能说明):  开票明细
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2019-07-19
  \*********************************************/
/

