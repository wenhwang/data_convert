create view VIEW_FIN_LOAD_INFO as
SELECT LOAD.LOAN_NO, --借款单号
       LOAD.CREATE_TIME, --申请日期
       USERNAME CHAP_NAME, --申请人
       REPAYMENT_DATE, --预计还款时间
       LOAN_PURPOSE, --用途
       NVL(LOAD.ALLOW_AMT, 0) ALLOW_AMT, --借款金额
       NVL(PAY_AMOUNT, 0) PAY_AMOUNT, --支付金额
       NVL(CX_AMT, 0) CX_AMT, --冲销金额
       NVL(AMOUNT_PAYMENT, 0) AMOUNT_PAYMENT, --还款金额
       DECODE(NVL(PAY_AMOUNT, 0),
              0,
              0,
              (NVL(PAY_AMOUNT, 0) - NVL(CX_AMT, 0) - NVL(AMOUNT_PAYMENT, 0))) NON_REPAYMENT, --未还金额=支付-冲销-还款

       --ROUND((SYSDATE - REPAYMENT_DATE)) OVERDUE_DAYS --逾期天数

       CASE
         WHEN ROUND((SYSDATE - REPAYMENT_DATE)) > 0 THEN
          ROUND((SYSDATE - REPAYMENT_DATE))
         ELSE
          0
       END OVERDUE_DAYS --逾期天数

  FROM (SELECT LOAN_HEAD.LOAN_NO,
               LOAN_HEAD.CREATE_TIME,
               CHAP_ID,
               LOAN_PURPOSE,
               LOAN_HEAD.REPAYMENT_DATE,
               NVL(SUM(LOAN_LINE.ALLOW_AMT), 0) ALLOW_AMT
          FROM MKT_LOAN_HEADER LOAN_HEAD, MKT_LOAN_LINE LOAN_LINE
         WHERE LOAN_HEAD.LOAN_ID = LOAN_LINE.LOAN_ID
           AND LOAN_HEAD.STAT = 5
         GROUP BY LOAN_HEAD.LOAN_NO,
                  LOAN_HEAD.CREATE_TIME,
                  CHAP_ID,
                  LOAN_HEAD.REPAYMENT_DATE,
                  LOAN_PURPOSE) LOAD, --1.借款金额
       (SELECT BILL_NO LOAN_NO, NVL(SUM(PAY.AMOUNT_CREDIT), 0) PAY_AMOUNT
          FROM FIN_PAYING_VOUCHER PAY
         WHERE PAY.STAT = 5
           AND PAY.SYSCREATE_TYPE = 6
         GROUP BY BILL_NO) PAY, --2.付款金额
       (SELECT LOAN_NO, CX_AMT FROM VIEW_FIN_LOAN_WRITE_OFF) WRITE_OFF, --3.冲销金额
       (SELECT SOURCE_BILL_NO LOAN_NO, NVL(AMOUNT_PAYMENT, 0) AMOUNT_PAYMENT
          FROM FD_PAYMENT_BILL REPAYMENT
         WHERE SOURCE_BILL_TYPE = 6
           AND REPAYMENT.STAT = 5) REPAY, --4.还款金额
       CPCUSER
 WHERE LOAD.LOAN_NO = PAY.LOAN_NO(+)
   AND LOAD.LOAN_NO = WRITE_OFF.LOAN_NO(+)
   AND LOAD.LOAN_NO = REPAY.LOAN_NO(+)
   AND LOAD.CHAP_ID = CPCUSER.SYSUSERID(+)

/*********************************************\
  * NAME(名称): VIEW_FIN_LOAD_INFO
  * PURPOSE(功能说明):  借款明细
                                   ALLOW_AMT, --借款金额
                                   PAY_AMOUNT, --支付金额
                                   CX_AMT, --冲销金额
                                   AMOUNT_PAYMENT, --还款金额
                                   NON_REPAYMENT --未还金额
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-07-21
  \*********************************************/
/

