create Function           Fn_Hr_GetPersonTax(TI varchar2,
                              year_month Varchar2)
 Return varchar2 Is
  v_sql Varchar2(3000);
  /**
   * 涓？汉缂寸撼绋？？
   * @TI: 璁＄？？跺？
   * @year_month: ？？？璁＄？链？唤
   *
   *  瀛？？涓叉浔浠剁？ {}镟挎？''锛?
   *   eg: year_month = '2010-10'？？？ year_month = {2010-10}
   */
Begin
/*
  涓？汉缂寸撼绋？？锛？？绋？？？ッ？？？？绋？？锛？？？？镓ｉ？？?
  ？？？？？链？？涓？？？朵腑update？椤？澶？溃
 update hr_count_salary_line t
   set f_salary6 = nvl((select F_SALARY5 * x.tax_rate-x.quick_deduction
                      from hr_persontax_rate x
                     where start_month =
                           (select max(start_month)
                              from hr_persontax_rate
                             where start_month <= '2010-09')
                       And f_salary5 Between x.money_bottom_line And x.money_top_line),0)
 Where hr_count_salary_head_id = 1
*/

  v_sql := 'nvl((select nvl('||TI||',0)* nvl(x.tax_rate,0)/100 - nvl(x.quick_deduction,0) '
         ||' from hr_persontax_rate x'
         ||' where start_month ='
         ||'    (select max(start_month)'
         ||'       from hr_persontax_rate'
         ||'      where start_month <= {'||year_month||'})'
         ||'        And nvl('||TI||',0) > x.money_bottom_line'
         ||'        And nvl('||TI||',0) <= x.money_top_line),0)';

  return v_sql;

End Fn_Hr_GetPersonTax;
/

