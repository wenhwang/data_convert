create Function           Fn_GetKeeped_Qty(p_organization_id Number,
                                            p_item_id         Number,
                                            p_warehouse_id    Number,
                                            p_bill_type       number,
                                            p_bill_line_id    number)
  Return Number Is
  Result      Number;
  CgReturnQty number;
  QtyCtrlFlag number;
  strSql      varchar2(30000);
  strStat     varchar2(10);
  match_qty number;  --零售核销单生成的出库单自动审核时候，核销单不应该是占用库存状态
  saOutNotQtyCtrl number;
  /*
  * Author: Jwb
  * Written Date: 2010.3.6
  * Desription: 库存占用量
  *             (1)采购退货申请量(已审核是必须的，其它是参数控制)
  *             (2)负数的入库数量(采购、其它入库红冲＋未做退货申请的采购退货)
  *             (3)未审核出库单数量
  *             (4)调拨单调出数量
  *             (5)委托代销和销售订单 数量
  * 参数控制：库存占用控制启用标识 0 仅申请采购退货量 1 采购红冲、退货及销售出库等，制单即占用  2 采购红冲、退货及销售出库等，启动流程才占用
  *
  * @p_bill_type: 1 采购退货申请;2 入库单; 3 出库单;4 调拨单; 5 委托代销/销售订单
  * @p_bill_line_id: 单据行ID
  */

Begin
  --零售核销单生成的出库单自动审核时候，核销单不应该是占用库存状态
  match_qty := 0;
  if (p_bill_type = 3 and p_bill_line_id > 0) then
    begin
      select nvl(sum(match_qty),0)
        into match_qty
        from inv_matching_bill_head mh,
             inv_matching_bill_line ml,
             inv_out_bill_head      iobh,
             inv_out_bill_line      iobl
       where mh.inv_matching_bill_head_id = ml.inv_matching_bill_head_id
         and ml.inv_out_bill_head_id = iobl.inv_out_bill_head_id
         and ml.inv_out_bill_head_id = iobh.inv_out_bill_head_id
         and mh.organization_id = iobh.organization_id
         and ml.warehouse_id = iobl.warehouse_id
         and ml.item_id = iobl.item_id
         and ml.match_qty = iobl.qty_bill
         and iobh.stat != 5
         and mh.stat != 5
         and iobl.inv_out_bill_line_id = p_bill_line_id;
    end;
  End If;

  -- 采购退货申请保留库存(申请已经通过，但尚未退货出库的)
   strSql := 'select nvl(sum(sum_qty),0) from ( select nvl(sum(bl.qty_invbill * (-1)),0) sum_qty' ||
            ' from srm_itemback_plan_line bl, srm_itemback_plan_head bh, ' ||
            '      (select distinct bl.srm_itemback_plan_head_id' ||
            '         from inv_in_bill_line il, inv_in_bill_head ih,srm_itemback_plan_line bl' ||
            '        where il.inv_in_bill_head_id = ih.inv_in_bill_head_id' ||
            '        and il.srm_itemback_plan_line_id=bl.srm_itemback_plan_line_id ' ||
            '          and il.srm_itemback_plan_line_id > 0 and ih.stat = 5' ||
            '          and ih.is_auditing_wh = 2' ||
            '          and ih.organization_id =' || p_organization_id ||
            '          and ih.billtypecode = ''0101'') il' ||
            ' where bl.srm_itemback_plan_head_id = bh.srm_itemback_plan_head_id and bh.stat = 5' ||
            '   and bl.srm_itemback_plan_head_id = il.srm_itemback_plan_head_id(+)' ||
            '   and il.srm_itemback_plan_head_id is null and item_id = ' ||
            p_item_id || '   and bl.warehouse_id = ' || p_warehouse_id ||
            '   and bh.Organization_Id =' || p_organization_id;

  if (p_bill_type = 1 and p_bill_line_id > 0) then
    strSql := strSql || ' and bl.srm_itemback_plan_line_id <> ' ||
              p_bill_line_id;
  End If;

  select nvl(param_value, 0)
    into QtyCtrlFlag
    from sys_param
   where param_code = 'StockRemainQtyCtrl'
     and enterprise_id = p_organization_id;

  if (QtyCtrlFlag is null) then--这是不可能的，若select没有返回一行，会抛no_data_found
    QtyCtrlFlag := 0;
  end if;
  --控制销售订单是否占用库存 0,1-占（默认） 2-不占
  select nvl((select nvl(param_value, 1)
               from sys_param
              where param_code = 'SaOutNotQtyCtrl'
                and enterprise_id = p_organization_id),
             1)--给0或1都没关系
    into saOutNotQtyCtrl
    from dual;

  if QtyCtrlFlag = 0 then
    begin
      --销售出库(无订单)走出库确认，流程已经审核完，但还没做出库确认的单据
      strSql := strSql || '        union all /*-销售出库单(无订单)和其他出库单*/' ||
                '        select nvl(sum(iol.qty_bill),0) sum_qty' ||
                '          from inv_out_bill_head ioh, inv_out_bill_line iol' ||
                '         where ioh.inv_out_bill_head_id = iol.inv_out_bill_head_id' ||
                '           and ioh.billtypecode =''0204''' ||
                '           and iol.qty_bill > 0 and ioh.is_auditing_wh <> 2' ||
                '           and ioh.stat = 5' ||
                '           and nvl(ioh.is_init_bill, 1) <> 2' ||
                '           and iol.item_id = ' || p_item_id ||
                '           and iol.warehouse_id = ' || p_warehouse_id ||
                '           and ioh.organization_id = ' ||
                p_organization_id;
      if (p_bill_type = 3 and p_bill_line_id > 0) then
        strSql := strSql || ' and iol.inv_out_bill_line_id <> ' ||
                  p_bill_line_id;
      End If;
      --委托代销开单走出库确认，流程已经审核完，但还没做出库确认的单据
      strSql := strSql || '        union all /*--委托代销单*/' ||
                '        select nvl(sum(sol.qty_bill),0) sum_qty' ||
                '          from sa_out_bill_head soh, sa_out_bill_line sol' ||
                '         where soh.sa_out_bill_head_id = sol.sa_out_bill_head_id' ||
                '           and soh.sale_type = 3 and soh.bill_type = 1' ||
                '           and soh.stat = 5 and soh.is_auditing_wh <> 2' ||
                '           and sol.item_id = ' || p_item_id ||
                '           and sol.warehouse_id = ' || p_warehouse_id ||
                '           and soh.organization_id = ' ||
                p_organization_id;
      if (p_bill_type = 5 and p_bill_line_id > 0) then
        strSql := strSql || ' and sol.sa_out_bill_line_id <> ' ||
                  p_bill_line_id;
      End If;
    end;
  end if;
  strSql := strSql || ' )';

  execute immediate strSql
    into CgReturnQty;

  -- rollback;
  -- raise_application_error(-20001,'参数[库存占用控制启用标识]不存在，请联系管理员！');

  -- 1 制单即占用；2 启动才占用
  if QtyCtrlFlag >= 1 then
    strStat := '0';
    if (QtyCtrlFlag = 2) then
      strStat := '2';
    end if;

    --* @p_bill_type: 1 采购退货申请;2 入库单; 3 出库单;4 调拨单; 5 委托代销/销售订单
    strSql := 'select nvl(sum(sum_qty),0)' || '  from (/*采购退货申请量*/' ||
              '        select nvl(sum(bl.qty_invbill * (-1)),0) sum_qty' ||
              '          from srm_itemback_plan_line bl, srm_itemback_plan_head bh' ||
              '         where bl.srm_itemback_plan_head_id = bh.srm_itemback_plan_head_id' ||
              '           and bh.stat >= ' || strStat ||
              '           and bh.stat < 5' || '           and item_id = ' ||
              p_item_id || '           and bl.warehouse_id = ' ||
              p_warehouse_id || '           and bh.Organization_Id = ' ||
              p_organization_id;
    if (p_bill_type = 1 and p_bill_line_id > 0) then
      strSql := strSql || ' and bl.srm_itemback_plan_line_id <> ' ||
                p_bill_line_id;
    End If;

    strSql := strSql || '        union all /*-采购入库红冲和退货(不含退货申请)，其他入库红冲,委外入库退货和红冲 */' ||
              '        select nvl(-sum(iil.qty_invbill),0) sum_qty' ||
              '          from inv_in_bill_head iih, inv_in_bill_line iil' ||
              '         where iih.inv_in_bill_head_id = iil.inv_in_bill_head_id' ||
              '           and iih.billtypecode in (''0101'', ''0199'',''0103'')' ||
              '           and iil.qty_invbill < 0 and iih.is_auditing_wh <> 2' ||
              '           and iih.stat >= ' || strStat ||
              '           and iih.stat < 5' ||
              '           and iih.is_have_order <> 2' ||
              '           and nvl(iih.is_init_bill, 1) <> 2' ||
              '           and iil.srm_itemback_plan_line_id = 0' ||
              '           and iil.item_id = ' || p_item_id ||
              '           and iil.warehouse_id = ' || p_warehouse_id ||
              '           and iih.organization_id = ' || p_organization_id;
    if (p_bill_type = 2 and p_bill_line_id > 0) then
      strSql := strSql || ' and iil.inv_in_bill_line_id <> ' ||
                p_bill_line_id;
    End If;

    strSql := strSql || '        union all /*-销售出库单(无订单)和其他出库单*/' ||
              '        select nvl(sum(iol.qty_bill),0) sum_qty' ||
              '          from inv_out_bill_head ioh, inv_out_bill_line iol' ||
              '         where ioh.inv_out_bill_head_id = iol.inv_out_bill_head_id' ||
              '           and ioh.billtypecode in (''0204'', ''0299'')' ||
              '           and iol.qty_bill > 0 and ioh.is_auditing_wh <> 2' ||
              '           and ioh.stat >= ' || strStat ||
              '           and ioh.stat < 5' ||
              --'           and ioh.is_have_order <> 2' ||
              '           and ioh.inv_out_type <> 3' ||
              '           and nvl(ioh.is_init_bill, 1) <> 2' ||
              '           and iol.item_id = ' || p_item_id ||
              '           and iol.warehouse_id = ' || p_warehouse_id ||
              '           and ioh.organization_id = ' || p_organization_id;

    -- 销售订单不占库存，则销售出库单需统计启用这部分
    if saOutNotQtyCtrl != 2 THEN
      BEGIN
        strSql := strSql || ' and ioh.is_have_order <> 2 ';
      END;
    END IF;

    if (p_bill_type = 3 and p_bill_line_id > 0) then
      strSql := strSql || ' and iol.inv_out_bill_line_id <> ' ||
                p_bill_line_id;
    End If;
    --销售出库(无订单)走出库确认，流程已经审核完，但还没做出库确认的单据
    strSql := strSql || '        union all /*-销售出库单(无订单)和其他出库单*/' ||
              '        select nvl(sum(iol.qty_bill),0) sum_qty' ||
              '          from inv_out_bill_head ioh, inv_out_bill_line iol' ||
              '         where ioh.inv_out_bill_head_id = iol.inv_out_bill_head_id' ||
              '           and ioh.billtypecode =''0204''' ||
              '           and iol.qty_bill > 0 and ioh.is_auditing_wh <> 2' ||
              '           and ioh.stat = 5' ||
              '           and nvl(ioh.is_init_bill, 1) <> 2' ||
              '           and iol.item_id = ' || p_item_id ||
              '           and iol.warehouse_id = ' || p_warehouse_id ||
              '           and ioh.organization_id = ' || p_organization_id;
    if (p_bill_type = 3 and p_bill_line_id > 0) then
      strSql := strSql || ' and iol.inv_out_bill_line_id <> ' ||
                p_bill_line_id;
    End If;

    strSql := strSql || '        union all /*--调拨单*/ ' ||
              '        select nvl(sum(iwl.qty_moved),0) sum_qty' ||
              '          from inv_whtowh_head iwh, inv_whtowh_line iwl' ||
              '         where iwh.inv_whtowh_head_id = iwl.inv_whtowh_head_id' ||
              '           and iwl.qty_moved > 0 and iwh.is_checked <> 2' ||
              '           and iwh.stat >= ' || strStat ||
              '           and iwh.stat < 5' ||
              '           and iwl.item_id = ' || p_item_id ||
              '           and iwl.warehouse_id_out = ' || p_warehouse_id ||
              '           and iwh.organization_id = ' || p_organization_id;
    if (p_bill_type = 4 and p_bill_line_id > 0) then
      strSql := strSql || ' and iwl.inv_whtowh_line_id <> ' ||
                p_bill_line_id;
    End If;

    strSql := strSql || '        union all /*--委托代销单*/' ||
              '        select nvl(sum(sol.qty_bill),0) sum_qty' ||
              '          from sa_out_bill_head soh, sa_out_bill_line sol' ||
              '         where soh.sa_out_bill_head_id = sol.sa_out_bill_head_id' ||
              '           and soh.sale_type = 3 and soh.bill_type = 1' ||
              '           and soh.stat >= ' || strStat ||
              '           and soh.stat < 5 and soh.is_auditing_wh <> 2' ||
              '           and sol.item_id = ' || p_item_id ||
              '           and sol.warehouse_id = ' || p_warehouse_id ||
              '           and soh.organization_id = ' || p_organization_id;
    if (p_bill_type = 5 and p_bill_line_id > 0) then
      strSql := strSql || ' and sol.sa_out_bill_line_id <> ' ||
                p_bill_line_id;
    End If;

    if saOutNotQtyCtrl != 2 then--控制销售订单是否占用库存
      begin
    strSql := strSql || '        union all /*--销售申请*/' ||
              '        select nvl(sum(sol.qty_bill),0) sum_qty' ||
              '          from sa_out_bill_head soh, sa_out_bill_line sol' ||
              '         where soh.sa_out_bill_head_id = sol.sa_out_bill_head_id' ||
              '           and soh.sale_type = 2 and soh.bill_type = 1' ||
              '           and soh.stat >= ' || strStat ||
              '           and soh.stat < 5 and soh.is_auditing_wh <> 2' ||
              '           and sol.item_id = ' || p_item_id ||
              '           and sol.warehouse_id = ' || p_warehouse_id ||
              '           and soh.organization_id = ' || p_organization_id;
    if (p_bill_type = 5 and p_bill_line_id > 0) then
      strSql := strSql || ' and sol.sa_out_bill_line_id <> ' ||
                p_bill_line_id;
    End If;

    --csh 2015.10.14 统计已经审核的销售订单
    strSql := strSql || ' union all /*--已经审核的销售订单*/' ||
              '  select (nvl(sum(sobl.qty_bill), 0) -' ||
              ' nvl(sum((select nvl(sum(iobl.qty_bill), 0)' ||
              '   from inv_out_bill_line iobl' ||
              '  where iobl.sa_out_bill_line_id = sobl.sa_out_bill_line_id' ||
              '   and iobl.sa_out_bill_head_id = sobl.sa_out_bill_head_id' ||
              '  and iobl.item_id =' || p_item_id || '  and exists' ||
              ' (select 1' || ' from inv_out_bill_head iobh' ||
              '  where iobh.inv_out_bill_head_id = iobl.inv_out_bill_head_id' ||
              '  and nvl(iobh.is_init_bill, 0) <> 2' ||
              '  and (iobh.stat = 5';
    --出库单创建时候,不计算本单
    if (p_bill_type = 3 and p_bill_line_id > 0) then
      strSql := strSql || ' or iobl.inv_out_bill_line_id = ' ||
                p_bill_line_id || ')';
    else
      strSql := strSql || ')';
    End If;
    strSql := strSql ||
              ' and iobh.billtypecode = ''0204''' ||
              ' and iobh.inv_out_type <> 3' ||
              ' and iobh.organization_id ='||
              p_organization_id || '))),0)) sum_qty ' ||
              ' from sa_out_bill_line sobl, sa_out_bill_head sobh ' ||
              ' where sobh.sa_out_bill_head_id = sobl.sa_out_bill_head_id and sobh.is_auditing_wh = 2' || ' and sobh.stat = 5' ||
              ' and sobh.bill_type = 1 and nvl(sobh.bill_stats,0) = 1 ' || '  and sobh.sale_type = 2' ||
              ' and sobl.item_id =' || p_item_id ||
              ' and sobl.warehouse_id =' || p_warehouse_id ||
              ' and sobh.organization_id =' || p_organization_id;
    if (p_bill_type = 5 and p_bill_line_id > 0) then
      strSql := strSql || ' and sobl.sa_out_bill_line_id <> ' ||
                p_bill_line_id;
    End If;
      end;
    end if;

     --委托代销开单走出库确认，流程已经审核完，但还没做出库确认的单据
   strSql := strSql || '        union all /*--委托代销单*/' ||
              '        select nvl(sum(sol.qty_bill),0) sum_qty' ||
              '          from sa_out_bill_head soh, sa_out_bill_line sol' ||
              '         where soh.sa_out_bill_head_id = sol.sa_out_bill_head_id' ||
              '           and soh.sale_type = 3 and soh.bill_type = 1' ||
              '           and soh.stat = 5 and soh.is_auditing_wh <> 2' ||
              '           and sol.item_id = ' || p_item_id ||
              '           and sol.warehouse_id = ' || p_warehouse_id ||
              '           and soh.organization_id = ' || p_organization_id;
    if (p_bill_type = 5 and p_bill_line_id > 0) then
      strSql := strSql || ' and sol.sa_out_bill_line_id <> ' ||
                p_bill_line_id;
    End If;

    --零售开单走流程，占用库存
    /*
    strSql := strSql || ' union all select nvl(sum(a.qty_bill),0) sum_qty'||
             '  from (select sum(l.qty_bill) qty_bill'||
             '        from inv_retail_bill_head h, inv_retail_bill_line l'||
             '  where h.inv_retail_bill_head_id = l.inv_retail_bill_head_id'||
             '    and h.stat >= ' || strStat ||
             '    and h.stat < 5'||
             '    and h.sale_type = 1'||
             '    and l.item_id ='||p_item_id||
             '    and l.warehouse_id ='||p_warehouse_id||
             '    and h.organization_id ='||p_organization_id;
           if(p_bill_type = 6 and p_bill_line_id > 0) then
             strSql := strSql || ' and l.inv_retail_bill_line_id <> ' ||
                p_bill_line_id;
             end if;
            strSql := strSql ||'   union all'||
             '   select sum(l.qty_bill)-sum(l.qty_match_total) qty_bill'||
             '   from inv_retail_bill_head h, inv_retail_bill_line l'||
             '  where h.inv_retail_bill_head_id = l.inv_retail_bill_head_id'||
             '    and h.stat >= ' || strStat ||
             '    and h.stat <> 99'||
             '    and h.sale_type in (2, 3)'||
             '    and h.is_delegate <> 2'|| --不是委托代销的单子
             '    and l.item_id ='||p_item_id||
             '    and l.warehouse_id ='||p_warehouse_id;
             */
             --2017/03/11,整个零售单，不考虑类型
    strSql := strSql || ' union all select nvl(sum(a.qty_bill),0) sum_qty'||
             '  from (select sum(l.qty_bill) qty_bill'||
             '        from inv_retail_bill_head h, inv_retail_bill_line l'||
             '  where h.inv_retail_bill_head_id = l.inv_retail_bill_head_id'||
             '    and h.stat >= ' || strStat ||
             '    and h.stat <= 5'|| --审核以后的6-中断，7-已发货，99-关闭 等其它不占库存
             --'    and h.sale_type = 1'||
             '    and l.item_id ='||p_item_id||
             '    and l.warehouse_id ='||p_warehouse_id||
             '    and h.organization_id ='||p_organization_id;
           if(p_bill_type = 6 and p_bill_line_id > 0) then
             strSql := strSql || ' and l.inv_retail_bill_line_id <> ' ||
                p_bill_line_id;
             end if;

             strSql := strSql || '    and h.organization_id ='||p_organization_id||') a ';

    strSql := strSql || ' )';

    execute immediate strSql
      into result;
  else
    result := 0;
  end if;
  --
  result := CgReturnQty + result - match_qty;
  Return nvl(Result, 0);
End Fn_GetKeeped_Qty;
/

