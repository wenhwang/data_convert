create view V_INV_OUT_BILL_BCS as
    select ih.organization_id,
          e.entname,
          ih.invbillno,
          c.customer_id,
          c.customer_code,
          c.customer_name,
          i.item_code,
          i.item_name,
          il.qty_bill,
          ih.Address1,
          ib.billtypecode,
          ib.billtypename,
          ih.date_invbill,
          ih.creation_date,
          w.warehouse_id,
          w.warehouse_code,
          w.warehouse_name,
          ih.is_auditing_wh,
          il.bcs_qty_actual
     from inv_out_bill_head ih,
          inv_out_bill_line il,
          customer          c,
          cpcent            e,
          item              i,
          inv_billtype      ib,
          warehouse         w
    where il.inv_out_bill_head_id = ih.inv_out_bill_head_id
      and il.warehouse_id = w.warehouse_id(+)
      and ih.billtypecode in ('0299', '0204')
      and ih.stat = 5
      and ih.customer_id = c.customer_id(+)
      and e.entid = ih.organization_id
      and i.item_id = il.item_id
      and ib.billtypecode = ih.billtypecode
      union all
           select sobh.organization_id,
            t.entname,
          sobh.sa_salebillno invbillno,
          c.customer_id,
          c.customer_code,
          c.customer_name,
          i.item_code,
          i.item_name,
          sobl.qty_bill,
          sobh.Address1,
          '' billtypecode,
          '' billtypename,
          sobh.date_invbill,
          sobh.creation_date,
          w.warehouse_id,
          w.warehouse_code,
          w.warehouse_name,
          sobh.is_auditing_wh,
          sobl.bcs_qty_actual
       from sa_out_bill_head sobh,sa_out_bill_line sobl,cpcent t,
            customer c,item i,warehouse w
      where sobh.sa_out_bill_head_id = sobl.sa_out_bill_head_id
        and sobl.warehouse_id = w.warehouse_id(+)
        and sobh.customer_id = c.customer_id(+)
        and sobl.item_id = i.item_id(+)
        and t.entid = sobh.organization_id
        and sobh.sale_type = 3
        and sobh.bill_type = 1
        and sobh.stat = 5
/

