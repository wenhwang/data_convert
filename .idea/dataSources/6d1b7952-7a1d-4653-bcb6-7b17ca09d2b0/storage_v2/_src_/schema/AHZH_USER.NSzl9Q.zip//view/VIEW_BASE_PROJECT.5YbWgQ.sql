create view VIEW_BASE_PROJECT as
SELECT PROJECT.ORGANIZATION_ID, --组织ID
       PROJECT.PROJECT_ID, --项目ID
       PROJECT.PROJECT_CODE, --项目编码
       PROJECT.PROJECT_NAME, --项目名称

       PROJECT.PROJECT_STATUS, --项目状态
       PROJECT.PROJECT_TYPE, --项目类型
       DICTNAME PROJECT_TYPE_NAME,

       PROJECT_SOURCE, --项目来源

       PROJECT.AREA_ID, --省市
       PROJECT.AREA,
       '' AREANAME,

       CUSTOMER.DEPT_ID, --所属部门

       CUSTOMER.DEPT_ID   SALE_AREA_ID, --所属分部
       CUSTOMER.DEPT_NAME SALE_AREA_NAME,

       PROJECT.SALE_MANAGER_ID, --大区经理
       SALE_MANAGER_USER.USERNAME SALE_MANAGER_NAME,

       PROJECT.BIZ_SUPPORT_PEOPLE, --商务专员

       PROJECT.SALES_ID, --业务员
       SALES_USER.USERNAME SALES_NAME,

       PROJECT.PARTNER_ID, --项目合伙人
       PROJECT.PARTNER,

       PROJECT.HOLDER_ID, --项目业主
       PROJECT.HOLDER,

       FUTURE_PRICES, --预估金额

       REPORT_TIME, --报备时间
       SIGNUP_TIME, --报名时间

       --DECODE(IS_NOT_BID, 2, '是  ' ， '否  ') IS_NOT_BID, --  是否免招标(枚举:1 否|2 是)
       IS_NOT_BID,

       BID_SEALED_TIME, --封标时间
       BID_SEALED_PERSON, --封标人

       BID_OPEN_PRIMARY, --开标授权人
       BID_OPEN_TIME, --开标时间
       BID_OPEN_ADDRESS, --开标地点

       PUBLICITY_PM， -- 项目经理
        PM_PUBLICITY_TIME， -- 公示时间
       --DECODE(IS_BID_WIN, 2, '是  ' ， '否  ') IS_BID_WIN, --  是否中标(枚举:1 否|2 是) 投标结果
        IS_BID_WIN,
       BID_WIN_TIME, --中标时间
       BID_WIN_AMOUNT, --中标金额

       CONTRACT_CODE, --合同编码
       CONTRACT_SIGNUP_DATE, --合同签订时间
       CONTRACT_AMOUNT, --合同金额
       PROJECT.CREATE_BY --制单人

  FROM EPM_PROJECT PROJECT,
       VIEW_BCS_CUSTOMER CUSTOMER,
       CPCUSER SALES_USER,
       CPCUSER SALE_MANAGER_USER,
       (SELECT DICTVALUE, DICTNAME FROM CPCDICT WHERE PID = -1026680) PROJECT_TYPE_DICT
 WHERE PROJECT.PARTNER_ID = CUSTOMER_ID(+)
   AND PROJECT.SALES_ID = SALES_USER.SYSUSERID(+)
   AND PROJECT.SALE_MANAGER_ID = SALE_MANAGER_USER.SYSUSERID(+)
   AND PROJECT.PROJECT_TYPE = PROJECT_TYPE_DICT.DICTVALUE(+)

/*********************************************\
  * NAME(名称): VIEW_BASE_PROJECT
  * PURPOSE(功能说明):  项目基本信息
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-01-24
  \*********************************************/
/

