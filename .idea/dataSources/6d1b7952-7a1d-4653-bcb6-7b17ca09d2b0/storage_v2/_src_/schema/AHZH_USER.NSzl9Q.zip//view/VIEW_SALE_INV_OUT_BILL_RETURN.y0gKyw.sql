create view VIEW_SALE_INV_OUT_BILL_RETURN as
Select Iobh.Organization_Id,
       Iobh.Invbillno,
       Iobh.Invbilldate,
      case
         when (select sp.param_value
                 from sys_param sp
                where sp.enterprise_id = Iobh.Organization_Id
                  and sp.param_code = 'Is_Start_Old_Code_Report') = '2' then
          co.attribute2
         else
          c.Customer_Code
       end Customer_Code,
       case
         when (select sp.param_value
                 from sys_param sp
                where sp.enterprise_id = Iobh.Organization_Id
                  and sp.param_code = 'Is_Start_Old_Code_Report') = '2' then
          co.attribute3
         else
          c.Customer_Name
       end Customer_Name,
       case
         when (select sp.param_value
                 from sys_param sp
                where sp.enterprise_id = Iobh.Organization_Id
                  and sp.param_code = 'Is_Start_Old_Code_Report') = '2' then
          w.attribute11
         else
          w.Warehouse_Code
       end Warehouse_Code,
       case
         when (select sp.param_value
                 from sys_param sp
                where sp.enterprise_id = Iobh.Organization_Id
                  and sp.param_code = 'Is_Start_Old_Code_Report') = '2' then
          w.attribute21
         else
          w.Warehouse_Name
       end Warehouse_Name,
       i.Item_Code,
       i.Item_Name,
       Iobl.Qty_Invbill,
       dd.dictname Crm_Entid,
       iobl.wtpricec_bill_f
  From inv_in_bill_head Iobh,
       inv_in_bill_line Iobl,
       Item i,
       Customer c,
       customer_org co,
       Warehouse w,
       (select d.dictname, d.dictvalue, d.entid
          from cpcdict d
         where lower(d.dictcode) like 'crm_entid%') dd
 Where Iobh.Inv_In_Bill_Head_Id = Iobl.Inv_In_Bill_Head_Id
   And Iobl.Item_Id = i.Item_Id
   And Iobh.Customer_Id = c.Customer_Id
   and Iobh.Customer_Id = co.Customer_Id
   And Iobl.Warehouse_Id = w.Warehouse_Id
   and iobh.crm_entid = dd.dictvalue(+)
   and iobh.organization_id = dd.entid(+)
   And Iobh.Organization_Id = w.Organization_Id
   And Iobh.Organization_Id = co.Organization_Id
   And Iobh.Billtypecode = '0206'
   and Iobh.is_init_bill <> 2
   and Iobh.Stat = 5
   and nvl(Iobh.Is_Auditing_Wh, 0) = 2
-- And Iobh.Inv_Out_Type <> 2
 Order By Iobh.Invbillno, i.Item_Code
/

