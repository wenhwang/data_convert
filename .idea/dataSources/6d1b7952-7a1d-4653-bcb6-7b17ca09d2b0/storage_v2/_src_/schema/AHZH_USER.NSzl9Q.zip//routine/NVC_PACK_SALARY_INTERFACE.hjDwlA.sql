create PROCEDURE           NVC_PACK_SALARY_INTERFACE(I_YEAR_MONTH HR_COUNT_SALARY_HEAD.YEAR_MONTH%TYPE,
                                                      I_USERID     CPCUSER.USERID%TYPE) AS
  /*********************************************\
  * Name(名称): NVC_PACK_SALARY_INTERFACE
  * Purpose(功能说明): 根据年月,姓名将对应工资条写入临时表NVC_HR_SALARY_INTERFACE_TMP,
                       以供移动端查询
  * Author(作者): NY
  * Create At(创建时间): 2016-08-18
  \*********************************************/

  V_HR_COUNT_SALARY_LINE_ID NUMBER := 0;
BEGIN
  /*0.------------------------------------ 清空表数据*/
  EXECUTE IMMEDIATE 'TRUNCATE TABLE NVC_HR_SALARY_INTERFACE_TMP';

  /*1.------------------------------------ 查询对应工资条明细ID*/
  SELECT MAX(HR_COUNT_SALARY_LINE_ID)
    INTO V_HR_COUNT_SALARY_LINE_ID
    FROM HR_COUNT_SALARY_LINE LINE, HR_COUNT_SALARY_HEAD HEAD, CPCUSER
   WHERE LINE.HR_COUNT_SALARY_HEAD_ID = HEAD.HR_COUNT_SALARY_HEAD_ID
     AND LINE.EMPLOYEE_ID = CPCUSER.SYSUSERID
     AND HEAD.STAT = 5
     AND HEAD.YEAR_MONTH = I_YEAR_MONTH
     AND CPCUSER.USERID = I_USERID;

  /*2.------------------------------------ 查询对应工资条*/
  IF V_HR_COUNT_SALARY_LINE_ID <> 0 THEN
    INSERT INTO NVC_HR_SALARY_INTERFACE_TMP
      (LINE_NO,
       SALARY_ITEM_CAPTION,
       SALARY_ITEM_PCAPTION,
       V_FIELDNAME,
       V_VALUE,
       CALC_TYPE)
      SELECT CAPTION.LINE_NO,
             CAPTION.SALARY_ITEM_CAPTION,
             CAPTION.SALARY_ITEM_PCAPTION,
             SALARY.V_FIELDNAME,
             SALARY.V_VALUE,
             CAPTION.CALC_TYPE
        FROM (SELECT V_FIELDNAME, V_VALUE
                FROM (SELECT HEAD.BILL_NO,
                             HEAD.YEAR_MONTH,
                             CPcorg.Orgname Dept_name,
                             CPCUSER.USERID EMPLOYEE_CODE,
                             CPCUSER.USERNAME EMPLOYEE_NAME,
                             TO_CHAR(LINE.F_SALARY1) F_SALARY1,
                             TO_CHAR(LINE.F_SALARY2) F_SALARY2,
                             TO_CHAR(LINE.F_SALARY3) F_SALARY3,
                             TO_CHAR(LINE.F_SALARY4) F_SALARY4,
                             TO_CHAR(LINE.F_SALARY5) F_SALARY5,
                             TO_CHAR(LINE.F_SALARY6) F_SALARY6,
                             TO_CHAR(LINE.F_SALARY7) F_SALARY7,
                             TO_CHAR(LINE.F_SALARY8) F_SALARY8,
                             TO_CHAR(LINE.F_SALARY9) F_SALARY9,
                             TO_CHAR(LINE.F_SALARY10) F_SALARY10,
                             TO_CHAR(LINE.F_SALARY11) F_SALARY11,
                             TO_CHAR(LINE.F_SALARY12) F_SALARY12,
                             TO_CHAR(LINE.F_SALARY13) F_SALARY13,
                             TO_CHAR(LINE.F_SALARY14) F_SALARY14,
                             TO_CHAR(LINE.F_SALARY15) F_SALARY15,
                             TO_CHAR(LINE.F_SALARY16) F_SALARY16,
                             TO_CHAR(LINE.F_SALARY17) F_SALARY17,
                             TO_CHAR(LINE.F_SALARY18) F_SALARY18,
                             TO_CHAR(LINE.F_SALARY19) F_SALARY19,
                             TO_CHAR(LINE.F_SALARY20) F_SALARY20,
                             TO_CHAR(LINE.F_SALARY21) F_SALARY21,
                             TO_CHAR(LINE.F_SALARY22) F_SALARY22,
                             TO_CHAR(LINE.F_SALARY23) F_SALARY23,
                             TO_CHAR(LINE.F_SALARY24) F_SALARY24,
                             TO_CHAR(LINE.F_SALARY25) F_SALARY25,
                             TO_CHAR(LINE.F_SALARY26) F_SALARY26,
                             TO_CHAR(LINE.F_SALARY27) F_SALARY27,
                             TO_CHAR(LINE.F_SALARY28) F_SALARY28,
                             TO_CHAR(LINE.F_SALARY29) F_SALARY29,
                             TO_CHAR(LINE.F_SALARY30) F_SALARY30,
                             TO_CHAR(LINE.V_SALARY1) V_SALARY1,
                             TO_CHAR(LINE.V_SALARY2) V_SALARY2,
                             TO_CHAR(LINE.V_SALARY3) V_SALARY3,
                             TO_CHAR(LINE.V_SALARY4) V_SALARY4,
                             TO_CHAR(LINE.V_SALARY5) V_SALARY5,
                             TO_CHAR(LINE.V_SALARY6) V_SALARY6,
                             TO_CHAR(LINE.V_SALARY7) V_SALARY7,
                             TO_CHAR(LINE.V_SALARY8) V_SALARY8,
                             TO_CHAR(LINE.V_SALARY9) V_SALARY9,
                             TO_CHAR(LINE.V_SALARY10) V_SALARY10,
                             TO_CHAR(LINE.V_SALARY11) V_SALARY11,
                             TO_CHAR(LINE.V_SALARY12) V_SALARY12,
                             TO_CHAR(LINE.V_SALARY13) V_SALARY13,
                             TO_CHAR(LINE.V_SALARY14) V_SALARY14,
                             TO_CHAR(LINE.V_SALARY15) V_SALARY15,
                             TO_CHAR(LINE.V_SALARY16) V_SALARY16,
                             TO_CHAR(LINE.V_SALARY17) V_SALARY17,
                             TO_CHAR(LINE.V_SALARY18) V_SALARY18,
                             TO_CHAR(LINE.V_SALARY19) V_SALARY19,
                             TO_CHAR(LINE.V_SALARY20) V_SALARY20,
                             TO_CHAR(LINE.V_SALARY21) V_SALARY21,
                             TO_CHAR(LINE.V_SALARY22) V_SALARY22,
                             TO_CHAR(LINE.V_SALARY23) V_SALARY23,
                             TO_CHAR(LINE.V_SALARY24) V_SALARY24,
                             TO_CHAR(LINE.V_SALARY25) V_SALARY25,
                             TO_CHAR(LINE.V_SALARY26) V_SALARY26,
                             TO_CHAR(LINE.V_SALARY27) V_SALARY27,
                             TO_CHAR(LINE.V_SALARY28) V_SALARY28,
                             TO_CHAR(LINE.V_SALARY29) V_SALARY29,
                             TO_CHAR(LINE.V_SALARY30) V_SALARY30,
                             TO_CHAR(LINE.V_SALARY31) V_SALARY31,
                             TO_CHAR(LINE.V_SALARY32) V_SALARY32,
                             TO_CHAR(LINE.V_SALARY33) V_SALARY33,
                             TO_CHAR(LINE.V_SALARY34) V_SALARY34,
                             TO_CHAR(LINE.V_SALARY35) V_SALARY35,
                             TO_CHAR(LINE.V_SALARY36) V_SALARY36,
                             TO_CHAR(LINE.V_SALARY37) V_SALARY37,
                             TO_CHAR(LINE.V_SALARY38) V_SALARY38,
                             TO_CHAR(LINE.V_SALARY39) V_SALARY39,
                             TO_CHAR(LINE.V_SALARY40) V_SALARY40,
                             TO_CHAR(LINE.V_SALARY41) V_SALARY41,
                             TO_CHAR(LINE.V_SALARY42) V_SALARY42,
                             TO_CHAR(LINE.V_SALARY43) V_SALARY43,
                             TO_CHAR(LINE.V_SALARY44) V_SALARY44,
                             TO_CHAR(LINE.V_SALARY45) V_SALARY45,
                             TO_CHAR(LINE.V_SALARY46) V_SALARY46,
                             TO_CHAR(LINE.V_SALARY47) V_SALARY47,
                             TO_CHAR(LINE.V_SALARY48) V_SALARY48,
                             TO_CHAR(LINE.V_SALARY49) V_SALARY49,
                             TO_CHAR(LINE.V_SALARY50) V_SALARY50,
                             TO_CHAR(LINE.V_SALARY51) V_SALARY51,
                             TO_CHAR(LINE.V_SALARY52) V_SALARY52,
                             TO_CHAR(LINE.V_SALARY53) V_SALARY53,
                             TO_CHAR(LINE.V_SALARY54) V_SALARY54,
                             TO_CHAR(LINE.V_SALARY55) V_SALARY55,
                             TO_CHAR(LINE.V_SALARY56) V_SALARY56,
                             TO_CHAR(LINE.V_SALARY57) V_SALARY57,
                             TO_CHAR(LINE.V_SALARY58) V_SALARY58,
                             TO_CHAR(LINE.V_SALARY59) V_SALARY59,
                             TO_CHAR(LINE.V_SALARY60) V_SALARY60,
                             TO_CHAR(LINE.V_SALARY61) V_SALARY61,
                             TO_CHAR(LINE.V_SALARY62) V_SALARY62,
                             TO_CHAR(LINE.V_SALARY63) V_SALARY63,
                             TO_CHAR(LINE.V_SALARY64) V_SALARY64,
                             TO_CHAR(LINE.V_SALARY65) V_SALARY65,
                             TO_CHAR(LINE.V_SALARY66) V_SALARY66,
                             TO_CHAR(LINE.V_SALARY67) V_SALARY67,
                             TO_CHAR(LINE.V_SALARY68) V_SALARY68,
                             TO_CHAR(LINE.V_SALARY69) V_SALARY69,
                             TO_CHAR(LINE.V_SALARY70) V_SALARY70,
                             TO_CHAR(LINE.IS_DIMISSION) IS_DIMISSION,
                             TO_CHAR(LINE.IS_PATCH) IS_PATCH,
                             TO_CHAR(LINE.IS_PATCHED) IS_PATCHED,
                             TO_CHAR(LINE.IDCARD) IDCARD,
                             TO_CHAR(LINE.BANK_ACC) BANK_ACC,
                             TO_CHAR(LINE.BANK) BANK,
                             TO_CHAR(LINE.ACC_NAME) ACC_NAME,
                             TO_CHAR(LINE.PAY_AMOUNT) PAY_AMOUNT,
                             TO_CHAR(LINE.LINE_REMARK) LINE_REMARK,
                             TO_CHAR(LINE.ATTRIBUTE11) ATTRIBUTE11,
                             TO_CHAR(LINE.ATTRIBUTE21) ATTRIBUTE21,
                             TO_CHAR(LINE.ATTRIBUTE31) ATTRIBUTE31,
                             TO_CHAR(LINE.ATTRIBUTE41) ATTRIBUTE41,
                             TO_CHAR(LINE.ATTRIBUTE51) ATTRIBUTE51
                        FROM HR_COUNT_SALARY_LINE LINE,
                             HR_COUNT_SALARY_HEAD HEAD,
                             CPCUSER,
                             cpcorg
                       WHERE LINE.HR_COUNT_SALARY_HEAD_ID =
                             HEAD.HR_COUNT_SALARY_HEAD_ID
                         AND LINE.EMPLOYEE_ID = CPCUSER.SYSUSERID(+)
                         AND LINE.Dept_ID = cpcorg.orgid(+)
                         AND HEAD.STAT = 5
                         AND LINE.HR_COUNT_SALARY_LINE_ID =
                             V_HR_COUNT_SALARY_LINE_ID) SALARY UNPIVOT(V_VALUE FOR V_FIELDNAME IN (BILL_NO, YEAR_MONTH, Dept_name, EMPLOYEE_CODE, EMPLOYEE_NAME, F_SALARY1, F_SALARY2, F_SALARY3, F_SALARY4, F_SALARY5, F_SALARY6, F_SALARY7, F_SALARY8, F_SALARY9, F_SALARY10, F_SALARY11, F_SALARY12, F_SALARY13, F_SALARY14, F_SALARY15, F_SALARY16, F_SALARY17, F_SALARY18, F_SALARY19, F_SALARY20, F_SALARY21, F_SALARY22, F_SALARY23, F_SALARY24, F_SALARY25, F_SALARY26, F_SALARY27, F_SALARY28, F_SALARY29, F_SALARY30, V_SALARY1, V_SALARY2, V_SALARY3, V_SALARY4, V_SALARY5, V_SALARY6, V_SALARY7, V_SALARY8, V_SALARY9, V_SALARY10, V_SALARY11, V_SALARY12, V_SALARY13, V_SALARY14, V_SALARY15, V_SALARY16, V_SALARY17, V_SALARY18, V_SALARY19, V_SALARY20, V_SALARY21, V_SALARY22, V_SALARY23, V_SALARY24, V_SALARY25, V_SALARY26, V_SALARY27, V_SALARY28, V_SALARY29, V_SALARY30, V_SALARY31, V_SALARY32, V_SALARY33, V_SALARY34, V_SALARY35, V_SALARY36, V_SALARY37, V_SALARY38, V_SALARY39, V_SALARY40, V_SALARY41, V_SALARY42, V_SALARY43, V_SALARY44, V_SALARY45, V_SALARY46, V_SALARY47, V_SALARY48, V_SALARY49, V_SALARY50, V_SALARY51, V_SALARY52, V_SALARY53, V_SALARY54, V_SALARY55, V_SALARY56, V_SALARY57, V_SALARY58, V_SALARY59, V_SALARY60, V_SALARY61, V_SALARY62, V_SALARY63, V_SALARY64, V_SALARY65, V_SALARY66, V_SALARY67, V_SALARY68, V_SALARY69, V_SALARY70, IS_DIMISSION, IS_PATCH, IS_PATCHED, IDCARD, BANK_ACC, BANK, ACC_NAME, PAY_AMOUNT, LINE_REMARK, ATTRIBUTE11, ATTRIBUTE21, ATTRIBUTE31, ATTRIBUTE41, ATTRIBUTE51))) SALARY,
             (SELECT CAPTION.LINE_NO,
                     CAPTION.SALARY_ITEM_CODE,
                     CAPTION.SALARY_ITEM_CAPTION,
                     CAPTION.SALARY_ITEM_PCAPTION,
                     CAPTION.CALC_TYPE
                FROM HR_COUNT_SALARY_CAPTION CAPTION
               WHERE CAPTION.HR_COUNT_SALARY_HEAD_ID < 0
              --AND CAPTION.CALC_TYPE = 1
              UNION
              SELECT -99 LINE_NO,
                     'BILL_NO' SALARY_ITEM_CODE,
                     '薪资单号' SALARY_ITEM_CAPTION,
                     '' SALARY_ITEM_PCAPTION,
                     3 CALC_TYPE
                FROM DUAL
              UNION
              SELECT -98 LINE_NO,
                     'YEAR_MONTH' SALARY_ITEM_CODE,
                     '薪资月份' SALARY_ITEM_CAPTION,
                     '' SALARY_ITEM_PCAPTION,
                     3 CALC_TYPE
                FROM DUAL) CAPTION
       WHERE LOWER(SALARY.V_FIELDNAME) = LOWER(CAPTION.SALARY_ITEM_CODE)
       ORDER BY LINE_NO;
  END IF;
  COMMIT;
  /*3.------------------------------------ 查询结果*/
  --SELECT * FROM NVC_HR_SALARY_INTERFACE_TMP;
END;
/

