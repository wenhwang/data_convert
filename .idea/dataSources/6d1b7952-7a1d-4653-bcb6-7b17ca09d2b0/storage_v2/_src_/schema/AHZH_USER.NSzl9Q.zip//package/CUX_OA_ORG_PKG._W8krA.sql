create PACKAGE           cux_oa_org_pkg IS
  /*==================================================
  PROGRAM NAME:
      CUX_OA_ORG_PKG
  DESCRIPTION:

  HISTORY:
      1.00  2016-07-07  OA    CREATION
  ==================================================*/
  /*=============================================
  FUNCTION  Name:
      get_org_path
  Description:
      获取组织路径
  Argument:

  Return:

  History:
      1.00  2016-07-07 OA    Creation
  =============================================*/
  FUNCTION get_org_path(p_idpath IN VARCHAR2) RETURN VARCHAR2;
  /*=============================================
  FUNCTION  Name:
      get_user_orgpath
  Description:
      获取用户组织路径
  Argument:

  Return:

  History:
      1.00  2016-07-07 OA    Creation
  =============================================*/
  FUNCTION get_user_orgpath(p_sysuserid IN NUMBER) RETURN VARCHAR2;

   /*=============================================
  FUNCTION  Name:
      get_user_positions
  Description:
      获取用户职位
  Argument:

  Return:

  History:
      1.00  2016-07-07 OA    Creation
  =============================================*/
  FUNCTION get_user_positions(p_sysuserid IN NUMBER) RETURN VARCHAR2;

     /*=============================================
  FUNCTION  Name:
      get_user_orgids
  Description:
      获取用户机构id
  Argument:

  Return:

  History:
      1.00  2016-07-07 OA    Creation
  =============================================*/
  FUNCTION get_user_orgids(p_sysuserid IN NUMBER) RETURN VARCHAR2;
END cux_oa_org_pkg;
/

