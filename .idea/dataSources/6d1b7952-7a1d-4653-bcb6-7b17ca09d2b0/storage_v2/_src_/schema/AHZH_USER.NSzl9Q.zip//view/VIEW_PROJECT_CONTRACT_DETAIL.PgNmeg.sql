create view VIEW_PROJECT_CONTRACT_DETAIL as
SELECT PROJECT_ID, --项目ID
       PROJECT_CONTRACT_ID, --合同编号ID
       PROJECT_CONTRACT_CODE, --合同编号
       PROJECT_CONTRACT_NAME, --合同名称
       PROJECT_CONTRACT_CHARACTER, --合同性质(1|项目(总包)合同,2|分包合同,3|维保合同)
       PROJECT_CONTRACT_TYPE, --合同类型(来源词汇值，如：销售、安装等)
       CONTRACT_AMOUNT, --合同金额
       CONTRACT_NUMBER, --合同份数
       INVOICE_TYPE, --开票类型
       FIRST_PARTY_NAME, --甲方
       FIRST_PARTY_LINKMAN, --甲方授权人
       FIRST_PARTY_PHONENO, --甲方联系方式
       SIGNUP_DATE, --签订时间
       SIGNUP_ADDRESS, --签订地址
       PROJECT_MANAGER_ID, --项目经理
       START_TIME, --工期
       ACCEPTANCE_CRITERIA, --验收标准
       GUARANTEE_PERIOD, --质保期
       GUARANTEE_AMOUNT, --质保金
       PERFORMANCE_SECURITY --履约保证金
  FROM EPM_PROJECT_CONTRACT
 WHERE NVL(PROJECT_CONTRACT_CHARACTER, 0) = 1
   AND STAT = 5
  /*********************************************\
  * NAME(名称): VIEW_PROJECT_CONTRACT_DETAIL
  * PURPOSE(功能说明):  总包合同明细
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2019-07-19
  \*********************************************/
/

