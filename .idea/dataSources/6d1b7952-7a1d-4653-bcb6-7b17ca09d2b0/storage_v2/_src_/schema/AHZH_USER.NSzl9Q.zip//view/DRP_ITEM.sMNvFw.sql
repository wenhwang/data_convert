create view DRP_ITEM as
select a.item_id          item_id,
       a.item_code        item_code,
       a.item_name        item_name,
       a.item_desc        item_short_name,
       b.specs            spec,
       c.item_class_id    bigc_id,
       c.item_class_code  bigc_code,
       c.item_class_name  bigc_name,
       d.item_class_id    smallc_id,
       d.item_class_code  smallc_code,
       d.item_class_name  smallc_name,
       e.item_class_id series_id,
       e.item_class_code series_code,
       e.item_class_name series_name,
       b.can_sale         is_sale,
       b.item_usable      usable,
       a.created_by       creator,
       a.creation_date    create_time,
       a.last_update_date update_time,
       b.organization_id  organization_id,
       b.organization_id  entid,
       b.note             note
  from item a, item_org b, item_class c, item_class d,item_class e
 where b.is_csspj<>2
   and a.item_id = b.item_id
   and b.item_class2 = c.item_class_id(+)
   and b.item_class1 = d.item_class_id(+)
   and b.item_class3 = e.item_class_id(+)
/

