create Function           Fn_Scm_Item_Stock_Run_Qty(p_Organization_Id Number,
                                                      p_Item_Id         Number,
                                                      StockType         Number)
  Return Number Is
  Rcv_Qty Number;
  ---寰？？？ュ？阅?
  --StockType 浠揿？绫诲？锛?锛？？寮？？锛?锛氩？妫？浠?
  --銮峰？？备？杩？？镄？？搴？？？╂？搴揿？
Begin
  select sum(i.qty_onhand)
    into Rcv_Qty
    from inv_current_inv i, warehouse w,mes_whmrprunset mw
   where i.organization_id = w.organization_id and
         i.warehouse_id = w.warehouse_id and i.item_id = p_Item_Id and
         i.organization_id = p_Organization_Id and
         mw.organization_id = p_Organization_Id and
         w.warehouse_id=mw.warehouse_id and
         mw.is_run=2 and
         w.warehouse_type = StockType;
  Return Nvl(Rcv_Qty, 0);
End Fn_Scm_Item_Stock_Run_Qty;
/

