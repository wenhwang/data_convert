create view VIEW_PARTNER_LOAN_LIST as
SELECT 2 BILL_TYPE, --业务单据金额
       HEAD.LOAN_NO BILL_NO,
       HEAD.PROJECT_ID,
       NVL(LINE.ALLOW_AMT, 0) AMOUNT
  FROM MKT_LOAN_LINE LINE, MKT_LOAN_HEADER HEAD, FD_PAYMENT_TYPE
 WHERE HEAD.LOAN_ID = LINE.LOAN_ID
   AND HEAD.BUSINESS_TYPE = FD_PAYMENT_TYPE.FD_PAYMENT_TYPE_ID
   AND UPDATE_FIELD = 'BORROW_AMOUNT' --公司借支
   AND NVL(HEAD.PROJECT_ID, 0) <> 0
   AND HEAD.STAT = 5

/*********************************************\
 * NAME(名称): VIEW_PARTNER_LOAN_LIST
  * PURPOSE(功能说明):  合伙人借支明细(不计入项目往来余额)
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-04-17
\*********************************************/
/

