create view V_INV_IN_BILL_A3 as
select mc.organization_id, mc.organization_name,sc.diffbill_no,sc.item_code,sc.item_name,sc.qty,sc.received_qty,sc.diff_qty
     from srm_crm_interface sc, mis_crm_collate mc
    where sc.entid = 999
      and sc.cust_code = mc.crm_customer_code(+)
      and mc.crm_entid = 999
/

