create PROCEDURE PRO_REDONE_BX_PAYMENT AS
  /*********************************************\
  * NAME(名称): PRO_REDONE_PUR_PAYMENT
  * PURPOSE(功能说明):  以付款单为基准更新费用报销单中本次已付款金额
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2017-11-29
  \*********************************************/
BEGIN

  UPDATE FIN_FEE_BX_LINE LINE
     SET LINE.PAY_AMT = (SELECT AMOUNT_CREDIT
                           FROM (SELECT IS_WB BILL_ID,
                                        NVL(SUM(AMOUNT_CREDIT), 0) AMOUNT_CREDIT
                                   FROM FD_FUND_BUSINESS
                                  WHERE NVL(IS_WB, 0) <> 0
                                    AND SYSCREATE_TYPE = 4 --4|费用报销
                                    AND STAT = 5 --已审核
                                    AND IS_AP_FUND = 2 --是否销售回款
                                    AND RECORD_TYPE = 3
                                  GROUP BY IS_WB)
                          WHERE BX_LINE_ID = BILL_ID)
   WHERE EXISTS (SELECT 1
            FROM (SELECT IS_WB BILL_ID
                    FROM FD_FUND_BUSINESS
                   WHERE NVL(IS_WB, 0) <> 0
                     AND SYSCREATE_TYPE = 4 --4|费用报销
                     AND STAT = 5 --已审核
                     AND IS_AP_FUND = 2 --是否销售回款
                     AND RECORD_TYPE = 3 --回款
                  )
           WHERE BX_LINE_ID = BILL_ID);

  COMMIT;
END;
/

