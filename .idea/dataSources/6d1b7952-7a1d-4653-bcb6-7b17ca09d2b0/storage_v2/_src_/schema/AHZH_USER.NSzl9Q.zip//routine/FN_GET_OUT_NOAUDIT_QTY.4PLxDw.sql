create Function           Fn_Get_Out_Noaudit_Qty(p_Organization_Id Number,
                                                  p_Item_Id         In Number,
                                                  p_Warehouse_Id    In Number)
  Return Number Is
  Result Number;
Begin
  Select Nvl(Sum(Iobl.Qty_Bill), 0)
    Into Result
    From Inv_Out_Bill_Head Iobh, Inv_Out_Bill_Line Iobl
   Where Iobh.Inv_Out_Bill_Head_Id = Iobl.Inv_Out_Bill_Head_Id
     And Iobl.Item_Id = p_Item_Id
     And Iobl.Warehouse_Id = p_Warehouse_Id
     And Iobh.Is_Auditing_Wh = 1
     And Iobh.Stat <> 5
     And Iobh.Organization_Id = p_Organization_Id;
  Return Nvl(Result, 0);
End Fn_Get_Out_Noaudit_Qty;
/

