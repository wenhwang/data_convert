create view VIEW_ZIYUAN_IN_BILL_LIST as
select distinct iibh.invbillno,
                iibh.invbilldate,
                iibh.year_month,
                i.item_code,
                i.item_name,
                w.warehouse_code,
                w.warehouse_name,
                v.vendor_code,
                v.vendor_name,
                iibh.created_by,
                iibh.creation_date,
                iibh.note,
                iibh.is_auditing_wh,
                iibl.line_no,
                iibl.qty_invbill,
                iibl.price_bill,
                iibl.amount_bill_f,
                u.uom_name,
                iibh.vendorbillno
  from inv_in_bill_head iibh,
       inv_in_bill_line iibl,
       item i,
       uom u,
       vendor v,
       warehouse w,
       (select entid, dictname, dictvalue
          from cpcdict
         where dictcode like 'crm_entid%') dict
 where iibh.inv_in_bill_head_id = iibl.inv_in_bill_head_id
   and iibh.vendor_id = v.vendor_id
   and iibl.item_id = i.item_id
   and iibl.uom_id = u.uom_id(+)
   and iibl.warehouse_id = w.warehouse_id
   and iibh.organization_id = dict.entid
   and iibh.attribute4 = 3
/

