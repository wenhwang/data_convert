create Function           Fn_Hr_GetTI(money varchar2,
                              year_month Varchar2,
                              organization_id Varchar2)
 Return varchar2 Is
  v_sql Varchar2(3000);
  /**
   * 璁＄？？跺？
   * @money: 搴？撼绋？？寰？？
   * @year_month: ？？？璁＄？链？唤
   * @organization_id: ？？？璁＄？缁？？ID
   *
   *  瀛？？涓叉浔浠剁？ {}镟挎？''锛?
   *   eg: year_month = '2010-10'？？？ year_month = {2010-10}
   */
Begin
/*
  璁＄？？跺？锛？？绾崇？镓？寰？？锛？捣寰？？
  ？？？？？链？？涓？？？朵腑update？椤？澶？溃
 update hr_count_salary_line t
   set f_salary5 = 3+(select F_SALARY24 - start_point
                      from hr_persontax_stpoint y
                     where hr_persontax_area_id = t.hr_persontax_area_id
                       and start_month =
                           (select max(start_month)
                              from hr_persontax_stpoint
                             where hr_persontax_area_id = t.hr_persontax_area_id
                               and start_month <= '2010-09'
                               and organization_id = 40)
                       and organization_id = 40)
 Where hr_count_salary_head_id = 1
*/

  v_sql := 'nvl((select case when nvl('||money||',0) - nvl(start_point,0) < 0 then 0'
         ||'        else nvl('||money||',0) - nvl(start_point,0) end '
         ||' from hr_persontax_stpoint '
         ||' where hr_persontax_area_id = t.hr_persontax_area_id'
         ||' and start_month ='
         ||'    (select max(start_month)'
         ||'       from hr_persontax_stpoint'
         ||'      where hr_persontax_area_id = t.hr_persontax_area_id'
         ||'        and start_month <= {'||year_month||'}'
         ||'        and organization_id = '||organization_id||')'
         ||' and organization_id = '||organization_id||'),0)';

  return v_sql;

End Fn_Hr_GetTI;
/

