create view DEPT as
select a.orgid as dept_id,
       case
         when a.code is not null then
          a.code
         else
          a.orgname
       end as dept_code,
       orgname as DEPT_NAME,
       entid,
       idpath,
       SUPERID as dept_pid/*,
       a.idpath,
       Fn_Get_Str_No(a.idpath, '\') as deptlevel*/
  from cpcorg a
  where nvl(a.stat,1)<>1
/

