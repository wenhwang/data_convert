create Procedure           Create_In_Ar_Invoice(p_Inv_In_Bill_Head_Id Number,
                                                 p_Organization_Id     Number,
                                                 p_Invoice_Bill_No     Varchar2) Is
  t_Ar_Invoice_Head_Id Number;
  t_Ar_Invoice_Line_Id Number;
  t_Dept_Id            Number;
  t_Customer_Id        Number;
  t_Bank               Varchar2(90);
  t_Bank_No            Varchar2(64);
  t_Base_Currency_Id   Number;
  t_Tax_Rate           Number;
  t_Exch_Rate          Number;
  t_Date_Invbill       Date;
  t_Invoice_Line_No    Number := 0;
  t_Refer_No           Varchar2(30);
  t_Note               Varchar2(2000);
  t_Days_Gathering     Number := 0;
  t_created_by         varchar2(45);
  t_last_updated_by    varchar2(45);
  t_crm_entid          Number;
  t_entorgid           Number;
  v_count              number := 0;
  /**
  * Modified By: DingHua 2009.9.22
  * Description: 允许直接销售退货，所以销售订单要改成左关联
  *
  * Modified By: DingHua 2010.3.26
  * Description: 屏蔽 commit
  */

  --出库表明细游标
  Cursor Invinbillline Is
    Select nvl(Sobl.Sa_Out_Bill_Head_Id, 0) Sa_Out_Bill_Head_Id,
           nvl(Iibl.Sa_Out_Bill_Line_Id, 0) Sa_Out_Bill_Line_Id,
           Iibl.Inv_In_Bill_Head_Id,
           Iibl.Inv_In_Bill_Line_Id,
           Iibl.Item_Id,
           Iibl.Qty_Invbill,
           nvl(Sobl.Price_Bill_Notax_f, 0) as Pricec_Bill_Notax_f,
           Iibl.Wtpricec_Bill_f,
           (Iibl.Qty_Invbill * Iibl.Wtpricec_Bill_f) as Amount_Bill_Notax_f
      From Inv_In_Bill_Line Iibl, Sa_Out_Bill_Line Sobl
     Where Iibl.Sa_Out_Bill_Line_Id = Sobl.Sa_Out_Bill_Line_Id(+)
       And Iibl.Inv_In_Bill_Head_Id = p_Inv_In_Bill_Head_Id;
Begin
  --如果已经生成发票了，就不要再生成了。
  select count(*)
    into v_count
    from ar_invoice_line al
   where al.Inv_In_Bill_Head_Id = p_Inv_In_Bill_Head_Id;
  if v_count = 0 then
    --查询入库单表头数据
    Select Sq_Ar_Invoice_Head.Nextval,
           Iibh.Dept_Id,
           Iibh.Customer_Id,
           Co.Bank,
           Co.Bank_Accno,
           1 Base_Currency_Id,
           Co.Tax_Rate,
           Iibh.Invbilldate,
           Iibh.Invbillno,
           Iibh.Note,
           nvl(co.Days_Gathering, 0) Days_Gathering,
           iibh.created_by,
           iibh.last_updated_by,
           Iibh.Crm_Entid,
           Iibh.Entorgid
      Into t_Ar_Invoice_Head_Id,
           t_Dept_Id,
           t_Customer_Id,
           t_Bank,
           t_Bank_No,
           t_Base_Currency_Id,
           t_Tax_Rate,
           t_Date_Invbill,
           t_Refer_No,
           t_Note,
           t_Days_Gathering,
           t_created_by,
           t_last_updated_by,
           t_crm_entid,
           t_entorgid
      From Inv_In_Bill_Head Iibh, Customer_Org Co
     Where Iibh.Customer_Id = Co.Customer_Id(+)
       And Co.Organization_Id(+) = p_Organization_Id
       And Iibh.Inv_In_Bill_Head_Id = p_Inv_In_Bill_Head_Id;
    --取汇率
    Select Nvl(Decode(Ismaster, 2, 1, Er.Exch_Rate), 0)
      Into t_Exch_Rate
      From Base_Currency Bc, Exchange_Rate Er
     Where Bc.Base_Currency_Id = Er.Base_Currency_Id(+)
       And Bc.Base_Currency_Id = t_Base_Currency_Id
       And Er.Exch_Month(+) = To_Char(t_Date_Invbill, 'YYYY-MM')
       And Rownum = 1;
    --插入表头
    Insert Into Ar_Invoice_Head
      (Organization_Id,
       Ar_Invoice_Head_Id,
       Invoice_Bill_No,
       Invoicet_Property,
       Invoice_Type,
       Bill_Type,
       Export_Trade_Type,
       Is_Auditing,
       Is_Credence,
       Dept_Id,
       Customer_Id,
       Bank,
       Bank_No,
       Base_Currency_Id,
       Tax_Rate,
       Exch_Rate,
       Date_Invoice,
       Date_Bill,
       Year_Month,
       Refer_No,
       Note,
       GATHERING_DATE,
       created_by,
       last_updated_by,
       crm_entid,
       entorgid)
    Values
      (p_Organization_Id,
       t_Ar_Invoice_Head_Id,
       p_Invoice_Bill_No,
       3,
       0,
       1,
       1,
       2,
       1,
       t_Dept_Id,
       t_Customer_Id,
       t_Bank,
       t_Bank_No,
       t_Base_Currency_Id,
       t_Tax_Rate,
       t_Exch_Rate,
       t_Date_Invbill,
       t_Date_Invbill,
       To_Char(t_Date_Invbill, 'YYYY-MM'),
       t_Refer_No,
       t_Note,
       t_Date_Invbill + t_Days_Gathering,
       t_created_by,
       t_last_updated_by,
       t_crm_entid,
       t_entorgid);
    --  Commit;
    --循环插入明细
    For Rec In Invinbillline Loop
      Select Sq_Ar_Invoice_Line.Nextval
        Into t_Ar_Invoice_Line_Id
        From Dual;
      t_Invoice_Line_No := t_Invoice_Line_No + 1;
      Insert Into Ar_Invoice_Line
        (Ar_Invoice_Line_Id,
         Ar_Invoice_Head_Id,
         Invoice_Line_No,
         Sa_Out_Bill_Head_Id,
         Sa_Out_Bill_Line_Id,
         Inv_In_Bill_Head_Id,
         Inv_In_Bill_Line_Id,
         Item_Id,
         Qty_Bill,
         Price_Tax,
         Price_Notax,
         Amount_Notax,
         Amount_Tax,
         Amount_Bill,
         Bill_Type_Match)
      Values
        (t_Ar_Invoice_Line_Id,
         t_Ar_Invoice_Head_Id,
         t_Invoice_Line_No,
         Rec.Sa_Out_Bill_Head_Id,
         Rec.Sa_Out_Bill_Line_Id,
         Rec.Inv_In_Bill_Head_Id,
         Rec.Inv_In_Bill_Line_Id,
         Rec.Item_Id,
         -rec.Qty_Invbill,
         Rec.Wtpricec_Bill_f, -- 含税价
         Rec.Wtpricec_Bill_f / (1 + t_Tax_Rate / 100.000000), -- 未税价
         /*       Round(Rec.Wtpricec_Bill_f * 1 / (1 + t_Tax_Rate / 100.000000) *
               (-rec.Qty_Invbill),
               2),
         Round(Rec.Wtpricec_Bill_f * (-rec.Qty_Invbill), 2) -
         Round(Rec.Wtpricec_Bill_f * 1 / (1 + t_Tax_Rate / 100.000000) *
               (-rec.Qty_Invbill),
               2),*/
         round(Round(Rec.Wtpricec_Bill_f * (-rec.Qty_Invbill), 2) -
               Round(Rec.Wtpricec_Bill_f / (1 + t_Tax_Rate / 100.000000) *
                     (t_Tax_Rate / 100.000000) * (-rec.Qty_Invbill),
                     2),
               2), -- 货款 = 发票金额 - 税款

         Round(Rec.Wtpricec_Bill_f / (1 + t_Tax_Rate / 100.000000) *
               (t_Tax_Rate / 100.000000) * (-rec.Qty_Invbill),
               2), -- 税款 = 发票金额 ÷1.17 ×0.17

         Round(Rec.Wtpricec_Bill_f * (-rec.Qty_Invbill), 2), -- 发票金额
         2);
      --更新出库单发票匹配数量金额
      Update Inv_In_Bill_Line Iibl
         Set Iibl.Qty_Match_Total = Iibl.Qty_Invbill
       Where Iibl.Inv_In_Bill_Line_Id = Rec.Inv_In_Bill_Line_Id;
      --更新销售订单发票匹配数量金额
      Update Sa_Out_Bill_Line Sobl
         Set Sobl.Qty_Cancel_Invoice = Nvl(Sobl.Qty_Cancel_Invoice, 0) -
                                       Rec.Qty_Invbill
       Where Sobl.Sa_Out_Bill_Line_Id = Rec.Sa_Out_Bill_Line_Id;
    End Loop;
    --  Commit;

    --更新发票表头金额
    Update Ar_Invoice_Head Aih
       Set (Aih.Amount_Tax_f, Aih.Amount_Bill_f, Aih.Amount_Goods_f) =
           (Select nvl(Sum(Ail.Amount_Tax), 0) Amount_Tax,
                   nvl(Sum(Ail.Amount_Tax), 0) +
                   nvl(Sum(Ail.Amount_Notax), 0) Amount_Notax,
                   nvl(Sum(Ail.Amount_Notax), 0) Amount_Goods_f
              From Ar_Invoice_Line Ail
             Where Ail.Ar_Invoice_Head_Id = Aih.Ar_Invoice_Head_Id)
     Where Aih.Ar_Invoice_Head_Id = t_Ar_Invoice_Head_Id;
    --Commit;

    -- Modified By: DingHua 2010.4.7
    -- Description: 系统生成发票，退货入库单不用生成凭证，故更新为已生成凭证状态
    update inv_in_bill_head iibh
       set iibh.iscredence = 2
     where iibh.inv_in_bill_head_id = p_Inv_In_Bill_Head_Id;
  end if;
Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, Sqlerrm);
End Create_In_Ar_Invoice;
/

