create view V_CUSTOMER_DP as
select a.customer_id, a.customer_code, a.customer_name, b.sale_type, b.dept_id, b.organization_id,b.Sale_Employee_Id,
d.address1, d.take_man, d.phone_code,
c.entid, c.entname from customer a,  customer_org b, cpcent c, customer_address d
where a.customer_id = b.customer_id
and b.organization_id = c.entid
and a.customer_id = d.customer_id
/

