create view CHARGE_ITEM as
select ffh.organization_id,
       ffh.fee_id as charge_item_id,
       ffh.fee_code as charge_item_code,
       ffh.fee_name as charge_item_name,
       2 as is_control,
       2 as is_relate_cash,
       0 as tax_rate,
       2 as is_execute,
       1 as charge_item_type,
       'M' as control_type,
       2 as is_end,
       0 as charge_item_pid,
       '\' || ffh.fee_id || '\' as charge_item_idpath,
       '\' || ffh.fee_id || '\' as idpath,
       '' as remark,
       '' as created_by,
       sysdate as creation_date,
       '' as last_updated_by,
       sysdate as last_updated_date,
       ffh.subject_id as gl_account_subject_id,
       decode(ffh.stat,0,2,2,2,1) is_usable
  from fin_fee_header ffh
/

