create view VIEW_INV_WH_CTRL as
SELECT distinct h.EMPLOYEE_CODE as CPCUSERID,
       W."ORGANIZATION_ID",W."WAREHOUSE_ID",W."WAREHOUSE_CODE",W."WAREHOUSE_NAME",W."VENDOR_ADDRESS_ID",W."USABLE",W."WAREHOUSE_TYPE",W."WAREHOUSE_PROPERTY",W."IS_END",W."ITEM_CLASS_ID",W."IS_CALCULATE_COST",W."WAREHOUSE_PID",W."WAREHOUSE_IDPATH",W."IDPATH",W."NOTE",W."CREATED_BY",W."CREATION_DATE",W."LAST_UPDATED_BY",W."LAST_UPDATE_DATE",W."ATTRIBUTE11",W."ATTRIBUTE21",W."ATTRIBUTE31",W."ATTRIBUTE41",W."ATTRIBUTE51"
       ,W.customer_id,cu.customer_code,cu.customer_name,w.address_name
       ,w.terminal_id,mt.terminal_code,mt.terminal_name,w.asset_property,w.is_wl,
       w.is_zb,w.is_service,w.orgid,w.fix_org_id
FROM   INV_WH_CTRL I,
       WAREHOUSE   W,
       erpemployee h,
       customer cu,
       mkt_terminal mt
WHERE  I.ORGANIZATION_ID = W.ORGANIZATION_ID AND
       I.WAREHOUSE_ID = W.WAREHOUSE_ID AND
       i.cpcuserid=h.EMPLOYEE_ID and
       w.customer_id=cu.customer_id(+)
       and w.terminal_id=mt.terminal_id(+)
       and W.IS_END = 2
/

