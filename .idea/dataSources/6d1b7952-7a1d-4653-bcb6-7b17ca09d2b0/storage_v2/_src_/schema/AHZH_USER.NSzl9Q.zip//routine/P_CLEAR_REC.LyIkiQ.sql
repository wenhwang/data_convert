create PROCEDURE           P_CLEAR_REC IS
BEGIN
  DECLARE
    TYPE RS_CURSOR IS REF CURSOR;
    RS        RS_CURSOR;
    STR       VARCHAR2(100);
    TABLENAME VARCHAR(100);
  BEGIN
    OPEN RS FOR
      SELECT original_name
        INTO TABLENAME
        FROM user_recyclebin
       WHERE original_name LIKE 'TMP%'  and type='TABLE' and substr(droptime,1,10)<to_char(sysdate-7,'yyyy-mm-dd') ;

    LOOP
      FETCH RS
        INTO TABLENAME;
      EXIT WHEN RS%NOTFOUND;

      STR := 'purge table ' || TABLENAME;
      EXECUTE IMMEDIATE STR;
      --DBMS_OUTPUT.PUT_LINE(STR);
    END LOOP;
    CLOSE RS;

     OPEN RS FOR
      SELECT original_name
        INTO TABLENAME
        FROM user_recyclebin
       WHERE original_name LIKE 'TEMP%'  and type='TABLE'  and substr(droptime,1,10)<to_char(sysdate-7,'yyyy-mm-dd') ;

    LOOP
      FETCH RS
        INTO TABLENAME;
      EXIT WHEN RS%NOTFOUND;

      STR := 'purge table ' || TABLENAME;
      EXECUTE IMMEDIATE STR;
      --DBMS_OUTPUT.PUT_LINE(STR);
    END LOOP;
    CLOSE RS;


    OPEN RS FOR
      SELECT original_name
        INTO TABLENAME
        FROM user_recyclebin
       WHERE original_name LIKE 'TCL%'  and type='TABLE'  and substr(droptime,1,10)<to_char(sysdate-7,'yyyy-mm-dd')  ;

    LOOP
      FETCH RS
        INTO TABLENAME;
      EXIT WHEN RS%NOTFOUND;

      STR := 'purge table ' || TABLENAME;
      EXECUTE IMMEDIATE STR;
      --DBMS_OUTPUT.PUT_LINE(STR);
    END LOOP;
    CLOSE RS;



    OPEN RS FOR
      SELECT original_name
        INTO TABLENAME
        FROM user_recyclebin
       WHERE original_name LIKE 'IX%'  and type='INDEX'  and substr(droptime,1,10)<to_char(sysdate-7,'yyyy-mm-dd') ;

    LOOP
      FETCH RS
        INTO TABLENAME;
      EXIT WHEN RS%NOTFOUND;

      STR := 'purge index ' || TABLENAME;
      EXECUTE IMMEDIATE STR;
      --DBMS_OUTPUT.PUT_LINE(STR);
    END LOOP;
    CLOSE RS;


    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RAISE_APPLICATION_ERROR(-20001, SQLERRM);
  END;
END P_CLEAR_REC;
/

