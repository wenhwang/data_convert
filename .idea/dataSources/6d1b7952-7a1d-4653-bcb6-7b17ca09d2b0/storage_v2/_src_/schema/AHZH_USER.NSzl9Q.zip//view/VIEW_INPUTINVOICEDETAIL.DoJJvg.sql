create view VIEW_INPUTINVOICEDETAIL as
SELECT "PROJECT_CODE",
       "PROJECT_NAME",
       "BILL_NO",
       "BILL_DATE",
       "VENDOR_NAME",
       "INVOICE_CLASS_NAME",
       "PUR_CONTRACT_CODE",
       "INVOICE_QTY",
       "INVOICE_TYPE_NAME",
       "INVOICE_DATE",
       "INVOICE_NUMBER",
       "INVOICE_CONTENT",
       "INVOICE_AMOUNT",
       "TAX_RATE",
       "TAX_AMOUNT"
  FROM (SELECT PROJECT_CODE,
               PROJECT_NAME,
               HEAD.BILL_NO,
               HEAD.BILL_DATE,
               VENDOR_NAME,
               DICTNAME INVOICE_CLASS_NAME,
               PUR_CONTRACT_CODE,
               HEAD.INVOICE_QTY,
               DECODE(LINE.INVOICE_TYPE,
                      1,
                      '专用发票(纸)',
                      2,
                      '普通发票(纸)',
                      3,
                      '专用发票(电)',
                      4,
                      '普通发票(电)') INVOICE_TYPE_NAME,
               LINE.INVOICE_DATE,
               LINE.INVOICE_NUMBER,
               LINE.INVOICE_CONTENT,
               LINE.INVOICE_AMOUNT,
               TAX_RATE,
               LINE.TAX_AMOUNT
          FROM FD_INPUT_INVOICE_HEAD HEAD,
               FD_INPUT_INVOICE_LINE LINE,
               EPM_PROJECT,
               VENDOR,
               (SELECT DICTVALUE, DICTNAME FROM CPCDICT WHERE PID = -1026669) INVOICE_CLASS
         WHERE LINE.INPUT_INVOICE_HEAD_ID = HEAD.INPUT_INVOICE_HEAD_ID
           AND HEAD.PROJECT_ID = EPM_PROJECT.PROJECT_ID(+)
           AND HEAD.VENDOR_ID = VENDOR.VENDOR_ID(+)
           AND HEAD.INVOICE_CLASS = INVOICE_CLASS.DICTVALUE(+)
           AND HEAD.STAT = 5)
 WHERE 1 = 1

/*********************************************\
  * NAME(名称): VIEW_INPUTINVOICEDETAIL
  * PURPOSE(功能说明):  钉钉智能报表-项目收票明细
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-11-14
  \*********************************************/
/

