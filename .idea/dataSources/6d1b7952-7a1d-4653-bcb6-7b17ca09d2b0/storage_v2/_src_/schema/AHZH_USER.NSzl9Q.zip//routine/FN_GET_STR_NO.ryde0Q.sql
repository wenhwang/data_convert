create Function           Fn_Get_Str_No(p_str_in      varchar2, --浼？？瀛？？涓?
                                         p_svarchar_in varchar2) --浼？？瀛？？
 Return Number Is
  Result Number;
  str_in varchar2(500);
  i      number;

Begin
  Result := 0;
  str_in := p_str_in;
  while (instr(str_in, p_svarchar_in) > 0) loop
    i := instr(str_in, p_svarchar_in);
    if (i > 0) then
      Result := Result + 1;
      str_in := substr(str_in, i + 1);
    end if;
  end loop;
  return Result-1;
  /* Exception
  Result:=0;
  return Result;*/

End Fn_Get_Str_No;

  /*select Fn_Get_Str_No('\sdfs\dd\\', '\') from dual*/
/

