create view BASE_VIEW_WAREHOUSEEMPLOYEE as
select a.organization_id,
       a.whemployee_id,
       a.employee_id,
       b.employee_code as Whemployee_Code,
       b.employee_name as Whemployee_Name,
       c.warehouse_id,
       d.warehouse_code,
       d.warehouse_name
  from whemployee a, erpemployee b, inv_wh_ctrl c, warehouse d
 where a.employee_id = b.employee_id and
       a.organization_id = c.organization_id and
       a.organization_id = d.organization_id and a.isuseable = 2 and
       b.employee_code = c.cpcuserid and c.warehouse_id = d.warehouse_id
/

