create view VIEW_PARTNER_MANAGEMENT as
SELECT HEAD.ORDINAL_NO, --单据号
       HEAD.DATE_FUND, --回款日期
       DECODE(HEAD.PAYMENT_TYPE,
              1,
              '供应商',
              2,
              '业主/招标机构',
              3,
              '合伙人',
              4,
              '潜在客户',
              5,
              '个人') PAYMENT_TYPE_NAME, --回款单位类型
       RECEIVER_NAME, --回款单位
       RECEIVER_LINKNAME, --回款人
       FD_PAYMENT_TYPE.PAYMENT_TYPE_NAME BUSINESS_TYPE_NAME, --回款类型
       EMPLOYEE_NAME AGENT_NAME, --经办人
       FUND_ACCOUNT_NAME, --资金帐号
       HEAD.AMOUNT_DEBIT AMOUNT --回款金额
  FROM FIN_RECEIPT_VOUCHER HEAD,
       FD_FUND_ACCOUNT,
       EMPLOYEE_HEADER EMPLOYEE,
       FD_PAYMENT_TYPE
 WHERE HEAD.FD_FUND_ACCOUNT_ID = FD_FUND_ACCOUNT.FD_FUND_ACCOUNT_ID(+)
   AND HEAD.BUSINESS_TYPE = FD_PAYMENT_TYPE.FD_PAYMENT_TYPE_ID(+)
   AND HEAD.AGENT_ID = EMPLOYEE.EMPLOYEE_ID(+)
   AND HEAD.STAT = 5
   AND PAYMENT_TYPE_NAME =  '收管理费'

 /*********************************************\
  * NAME(名称): VIEW_PARTNER_MANAGEMENT
  * PURPOSE(功能说明):  合伙人回款-管理费
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2019-07-20
  \*********************************************/
/

