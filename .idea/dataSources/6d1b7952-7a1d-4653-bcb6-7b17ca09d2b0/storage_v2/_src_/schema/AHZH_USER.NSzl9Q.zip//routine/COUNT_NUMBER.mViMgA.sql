create procedure           count_number is
  i number(10);
  s number(10);
begin
  i := 1;
  s := 0;
  loop
    exit when i > 100;
    s := s + i;
    i := i + 1;
    dbms_output.put_line('s = ' || s);
  end loop;
end count_number;
/

