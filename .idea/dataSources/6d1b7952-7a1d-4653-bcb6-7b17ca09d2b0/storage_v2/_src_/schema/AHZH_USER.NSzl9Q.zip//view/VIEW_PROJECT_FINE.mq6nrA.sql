create view VIEW_PROJECT_FINE as
    SELECT 1 BILL_TYPE, --初始化及变更金额
       BALANCE_CHANGE_NO BILL_NO,
       PROJECT_ID,
       CHANGE_AMOUNT AMOUNT
  FROM EPM_PROJECT_BALANCE_CHANGE
 WHERE ACCT_BLNC_FIELD_NAME = 'PROJECT_FINE_AMOUNT'
   AND STAT = 5
UNION ALL
SELECT 2 BILL_TYPE, --业务单据金额
       HEAD.PROJECT_FINE_APPLY_NO,
       HEAD.PROJECT_ID,
       APPLY_AMOUNT AMOUNT
  FROM EPM_PROJECT_FINE_APPLY HEAD
 WHERE HEAD.STAT = 5
   AND HEAD.FINE_METHOD = 2 --  类型为: 2\扣除往来余额

/*********************************************\
  * NAME(名称): VIEW_PROJECT_FINE
  * PURPOSE(功能说明):  项目罚款金额明细
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2017-12-22
  \*********************************************/
/

