create view DRP_ITEM_TYPE as
select item_class_id as ITEM_TYPE_ID,
         item_class_code ITEM_TYPE_NO,
         item_class_name ITEM_TYPE_NAME,
         item_class_idpath IDPATH,
         (case when ORGANIZATION_ID=1 then item_class_level-1 else item_class_level + 1 end) LEV,
         item_usable USABLE,
         '' NOTE,
         item_class_pid PID,
         0 ENTORG_TYPE,
         resource_entorgid ENTORGID,
         is_end IS_ITEM,
         '' ENTORGIDS,
         '' MDCC_TYPE_NO,
         ORGANIZATION_ID ENTID,
         ORGANIZATION_ID,
         crm_entid,
         is_retail
    from item_class
   where item_class_level > 0
/*   AND item_class_idpath LIKE '\140\%'*/
   order by crm_entid, item_class_idpath
/

