create view VIEW_SCM_DATE_SHORTITEM as
select /*+ ALL_ROWS */ mnia.billno,
                mnia.Organization_Id,
                mnia.Item_Id,
                mnia.pm_code,
                mnia.Need_Date,
                Fn_Scm_Item_Stock_Run_Qty(mnia.Organization_Id,
                                           mnia.Item_Id,
                                           1) Onhand_Qty,
                Fn_Scm_Item_Stock_Run_Qty(mnia.Organization_Id,
                                           mnia.Item_Id,
                                           2) Rcv_Qty,
                sum(mnia.Need_Qty) Need_Qty
from (
--？？骇璁㈠？？╂？
    Select distinct mo.mono billno,
                    mo.Organization_Id,
                    ml.Item_Id,
                    ml.pm_code,
                    (nvl(mo.mostartdate, mo.MOENDDATE) -
                    nvl(mo.PREPARE_LDTIME, 0) - nvl(ml.QC_LDTIME, 0)) Need_Date,
                    Need_Qty
      From (select m. *, nvl(PREPARE_LDTIME, 0) PREPARE_LDTIME
              from mes_mo m, item_org io
             where m.organization_id = io.organization_id and
                   m.item_id = io.item_id) mo,
           (select m.organization_id,m.mes_mo_id,m. item_id,
               decode(sign(m.MOCTRLQTY - m.MOREALQTY),-1,0,m.MOCTRLQTY - m.MOREALQTY) Need_Qty,
            nvl(QC_LDTIME, 0) QC_LDTIME, io.pm_code
              from mnitemlist m, item_org io, item i
             where m.organization_id = io.organization_id and
                   m.item_id = io.item_id and io.item_id = i.item_id) ml
     Where mo.mes_mo_id = ml.mes_mo_id and
           mo.organization_id = ml.organization_id and mo.mostatus = 6
 --濮？？璁㈠？
 --杩？护镫？？璁㈠？
 union all
 Select po.pono billno,
       po.Organization_Id,
       pl.Item_Id,
       pl.pm_code,
       (polinedate - nvl(po.PREPARE_LDTIME, 0) - nvl(pl.QC_LDTIME, 0)) Need_Date,
       Need_Qty
  From (select sl.item_id,
               sl.polinedate,
               sl.postartworkdate,
               sh.pono,
               sh.organization_id,
               sl.polinestatus,
               sl.srm_po_line_id,
               nvl(PREPARE_LDTIME, 0) PREPARE_LDTIME
          from srm_po_line sl, srm_po_head sh, item_org io
         where sh.organization_id = io.organization_id and
               sh.srm_po_head_id = sl.srm_po_head_id and sh.potype = 2 and sh.pospecial <>2
               and sl.item_id = io.item_id) po,
       (select op.organization_id,
               op.opitemlist_id,
               op.srm_po_line_id,
               op.item_id,
               decode(sign(op.pOCTRLQTY - op.pooutqty),
                      -1,
                      0,
                      op.poctrlqty - op.pooutqty) Need_Qty,
               nvl(QC_LDTIME, 0) QC_LDTIME,
               io.pm_code
          from opitemlist op, item_org io, item i
         where op.organization_id = io.organization_id and
               op.item_id = io.item_id and io.item_id = i.item_id) pl
 Where po.srm_po_line_id = pl.srm_po_line_id and
       po.organization_id = pl.organization_id and po.polinestatus = 6
    ) mnia
 Group By mnia.billno,
          mnia.Organization_Id,
          mnia.Item_Id,
          mnia.pm_code,
          mnia.Need_Date
/

