create view VIEW_INV_OUT_TYPE_LIST as
select iobh.invbillno,
       iobh.refer_no,
       iobh.note,
       iobh.date_invbill,
       iobh.year_month,
       iobh.send_time,
       iobh.organization_id,
       w.warehouse_code,
       w.warehouse_name,
       d.dept_code,
       d.DEPT_NAME,
       c.customer_code,
       c.customer_name,
       ca.address1,
       ca.take_man,
       ca.phone_code,
       ib.billtype2code,
       ib.billtype2name,
       i.item_code,
       i.item_name,
       u.uom_name,
       iobl.qty_bill,
       iobl.wtpricec_bill_f,
       iobl.wtamount_bill_f,
       (Select DICTNAME From cpcdict
       Where cpcdict.entid = iobh.organization_id
         And upper(dictcode) = 'CRM_ENTID'||iobh.crm_entid) CRM_ENTNAME
  from inv_out_bill_head iobh,
       inv_out_bill_line iobl,
       warehouse         w,
       dept              d,
       customer          c,
       customer_address  ca,
       inv_billtype2     ib,
       item              i,
       uom               u
 where iobh.inv_out_bill_head_id = iobl.inv_out_bill_head_id
   and iobh.dept_id = d.dept_id(+)
   and iobh.customer_id = c.customer_id(+)
   and c.customer_id = ca.customer_id(+)
   and iobh.billtype2code = ib.billtype2code(+)
   and iobl.item_id = i.item_id(+)
   and iobl.uom_id = u.uom_id(+)
   and iobl.warehouse_id = w.warehouse_id(+)
   and iobh.billtypecode = '0299'
   and iobh.bluered = 'B'
   and iobh.is_auditing_wh = 2
   and iobh.stat = 5
   and ib.issystemvalue != 2
   and iobh.billtype2code != '062'
/

