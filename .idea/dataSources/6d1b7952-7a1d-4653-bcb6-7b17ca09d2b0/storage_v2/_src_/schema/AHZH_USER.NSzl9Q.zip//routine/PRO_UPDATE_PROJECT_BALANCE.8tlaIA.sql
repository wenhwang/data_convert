create PROCEDURE PRO_UPDATE_PROJECT_BALANCE(P_ORGANIZATION_ID IN EPM_PROJECT_ACCOUNT_BALANCE.ORGANIZATION_ID%TYPE,
                                                       P_PROJECT_ID      IN EPM_PROJECT_ACCOUNT_BALANCE.PROJECT_ID%TYPE,
                                                       P_UPDATE_FIELD    IN FD_PAYMENT_TYPE.UPDATE_FIELD%TYPE,
                                                       P_IO_TYPE         IN INTEGER,
                                                       P_AMOUNT_DEBIT    IN EPM_PROJECT_ACCOUNT_BALANCE.PROJECT_PAYMENT_AMOUNT %TYPE,
                                                       P_STATUS          OUT INTEGER,
                                                       P_MESSAGE         OUT VARCHAR2) IS

  /*********************************************\
  * NAME(名称): PRO_UPDATE_PROJECT_BALANCE
  * PURPOSE(功能说明):  更新项目余额
  *PARAM(参数说明)：P_ORGANIZATION_ID 组织
                                 P_PROJECT_ID 项目ID
                                 P_UPDATE_FIELD 更新字段
                                 P_IO_TYPE 更新方向:1 入 -1 出
                                 P_AMOUNT_DEBIT 金额
                                 P_STATUS: 执行状态 >0 成功 <0 失败
                                 P_MESSAGE: 执行信息

                                更新项
                                一、工程款
                                  收工程款
                                  付工程款
                                二、投资款
                                  收投资款
                                  付投资款
                                三、保证金
                                  收保证金
                                  付保证金
                                四、调拨款
                                  往来调拨收款
                                  往来调拨付款
                                五、公司借款
                                  公司借入
                                  公司借支
                                六、收付票据
                                  累计收票金额
                                  进项票税额
                                  累计开票金额
                                  销项票税额
                                七、项目扣款
                                  项目扣款金额(管理费)
                                  项目扣款金额(年费)
                                  项目扣款金额(税费)
                                  项目扣款金额(其他)
                                八、项目罚款
                                  项目罚款金额
                                九、其他款项
                                  其他回款
                                  其他付款
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2017-10-27
  \*********************************************/

  V_PROJECT_ID   EPM_PROJECT_ACCOUNT_BALANCE.PROJECT_ID%TYPE;
  V_AMOUNT_DEBIT EPM_PROJECT_ACCOUNT_BALANCE.PROJECT_PAYMENT_AMOUNT %TYPE;
BEGIN

  P_STATUS := -1;

  IF P_PROJECT_ID = 0 THEN
    RAISE_APPLICATION_ERROR(-20099, '项目ID错误:' || P_PROJECT_ID);
  END IF;

  V_AMOUNT_DEBIT := P_AMOUNT_DEBIT * P_IO_TYPE;

  --1.检查项目是否存在于项目余额表
  SELECT NVL(MAX(PROJECT_ID), 0)
    INTO V_PROJECT_ID
    FROM EPM_PROJECT_ACCOUNT_BALANCE
   WHERE PROJECT_ID = P_PROJECT_ID
     AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --如果没有新增一条
  IF V_PROJECT_ID = 0 THEN
    INSERT INTO EPM_PROJECT_ACCOUNT_BALANCE
      (PROJECT_ID, ORGANIZATION_ID)
    VALUES
      (P_PROJECT_ID, P_ORGANIZATION_ID);
    --COMMIT;
  END IF;

  --FOR UPDATE 并发、加行锁、获取PROJECT_ID
  SELECT PROJECT_ID
    INTO V_PROJECT_ID
    FROM EPM_PROJECT_ACCOUNT_BALANCE
   WHERE PROJECT_ID = P_PROJECT_ID
     AND ORGANIZATION_ID = P_ORGANIZATION_ID
     FOR UPDATE;

  --更新项目余额表
  CASE P_UPDATE_FIELD

  --1.1 收工程款
    WHEN 'PROJECT_RECEIVE_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET PROJECT_RECEIVE_AMOUNT = NVL(PROJECT_RECEIVE_AMOUNT, 0) +
                                      V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --1.2 付工程款
    WHEN 'PROJECT_PAYMENT_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET PROJECT_PAYMENT_AMOUNT = NVL(PROJECT_PAYMENT_AMOUNT, 0) +
                                      V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --2.1 收投资款
    WHEN 'PROJECT_INVEST_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET PROJECT_INVEST_AMOUNT = NVL(PROJECT_INVEST_AMOUNT, 0) +
                                     V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --2.2 付投资款
    WHEN 'AGENT_PURCHASE_OUT_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET AGENT_PURCHASE_OUT_AMOUNT = NVL(AGENT_PURCHASE_OUT_AMOUNT, 0) +
                                         V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --3.1 收保证金
    WHEN 'IN_MARGIN_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET IN_MARGIN_AMOUNT = NVL(IN_MARGIN_AMOUNT, 0) + V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --3.2 付保证金
    WHEN 'OUT_MARGIN_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET OUT_MARGIN_AMOUNT = NVL(OUT_MARGIN_AMOUNT, 0) + V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --4.1 往来调拨收款
    WHEN 'TRANSFER_IN_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET TRANSFER_IN_AMOUNT = NVL(TRANSFER_IN_AMOUNT, 0) +
                                  V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --4.2 往来调拨付款
    WHEN 'TRANSFER_OUT_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET TRANSFER_OUT_AMOUNT = NVL(TRANSFER_OUT_AMOUNT, 0) +
                                   V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --5.1 公司借入
    WHEN 'LOAN_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET LOAN_AMOUNT = NVL(LOAN_AMOUNT, 0) + V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --5.2 公司借支
    WHEN 'BORROW_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET BORROW_AMOUNT = NVL(BORROW_AMOUNT, 0) + V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --6.1 累计收票金额
    WHEN 'INPUT_INVOICE_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET INPUT_INVOICE_AMOUNT = NVL(INPUT_INVOICE_AMOUNT, 0) +
                                    V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --6.2 进项票税额
    WHEN 'INPUT_VAT_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET INPUT_VAT_AMOUNT = NVL(INPUT_VAT_AMOUNT, 0) + V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --6.3 累计开票金额
    WHEN 'OUTPUT_INVOICE_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET OUTPUT_INVOICE_AMOUNT = NVL(OUTPUT_INVOICE_AMOUNT, 0) +
                                     V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --6.4 销项票税额
    WHEN 'OUTPUT_VAT_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET OUTPUT_VAT_AMOUNT = NVL(OUTPUT_VAT_AMOUNT, 0) + V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --7.1 扣款金额-管理费
    WHEN 'WITHHOLD_MANAGEMENT_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET WITHHOLD_MANAGEMENT_AMOUNT = NVL(WITHHOLD_MANAGEMENT_AMOUNT, 0) +
                                          V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --7.2 扣款金额-年费
    WHEN 'WITHHOLD_YEAR_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET WITHHOLD_YEAR_AMOUNT = NVL(WITHHOLD_YEAR_AMOUNT, 0) +
                                    V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --7.3 扣款金额-税费
    WHEN 'WITHHOLD_TAX_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET WITHHOLD_TAX_AMOUNT = NVL(WITHHOLD_TAX_AMOUNT, 0) +
                                   V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --7.4 扣款金额-其他
    WHEN 'WITHHOLD_OTHER_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET WITHHOLD_OTHER_AMOUNT = NVL(WITHHOLD_OTHER_AMOUNT, 0) +
                                     V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --8.1 罚款金额
    WHEN 'PROJECT_FINE_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET PROJECT_FINE_AMOUNT = NVL(PROJECT_FINE_AMOUNT, 0) +
                                   V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --9.1 其他回款
    WHEN 'OTHER_IN_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET OTHER_IN_AMOUNT = NVL(OTHER_IN_AMOUNT, 0) + V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

  --9.2 其他付款
    WHEN 'OTHER_OUT_AMOUNT' THEN
      UPDATE EPM_PROJECT_ACCOUNT_BALANCE
         SET OTHER_OUT_AMOUNT = NVL(OTHER_OUT_AMOUNT, 0) + V_AMOUNT_DEBIT
       WHERE PROJECT_ID = P_PROJECT_ID
         AND ORGANIZATION_ID = P_ORGANIZATION_ID;

    ELSE
      P_STATUS  := -2;
      P_MESSAGE := '更新字段[' || P_UPDATE_FIELD || ']不正确';
  END CASE;

  --COMMIT;

  P_STATUS := -3;

  /*
  合伙人实际应付余额=(回款合计-付款合计-扣罚款合计+收保证金-付保证金+借入金额-借支金额)
  回款合计=投资款+工程回款+往来调拨收款+其他回款；
  付款合计=已支付项目款+往来调拨付款+代采购付款+其他付款；
  扣罚款合计=扣管理费+扣年费+扣税费+扣其他+罚款金额；
  业主应收余额(累计开票金额-项目回款金额)
  */
  UPDATE EPM_PROJECT_ACCOUNT_BALANCE
     SET PAYABLE_BALANCE    = ((NVL(PROJECT_INVEST_AMOUNT, 0) +
                              NVL(PROJECT_RECEIVE_AMOUNT, 0) +
                              NVL(TRANSFER_IN_AMOUNT, 0) +
                              NVL(OTHER_IN_AMOUNT, 0)) -
                              (NVL(PROJECT_PAYMENT_AMOUNT, 0) +
                              NVL(TRANSFER_OUT_AMOUNT, 0) +
                              NVL(AGENT_PURCHASE_OUT_AMOUNT, 0) +
                              NVL(OTHER_OUT_AMOUNT, 0)) -
                              (NVL(WITHHOLD_MANAGEMENT_AMOUNT, 0) +
                              NVL(WITHHOLD_YEAR_AMOUNT, 0) +
                              NVL(WITHHOLD_TAX_AMOUNT, 0) +
                              NVL(WITHHOLD_OTHER_AMOUNT, 0) +
                              NVL(PROJECT_FINE_AMOUNT, 0)) +
                              (NVL(IN_MARGIN_AMOUNT, 0) -
                              NVL(OUT_MARGIN_AMOUNT, 0)) +
                              (NVL(LOAN_AMOUNT, 0) - NVL(BORROW_AMOUNT, 0))),
         RECEIVABLE_BALANCE = (NVL(OUTPUT_INVOICE_AMOUNT, 0) -
                              NVL(PROJECT_RECEIVE_AMOUNT, 0))
   WHERE PROJECT_ID = P_PROJECT_ID;

  P_STATUS  := 1;
  P_MESSAGE := P_MESSAGE || '更新项目余额成功';

EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE = -20099 THEN
      --项目ID为0
      P_STATUS  := 1;
      P_MESSAGE := P_MESSAGE || SQLERRM;
    ELSE
      P_STATUS  := -99;
      P_MESSAGE := P_MESSAGE || SQLERRM;
    END IF;

END;
/

