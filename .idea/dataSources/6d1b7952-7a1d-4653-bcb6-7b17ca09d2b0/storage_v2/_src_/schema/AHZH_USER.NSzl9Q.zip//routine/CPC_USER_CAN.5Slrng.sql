create Procedure           CPC_USER_CAN Is

Begin
  update cpcuser f set f.actived = 1,
         note    = f.note || ':绯荤？绠＄？锻树？' ||
                   to_char(sysdate, 'yyyy-mm-dd') || '锅灭？'
   where  substr(f.createtime,1,10)<=to_char(sysdate-60,'yyyy-mm-dd') and  not exists (select distinct d.userid
            from cpcsyslog d
           where d.postaction = '锏诲？'
             and d.msgid = -1
             and substr(d.logtime, 1, 10) >=
                 to_char(sysdate - 60, 'yyyy-mm-dd')
             and f.userid = d.userid)
     and f.actived = 2;

   commit;
   End ;
/

