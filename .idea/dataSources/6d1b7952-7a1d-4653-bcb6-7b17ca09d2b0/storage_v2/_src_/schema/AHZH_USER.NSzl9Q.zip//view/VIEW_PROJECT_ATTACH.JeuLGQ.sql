create view VIEW_PROJECT_ATTACH as
SELECT EPM_ATTACH."OBJTYPE",
       EPM_ATTACH."OBJNAME",
       EPM_ATTACH."BILLNAME",
       EPM_ATTACH."OBJID",
       EPM_ATTACH."DOCID",
       CPCDOC.DOCNAME,
       CRC32,
       'http://epms.zhonghui365.com:8082/downloadfile.do?docid=' || EPM_ATTACH.DOCID ||
       '&crc32=' || CRC32 URL
  FROM (SELECT SUBSTR(BILL, 1, 5) OBJTYPE,
               SUBSTR(BILL, 6, INSTR(BILL, '||') - 6) OBJNAME,
               SUBSTR(BILL, INSTR(BILL, '||') + 2, LENGTH(BILL)) BILLNAME,
               OBJID,
               DOCID
          FROM (SELECT (CASE PROJECT_NODE
                         WHEN 1 THEN
                          'EPM01项目报备||EPM_PROJECT'
                         WHEN 2 THEN
                          'EPM02资格审查||EPM_PROJECT'
                         WHEN 3 THEN
                          'EPM03项目报名||EPM_PROJECT_SIGNUP'
                         WHEN 4 THEN
                          'EPM04招标文件解读||EPM_PROJECT_BID_HEAD'
                         WHEN 5 THEN
                          'EPM05招标文件评审||EPM_PROJECT_BID_REVIEW_HEAD'
                         WHEN 6 THEN
                          'EPM06封标核查||EPM_PROJECT_BID_SEALED'
                         WHEN 7 THEN
                          'EPM07现场开标||EPM_PROJECT_BID_OPEN'
                         WHEN 9 THEN
                          'EPM09开标结果分析||EPM_PROJECT_BID_RESULT'
                         WHEN 10 THEN
                          'EPM10项目总包合同||EPM_PROJECT_CONTRACT'
                         WHEN 90 THEN
                          'EPM11项目合同增补||EPM_PROJECT_CONTRACT_EXTRA'
                         WHEN 12 THEN
                          'EPM12项目分包合同||EPM_PROJECT_CONTRACT'
                         WHEN 13 THEN
                          'EPM13项目维保合同||EPM_PROJECT_CONTRACT'
                         WHEN 17 THEN
                          'EPM17施工日志||EPM_PROJECT_BUILD_LOG_HEAD'
                         WHEN 18 THEN
                          'EPM18巡检派遣||EPM_PROJECT_PATROL_APPLY'
                         WHEN 19 THEN
                          'EPM19巡检日志||EPM_PROJECT_PATROL_LOG_HEAD'
                         WHEN 20 THEN
                          'EPM20项目投诉||EPM_PROJECT_BID_COMPLAINT'
                         WHEN 24 THEN
                          'EPM24项目付款申请||EPM_PROJECT_PAYMENT_APPLY'
                         WHEN 25 THEN
                          'EPM25项目扣款申请||EPM_PROJECT_KK_APPLY_HEAD'
                         WHEN 26 THEN
                          'EPM26项目罚款申请||EPM_PROJECT_FINE_APPLY'
                         WHEN 27 THEN
                          'EPM27项目往来调拨||EPM_PROJECT_ACCT_BLNC_TRSF'
                         WHEN 28 THEN
                          'EPM28保证金转出申请||EPM_PROJECT_MARGIN_APPLY'
                         WHEN 34 THEN
                          'EPM34投标贷申请||EPM_PROJECT_BID_LOAN'
                       END) BILL,
                       ATTACH.OBJID,
                       ATTACH.DOCID
                  FROM EPM_PROJECT_ATTACH ATTACH
                 WHERE (PROJECT_NODE <> 30 AND PROJECT_NODE <> 31 AND --外经证开取申请、开票申请、收票确认归入财务
                       PROJECT_NODE <> 32))

        UNION ALL

        SELECT 'EPM29' OBJTYPE,
               OBJNAME,
               '业务用章申请' BILLNAME,
               OBJID,
               DOCID
          FROM ERPOBJATTACH
         WHERE UPPER(OBJNAME) = 'EPM_RESOUCE_STAMP_APPLY_HEAD'

        UNION ALL

        SELECT 'EPM30' OBJTYPE,
               OBJNAME,
               '项目往来余额变更' BILLNAME,
               OBJID,
               DOCID
          FROM ERPOBJATTACH
         WHERE UPPER(OBJNAME) = 'EPM_PROJECT_BALANCE_CHANGE'

        UNION ALL

        SELECT 'EPM31' OBJTYPE, OBJNAME, '项目答疑' BILLNAME, OBJID, DOCID
          FROM ERPOBJATTACH
         WHERE UPPER(OBJNAME) = 'EPM_PROJECT_ANSWER'

        UNION ALL

        SELECT 'EPM32' OBJTYPE, OBJNAME, '保函申请' BILLNAME, OBJID, DOCID
          FROM ERPOBJATTACH
         WHERE UPPER(OBJNAME) = 'EPM_GUARANTEE_LETTER'

        UNION ALL

        SELECT 'EPM33' OBJTYPE, OBJNAME, '承诺函' BILLNAME, OBJID, DOCID
          FROM ERPOBJATTACH
         WHERE UPPER(OBJNAME) = 'EPM_COMMITMENT_LETTER'

        UNION ALL

        SELECT 'EPM35' OBJTYPE,
               OBJNAME,
               '项目预算筹划' BILLNAME,
               OBJID,
               DOCID
          FROM ERPOBJATTACH
         WHERE UPPER(OBJNAME) = 'EPM_BUDGET_TO_PLAN_HEAD') EPM_ATTACH,
       CPCDOC
 WHERE EPM_ATTACH.DOCID = CPCDOC.DOCID
/*********************************************\
   * NAME(名称): VIEW_PROJECT_ATTACH
   * PURPOSE(功能说明):  项目附件汇总
   * AUTHOR(作者): NY
   * CREATE AT(创建时间): 2019-10-16
\*********************************************/
/

