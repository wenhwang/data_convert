create PROCEDURE PRO_DINGREMIND_DIFFAREAVAT(ADVANCE_DAYS  INTEGER, --提前天数
                                                       INTERVAL_DAYS INTEGER --间隔天数
                                                       ) IS
  --计数
  V_COUNT_NUM INTEGER;

  --接收人
  V_RECIPIENT   VARCHAR(512); --钉钉USERID
  V_RECIPIENTID VARCHAR(512);

  --提醒内容游标
  CURSOR V_REMINDS IS
    SELECT '9001' BILL_TYPE_CODE,
           '外经证' BILL_TYPE_NAME,
           ORGANIZATION_ID,
           APPLY_BILL_NO BILL_NO,
           '外经证销缴' BILL_NAME,
           '外经证:' || APPLY_BILL_NO || ',将于' ||
           TO_CHAR(END_DATE, 'YYYY-MM-DD') || '日过期,请及时处理.[' || APPLY_NOTE || ']' MESSAGE,
           TRUNC(SYSDATE - 1) + 33 / 24 SENDING_TIME, --默认第二天上午9点
           WFID,
           0 SENDING_STAT,
           NULL SENDING_RESULT
      FROM FD_DIFF_AREA_VAT_APPLY HEAD
     WHERE STAT = 5
       AND IS_PRINT_INVOICE = 1 --未缴销
       AND CEIL(END_DATE - SYSDATE) <= ADVANCE_DAYS;

BEGIN

  --1、周六、周日不提醒
  V_COUNT_NUM := 0;
  SELECT COUNT(1)
    INTO V_COUNT_NUM
    FROM DUAL
   WHERE TRIM(TO_CHAR(SYSDATE, 'DAY', 'NLS_DATE_LANGUAGE=AMERICAN')) IN
         ('SATURDAY', 'SUNDAY');
  IF (V_COUNT_NUM > 0) THEN
    RETURN;
  END IF;

  --2.产生提醒内容
  FOR REMIND IN V_REMINDS LOOP
    BEGIN
      --2.1判断间隔时间
      V_COUNT_NUM := 0;
      SELECT NVL(CEIL(SYSDATE -
                      (SELECT MAX(HEAD.SENDING_TIME)
                         FROM DINGTALK_REMIND HEAD
                        WHERE HEAD.BILL_TYPE_CODE = '9001'
                          AND HEAD.BILL_NO = REMIND.BILL_NO)),
                 0)
        INTO V_COUNT_NUM
        FROM DUAL;

      --间隔天数小于指定天数,退出循环
      IF (V_COUNT_NUM < INTERVAL_DAYS) AND (V_COUNT_NUM <> 0) THEN
        CONTINUE;
      END IF;

      --2.2提取提醒对象
      SELECT WMSYS.WM_CONCAT(RECIPIENT), WMSYS.WM_CONCAT(RECIPIENTID)
        INTO V_RECIPIENT, V_RECIPIENTID
        FROM (SELECT 'DIFFAREAVAT' RECIPIENT_TYPE,
                     USERID RECIPIENT,
                     EMPLOYEE.DINGTALK_USERID RECIPIENTID
                FROM EMPLOYEE_HEADER EMPLOYEE
               WHERE USERID IN
                     (SELECT DISTINCT USERID
                        FROM CPCROLEUSER, CPCUSER
                       WHERE CPCROLEUSER.SYSUSERID = CPCUSER.SYSUSERID
                         AND ROLEID = '税务会计' --提取 税务会计 角色
                      UNION
                      SELECT DISTINCT USERID --流程上所有节点
                        FROM CPCWFPROC_V, CPCUSER
                       WHERE CPCWFPROC_V.MANAGER = CPCUSER.USERID
                         AND CPCWFPROC_V.WFID = REMIND.WFID))
       GROUP BY RECIPIENT_TYPE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_RECIPIENT   := '';
        V_RECIPIENTID := '';
    END;

    --2.1生成提醒内容
    INSERT INTO DINGTALK_REMIND
      (DINGTALK_REMIND_ID,
       BILL_TYPE_CODE,
       BILL_TYPE_NAME,
       ORGANIZATION_ID,
       BILL_NO,
       BILL_NAME,
       MESSAGE,
       RECIPIENT,
       RECIPIENTID,
       SENDING_TIME,
       SENDING_STAT,
       SENDING_RESULT)
    VALUES
      (SQ_DINGTALK_REMIND_ID.NEXTVAL,
       REMIND.BILL_TYPE_CODE,
       REMIND.BILL_TYPE_NAME,
       REMIND.ORGANIZATION_ID,
       REMIND.BILL_NO,
       REMIND.BILL_NAME,
       REMIND.MESSAGE,
       V_RECIPIENT,
       V_RECIPIENTID,
       REMIND.SENDING_TIME,
       REMIND.SENDING_STAT,
       REMIND.SENDING_RESULT);
    --提交
    COMMIT;

  END LOOP;

END;

  /*********************************************\
  * NAME(名称): PRO_DINGREMIND_DIFFAREAVAT
  * PURPOSE(功能说明):  钉钉消息提醒-外经证缴销
                                    通知人:流程审核人、税务会计角色

    PARAMETER(参数):  ADVANCE_DAYS:提前天数
                                 INTERVAL_DAYS:间隔天数
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2019-04-04
  \*********************************************/
/

