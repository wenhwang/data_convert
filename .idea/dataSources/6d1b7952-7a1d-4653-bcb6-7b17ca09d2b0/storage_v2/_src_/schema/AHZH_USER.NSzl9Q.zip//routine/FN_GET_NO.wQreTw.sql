create Function           Fn_Get_No(p_str_in varchar2, --浼？？瀛？？涓?
                                     p_num_in number) --浼？？瀛？？
 Return varchar2 Is
  Result varchar2(30);
Begin
  Result := p_str_in;
  if p_num_in < 10 then
    Result := Result || '000' || to_char(p_num_in);
  end if;
  if p_num_in >= 10 and p_num_in < 100 then
    Result := Result || '00' || to_char(p_num_in);
  end if;
  if p_num_in >= 100 and p_num_in < 1000 then
    Result := Result || '0' || to_char(p_num_in);
  end if;
  if p_num_in >= 1000 then
    Result := Result || to_char(p_num_in);
  end if;
  return Result;
End Fn_Get_No;
/

