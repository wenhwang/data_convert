create view VIEW_GL_CREATE_ACTSUBJ as
SELECT a.GL_ACCOUNT_SUBJECT_ID,
      b.Organization_Id,
       KM_CODE,
       (CASE
         WHEN (LENGTH(KM_CODE)) <= 4 THEN
          KM_NAME
         WHEN (LENGTH(KM_CODE)) = 6 THEN
          (SELECT KM_DESC
             FROM GL_ACCOUNT_SUBJECT
            WHERE KM_CODE = SUBSTR(A.KM_CODE, 0, 4)
              and GL_ACCOUNT_SUBJECT.Org_Id_Owner=a.org_id_owner) || '-' || KM_DESC
         WHEN (LENGTH(KM_CODE)) = 8 THEN
          (SELECT KM_DESC
             FROM GL_ACCOUNT_SUBJECT
            WHERE KM_CODE = SUBSTR(A.KM_CODE, 0, 4)
              and GL_ACCOUNT_SUBJECT.Org_Id_Owner=a.org_id_owner) || '-' ||
          (SELECT KM_DESC
             FROM GL_ACCOUNT_SUBJECT
            WHERE KM_CODE = SUBSTR(A.KM_CODE, 0, 6)
              and GL_ACCOUNT_SUBJECT.Org_Id_Owner=a.org_id_owner) || '-' || KM_DESC
         WHEN (LENGTH(KM_CODE)) = 10 THEN
          (SELECT KM_DESC
             FROM GL_ACCOUNT_SUBJECT
            WHERE KM_CODE = SUBSTR(A.KM_CODE, 0, 4)
              and GL_ACCOUNT_SUBJECT.Org_Id_Owner=a.org_id_owner) || '-' ||
          (SELECT KM_DESC
             FROM GL_ACCOUNT_SUBJECT
            WHERE KM_CODE = SUBSTR(A.KM_CODE, 0, 6)
              and GL_ACCOUNT_SUBJECT.Org_Id_Owner=a.org_id_owner) || '-' ||
          (SELECT KM_DESC
             FROM GL_ACCOUNT_SUBJECT
            WHERE KM_CODE = SUBSTR(A.KM_CODE, 0, 8)
              and GL_ACCOUNT_SUBJECT.Org_Id_Owner=a.org_id_owner) || '-' || KM_DESC
         WHEN (LENGTH(KM_CODE)) = 12 THEN
          (SELECT KM_DESC
             FROM GL_ACCOUNT_SUBJECT
            WHERE KM_CODE = SUBSTR(A.KM_CODE, 0, 4)
              and GL_ACCOUNT_SUBJECT.Org_Id_Owner=a.org_id_owner) || '-' ||
          (SELECT KM_DESC
             FROM GL_ACCOUNT_SUBJECT
            WHERE KM_CODE = SUBSTR(A.KM_CODE, 0, 6)
              and GL_ACCOUNT_SUBJECT.Org_Id_Owner=a.org_id_owner) || '-' || KM_DESC
         /* (SELECT KM_DESC
             FROM GL_ACCOUNT_SUBJECT
            WHERE KM_CODE = SUBSTR(A.KM_CODE, 0, 8)) || '-' ||
          (SELECT KM_DESC
             FROM GL_ACCOUNT_SUBJECT
            WHERE KM_CODE = SUBSTR(A.KM_CODE, 0, 10)) || '-' || KM_DESC*/
         WHEN (LENGTH(KM_CODE)) = 14 THEN
          (SELECT KM_DESC
             FROM GL_ACCOUNT_SUBJECT
            WHERE KM_CODE = SUBSTR(A.KM_CODE, 0, 4)
              and GL_ACCOUNT_SUBJECT.Org_Id_Owner=a.org_id_owner) || '-' ||
          (SELECT KM_DESC
             FROM GL_ACCOUNT_SUBJECT
            WHERE KM_CODE = SUBSTR(A.KM_CODE, 0, 6)
              and GL_ACCOUNT_SUBJECT.Org_Id_Owner=a.org_id_owner) || '-' ||
          (SELECT KM_DESC
             FROM GL_ACCOUNT_SUBJECT
            WHERE KM_CODE = SUBSTR(A.KM_CODE, 0, 8)
              and GL_ACCOUNT_SUBJECT.Org_Id_Owner=a.org_id_owner) || '-' || KM_DESC
         /* (SELECT KM_DESC
             FROM GL_ACCOUNT_SUBJECT
            WHERE KM_CODE = SUBSTR(A.KM_CODE, 0, 10)) || '-' ||
          (SELECT KM_DESC
             FROM GL_ACCOUNT_SUBJECT
            WHERE KM_CODE = SUBSTR(A.KM_CODE, 0, 12)) || '-' || KM_DESC*/
       END) AS KM_NAME,
       HELP_CODE,
       KM_TYPE,
       KM_PROPERTY,
       PAGE_TYPE,
       KM_LEVEL,
       BASE_CURRENCY_ID,
       IS_FREEZE,
       DEPT_CALCULATE,
       PERSON_CALCULATE,
       CUSTOMER_CALCULATE,
       VENDOR_CALCULATE,
       PROJECT_CALCULATE,
       ITEM_CALCULATE,
       FIRST_QUERY_OBJ,
       is_shop_CALCULATE,
       is_area_CALCULATE,
       END_KM,
       GL_ACCOUNT_SUBJECT_PID,
       GL_ACCOUNT_SUBJECT_IDPATH,
       IDPATH,
       KM_DESC
  FROM GL_ACCOUNT_SUBJECT A,GL_ACCOUNT_SUBJECT_org b
  Where a.Gl_Account_Subject_Id=b.Gl_Account_Subject_Id
    and a.org_id_owner = b.organization_id
/

