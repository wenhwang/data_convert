create view VIEW_PROJECT_LOAD_INFO as
SELECT PRJOECT_LOAN.PROJECT_ID,
       PARTNER_ID, --项目合伙人
       PARTNER,
       HOLDER_ID, --项目业主
       HOLDER,
       LOAN_AMT,
       REPAY_AMT,
       NVL(LOAN_AMT - REPAY_AMT, 0) NOT_HK_AMT
  FROM (SELECT LOAN.PROJECT_ID,
               NVL(ALLOW_AMT, 0) LOAN_AMT,
               NVL(AMOUNT_PAYMENT, 0) REPAY_AMT
          FROM (SELECT PROJECT_ID, NVL(SUM(LINE.ALLOW_AMT), 0) ALLOW_AMT
                  FROM MKT_LOAN_HEADER HEAD, MKT_LOAN_LINE LINE
                 WHERE LINE.LOAN_ID = HEAD.LOAN_ID
                   AND HEAD.PROJECT_ID <> 0
                 GROUP BY PROJECT_ID) LOAN,
               (SELECT PROJECT_ID, NVL(SUM(AMOUNT_PAYMENT), 0) AMOUNT_PAYMENT
                  FROM FD_PAYMENT_BILL HEAD
                 WHERE HEAD.PROJECT_ID <> 0
                 GROUP BY PROJECT_ID) PAYMENT
         WHERE LOAN.PROJECT_ID = PAYMENT.PROJECT_ID(+)
           AND NVL(ALLOW_AMT, 0) - NVL(AMOUNT_PAYMENT, 0) <> 0) PRJOECT_LOAN,
       VIEW_BASE_PROJECT
 WHERE PRJOECT_LOAN.PROJECT_ID = VIEW_BASE_PROJECT.PROJECT_ID(+)

/*********************************************\
  * NAME(名称): VIEW_PROJECT_LOAD_INFO
  * PURPOSE(功能说明):  项目借款明细
                                   LOAN_AMT, --借款金额
                                   REPAY_AMT, --还款金额
                                   NOT_HK_AMT --未还金额
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2019-03-02
  \*********************************************/
/

