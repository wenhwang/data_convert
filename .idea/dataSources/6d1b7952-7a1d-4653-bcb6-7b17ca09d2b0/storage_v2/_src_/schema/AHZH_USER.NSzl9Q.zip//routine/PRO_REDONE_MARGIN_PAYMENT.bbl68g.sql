create PROCEDURE PRO_REDONE_MARGIN_PAYMENT AS
  /*********************************************\
  * NAME(名称): PRO_REDONE_MARGIN_PAYMENT
  * PURPOSE(功能说明):  以付款单为基准更新保证金转出申请单中本次已付款金额、是否结案
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2017-11-29
  \*********************************************/
BEGIN

  UPDATE EPM_PROJECT_MARGIN_APPLY HEAD
     SET HEAD.PAID_AMOUNT = (SELECT AMOUNT_CREDIT
                               FROM (SELECT SALEORDER_NO BILL_NO,
                                            NVL(SUM(AMOUNT_CREDIT), 0) AMOUNT_CREDIT
                                       FROM FD_FUND_BUSINESS
                                      WHERE SALEORDER_NO IS NOT NULL
                                        AND SYSCREATE_TYPE = 5 --5|保证金转出
                                        AND STAT = 5 --已审核
                                        AND IS_AP_FUND = 2 --是否销售回款
                                        AND RECORD_TYPE = 3
                                      GROUP BY SALEORDER_NO) BUSINESS
                              WHERE HEAD.BILL_NO = BUSINESS.BILL_NO),
         IS_CLOSED        = 2 --单次付款
   WHERE EXISTS (SELECT 1
            FROM (SELECT SALEORDER_NO BILL_NO
                    FROM FD_FUND_BUSINESS
                   WHERE SALEORDER_NO IS NOT NULL
                     AND SYSCREATE_TYPE = 5 --5|保证金转出
                     AND STAT = 5 --已审核
                     AND IS_AP_FUND = 2 --是否销售回款
                     AND RECORD_TYPE = 3 --回款
                  ) BUSINESS
           WHERE HEAD.BILL_NO = BUSINESS.BILL_NO);

  COMMIT;
END;
/

