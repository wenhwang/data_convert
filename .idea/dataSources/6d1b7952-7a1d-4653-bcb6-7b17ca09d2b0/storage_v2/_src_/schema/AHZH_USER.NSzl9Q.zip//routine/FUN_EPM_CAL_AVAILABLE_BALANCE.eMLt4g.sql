create FUNCTION FUN_EPM_CAL_AVAILABLE_BALANCE(P_ORGANIZATION_ID IN NUMBER,
                                                         P_PROJECT_ID      IN NUMBER)
  RETURN NUMBER IS
  RESULT NUMBER;
  /**
   * 获取可用应付金额
   */
  v_available_balance number(12, 4);

  v_payable_balance number(12, 4); --1.实际剩余应付
  v_lock_amount     number(12, 4); --2.冻结金额

/*  v_lock_payment         number(12, 4); --2.1冻结付款
  v_lock_project_amount  number(12, 4); --2.1.1 冻结项目付款
  v_lock_trsf_amount     number(12, 4); -- 2.1.2 冻结往来调拨付款
  v_lock_purchase_amount number(12, 4); --2.1.3 冻结代采购付款

  v_lock_kk_amount     number(12, 4); --2.2 冻结扣款
  v_lock_fine_amount   number(12, 4); --2.3 冻结罚款
  v_lock_margin_amount number(12, 4); -- 2.4 冻结付保证金*/

Begin
  --1.实际剩余应付 
  select nvl(max(payable_balance), 0) payable_balance
    into v_payable_balance
    from epm_project_account_balance
   where organization_id = p_organization_id
     and project_id = p_project_id;

  /*--2.1.1 冻结项目付款
  select nvl(sum(approved_amount) - sum(paid_amount), 0) as lock_project_amount
    into v_lock_project_amount
    from epm_project_payment_apply eppa
   where (stat >= 2 and stat != 99)
     and nvl(is_closed, 0) <= 1
     and organization_id = p_organization_id 
     and project_id = p_project_id;

  -- 2.1.2 冻结往来调拨付款
  select nvl(sum(apply_amount), 0) as lock_trsf_amount
    into v_lock_trsf_amount
    from epm_project_acct_blnc_trsf 
   where (stat >= 2 and stat != 99)
     and organization_id = p_organization_id
     and out_project_id = p_project_id;

  --2.1.3 冻结代采购付款
  select nvl(sum(approve_amount) - sum(paid_amount), 0) as lock_purchase_amount
    into v_lock_purchase_amount
    from pur_payment_apply_head
   where (stat >= 2 and stat != 99)
     and nvl(is_closed, 0) <= 1
     and organization_id = p_organization_id
     and project_id = p_project_id;

  --2.4冻结扣款=（已启动流程的未结案的项目扣款申请单的批准金额-本次实际扣款金额）
  select nvl(sum(approved_amount) - sum(paid_amount), 0) as lock_kk_amount
    into v_lock_kk_amount
    from epm_project_kk_apply_head
   where (stat >= 2 and stat != 99)
     and nvl(is_closed, 0) <= 1
     and organization_id = p_organization_id
     and project_id = p_project_id;

  --2.3 冻结罚款
  select nvl(sum(apply_amount), 0) as lock_fine_amount
    into v_lock_fine_amount
    from epm_project_fine_apply
   where (stat >= 2 and stat != 99)
     and organization_id = p_organization_id
     and project_id = p_project_id;

  -- 2.4 冻结付保证金
  select nvl(sum(apply_amount) - sum(paid_amount), 0) as lock_margin_amount
    into v_lock_margin_amount
    from epm_project_margin_apply
   where (stat >= 2 and stat != 99)
     and nvl(is_closed, 0) <= 1
     and organization_id = p_organization_id
     and project_id = p_project_id;

  --2.1冻结付款 = 2.1.1 冻结项目付款(v_lock_project_amount) + 
  --                        2.1.2 冻结往来调拨付款(v_lock_trsf_amount)+ 
  --                        2.1.3 冻结代采购付款(v_lock_purchase_amount)
  v_lock_payment := v_lock_project_amount + v_lock_trsf_amount +
                    v_lock_purchase_amount;

  -- 2.冻结金额= 2.1冻结付款(v_lock_payment) + 2.2 冻结扣款(v_lock_kk_amount) + 2.3 冻结罚款(v_lock_fine_amount) + 2.4 冻结付保证金(v_lock_Margin_amount)
  v_lock_amount := v_lock_payment + v_lock_kk_amount + v_lock_fine_amount +
                   v_lock_Margin_amount;*/
                   
  -- 2.冻结金额
  v_lock_amount := fun_epm_get_lock_amount(P_ORGANIZATION_ID, P_PROJECT_ID);                   

  --可用应付余额 (available_balance)= 1.实际剩余应付(v_payable_balance) - 2.冻结金额(v_lock_amount) 
  v_available_balance := v_payable_balance - v_lock_amount;

  result := v_available_balance;

  return result;

End;
/

