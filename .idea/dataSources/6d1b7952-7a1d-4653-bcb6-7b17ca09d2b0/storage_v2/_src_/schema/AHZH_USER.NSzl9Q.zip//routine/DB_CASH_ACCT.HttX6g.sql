create Function           Db_Cash_Acct(P_Obj_CODEs         Varchar2,
                                   P_S_YEAR_MONTH     VARCHAR2,
                                   P_E_YEAR_MONTH     VARCHAR2,
                                   P_Organization_Ids Varchar2)
  Return Number Is
  Result Number;
  Objcodes  VARCHAR2(300);
  orgids    VARCHAR2(300);
  Sqlwhere  VARCHAR2(1000);
  intflag   number;
  /*
  銮峰？绉？？浣？？？版？

  p_Organization_Id  浜у？缁？？ID
  P_KM_CODE           绉？？浠ｇ？,
  P_GET_TYPE  C 链？？？?JF ？？？？？？？?DF 璐锋？？？？？?Y 链？汤？?
  P_S_YEAR_MONTH    寮？濮？？浠?
  P_E_YEAR_MONTH   缁？？链？唤,
  */

Begin

  --Sqlwhere := '';
  --瑙ｆ？绉？？

  --瑙ｆ？绉？？
  select replace(P_Obj_CODEs, '\', ''',''') into Objcodes from dual;
  --瑙ｆ？缁？？
  select replace(P_Organization_Ids, '\', ',') into orgids from dual;

  --镙规？？？？？ゆ？？？？？ユ？ definecelltall Tall_Flag

  Sqlwhere :='select Tall_Flag from definecelltall '||
             ' where organization_id in (' || orgids || ') and rownum = 1';
   execute immediate sqlwhere
    into intflag;

  Sqlwhere := 'Select Sum(nvl(line.amount, 0)) amount '||
             '  From Gl_Credence_Head   Head,'||
             '       Gl_Cashreport_Line Line,'||
             '       Gl_Cash_Report_Set Cashset '||
             ' Where Head.Gl_Credence_Head_Id = Line.Gl_Credence_Head_Id '||
             '   and Head.Organization_ID in (' || orgids || ')' ||
             '   And Line.Gl_Cash_Report_Set_Id = Cashset.Gl_Cash_Report_Set_Id(+) '||
             '   and head.year_month between ''' || P_S_YEAR_MONTH ||
              ''' and ''' || P_E_YEAR_MONTH || ''''||
              ' and cashset.obj_code in (''' || Objcodes || ''')';

  ---杩？处镙？？
  if (intflag is not null) and ( intflag=2)  Then
    Sqlwhere := Sqlwhere || ' and head.Tally_Flag = 2 ';
  End If;


  --Dbms_Output.Put_Line('Sqlwhere:' || Sqlwhere);
  execute immediate sqlwhere
    into Result;

  Return Nvl(Result, 0);

End Db_Cash_Acct;
/

