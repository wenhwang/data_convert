create view VIEW_SALE_PAYMENT_BILLING as
SELECT BILL."BILL_TYPE",BILL."PROJECT_ID",BILL."YEAR",BILL."MONTH",BILL."BILL_DATE",BILL."AMOUNT",
       PROJECT.SALE_AREA_ID, --销售区域
       PROJECT.SALES_ID --业务员
  FROM (SELECT '销售额' BILL_TYPE,
               PROJECT_ID,
               TO_CHAR(SIGNUP_DATE, 'YYYY') YEAR,
               TO_CHAR(SIGNUP_DATE, 'MM') MONTH,
               SIGNUP_DATE BILL_DATE,
               CONTRACT.CONTRACT_AMOUNT AMOUNT
          FROM EPM_PROJECT_CONTRACT CONTRACT
         WHERE CONTRACT.STAT = 5

        UNION ALL

        SELECT '回款额' BILL_TYPE,
               LIST.PROJECT_ID,
               TO_CHAR(DATE_FUND, 'YYYY') YEAR,
               TO_CHAR(DATE_FUND, 'MM') MONTH,
               HEAD.DATE_FUND BILL_DATE,
               AMOUNT
          FROM VIEW_PROJECT_RECEIVE_LIST LIST, FIN_RECEIPT_VOUCHER HEAD
         WHERE LIST.BILL_TYPE = 2
           AND LIST.BILL_NO = HEAD.ORDINAL_NO

        UNION ALL

        SELECT '开票额' BILL_TYPE,
               LIST.PROJECT_ID,
               TO_CHAR(APPLY_DATE, 'YYYY') YEAR,
               TO_CHAR(APPLY_DATE, 'MM') MONTH,
               HEAD.APPLY_DATE BILL_DATE,
               AMOUNT
          FROM VIEW_OUTPUT_INVOICE_LIST LIST, FD_OUTPUT_INVOICE_APPLY HEAD
         WHERE LIST.BILL_TYPE = 2
           AND LIST.BILL_NO = HEAD.APPLY_BILL_NO) BILL,
       EPM_PROJECT PROJECT
 WHERE BILL.PROJECT_ID = PROJECT.PROJECT_ID(+)

  /*********************************************\
  * NAME(名称): VIEW_SALE_PAYMENT_BILLING
  * PURPOSE(功能说明):  项目销售额与回款额、开票额趋势图-明细
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-01-13
  \*********************************************/
/

