create trigger T_INV_IN_BILL_HEAD_UPDATED
    after update
    on INV_IN_BILL_HEAD
    for each row
declare
  cnt     number := 0;
  head_id number := 0;
  --是否启用BIC系统对接：1 不启用、2 启用
  is_start_bic_intf number := 1;
  v_count           number := 0;
  v_head_id         number := 0;
  -- PRAGMA AUTONOMOUS_TRANSACTION;
begin
  if updating then
    select count(1)
      into cnt
      from sys_param
     where param_code = 'IS_START_BIC_INTF'
       and ENTERPRISE_ID = :old.organization_id;
    if (cnt = 1) then
      select param_value
        into is_start_bic_intf
        from sys_param
       where param_code = 'IS_START_BIC_INTF'
         and ENTERPRISE_ID = :old.organization_id;
    end if;

    --dgj 2016.04.05
    --BMS1
    --查询是否配置帐套对照关系
    select count(1)
      into v_count
      from CCS_BMS_ORG_COMPARE c
     where nvl(c.usable, 0) = 2
       and c.organization_id = :new.organization_id;

    --正常出库审核
    if (is_start_bic_intf = 2) and (:new.is_auditing_wh = 2) and
       (:old.is_auditing_wh = 1) and (nvl(:old.is_from_ec, 0) <> 2) then
      --正常出库审核写入接口表
      --取接口表ID
      select sq_Intf_To_Inv_Bill_Head.Nextval head_id
        into head_id
        from dual;
      --插入表头
      insert into Intf_To_Inv_Bill_Head
        (SET_OF_BOOKS_ID,
         ORGANIZATION_ID,
         INTF_TO_BILL_ID,
         IO_TYPE,
         BILLTYPECODE,
         BILLTYPE2CODE,
         INV_BILL_ID,
         INV_BILL_NO,
         BILL_DATE,
         YEAR_MONTH,
         DEPT_ID,
         WAREHOUSE_ID,
         CUSTOMER_ID,
         VENDOR_ID,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATE_BY,
         LAST_UPDATE_DATE,
         REMARK,
         OUT_INTF_FLAG,
         OUT_INTF_INFO,
         TOTAL_QTY,
         AMOUNT_TOTAL_NOTAX,
         AMOUNT_TOTAL_NOTAX_F,
         AMOUNT_TOTAL,
         AMOUNT_TOTAL_F)
        select (select t.set_of_books_id
                  from cpcent t
                 where t.organization_id = :old.organization_id) set_of_books_id,
               :old.organization_id,
               head_id,
               2,
               :old.billtypecode,
               :old.billtype2code,
               :old.inv_in_bill_head_id,
               :old.invbillno,
               :old.invbilldate,
               :old.year_month,
               :old.dept_id,
               :old.warehouse_id,
               :old.customer_id,
               :old.vendor_id,
               'admin',
               sysdate,
               'admin',
               sysdate,
               '入库单写入',
               0,
               '',
               :old.TOTAL_QTY,
               :old.AMOUNT_TOTAL_NOTAX,
               :old.AMOUNT_TOTAL_NOTAX_F,
               :old.AMOUNT_TOTAL,
               :old.AMOUNT_TOTAL_F
          from dual;

      --插入明细
      insert into Intf_To_Inv_Bill_line
        (INTF_TO_BILL_ID,
         INTF_TO_BILL_LINE_ID,
         INV_BILL_ID,
         INV_BILL_LINE_ID,
         ITEM_ID,
         WAREHOUSE_ID,
         BILL_QTY,
         PRICE_TAX,
         AMOUNT_TAX,
         PRICE_NOTAX,
         AMOUNT_NOTAX,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATE_BY,
         LAST_UPDATE_DATE,
         REMARK)
        select head_id,
               SQ_INTF_BMS_TO_INVBILL_LINE.Nextval,
               l.inv_in_bill_head_id,
               l.inv_in_bill_line_id,
               l.item_id,
               l.warehouse_id,
               l.qty_invbill,
               l.wtpricec_bill_f,
               nvl(l.wtpricec_bill_f * l.qty_invbill, 0),
               l.wtpricec_bill_f_notax,
               nvl(l.wtpricec_bill_f_notax * l.qty_invbill, 0),
               'admin',
               sysdate,
               'admin',
               sysdate,
               '入库单写入'
          from inv_in_bill_line l
         where l.inv_in_bill_head_id = :old.inv_in_bill_head_id;
    end if;

    --异常入库审核反改
    if (is_start_bic_intf = 2) and (:new.is_auditing_wh = 1) and
       (:old.is_auditing_wh = 2) and (nvl(:old.is_from_ec, 0) <> 2) then
      --正常出库审核写入接口表
      --取接口表ID
      select sq_Intf_To_Inv_Bill_Head.Nextval head_id
        into head_id
        from dual;
      --插入表头
      insert into Intf_To_Inv_Bill_Head
        (SET_OF_BOOKS_ID,
         ORGANIZATION_ID,
         INTF_TO_BILL_ID,
         IO_TYPE,
         BILLTYPECODE,
         BILLTYPE2CODE,
         INV_BILL_ID,
         INV_BILL_NO,
         BILL_DATE,
         YEAR_MONTH,
         DEPT_ID,
         WAREHOUSE_ID,
         CUSTOMER_ID,
         VENDOR_ID,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATE_BY,
         LAST_UPDATE_DATE,
         REMARK,
         OUT_INTF_FLAG,
         OUT_INTF_INFO,
         TOTAL_QTY,
         AMOUNT_TOTAL_NOTAX,
         AMOUNT_TOTAL_NOTAX_F,
         AMOUNT_TOTAL,
         AMOUNT_TOTAL_F)
        select (select t.set_of_books_id
                  from cpcent t
                 where t.organization_id = :old.organization_id) set_of_books_id,
               :old.organization_id,
               head_id,
               2,
               :old.billtypecode,
               :old.billtype2code,
               :old.inv_in_bill_head_id,
               :old.invbillno,
               :old.invbilldate,
               :old.year_month,
               :old.dept_id,
               :old.warehouse_id,
               :old.customer_id,
               :old.vendor_id,
               'admin',
               sysdate,
               'admin',
               sysdate,
               '将原审核的入库单改成未审核单据',
               0,
               '',
               (-1) * :old.TOTAL_QTY,
               (-1) * :old.AMOUNT_TOTAL_NOTAX,
               (-1) * :old.AMOUNT_TOTAL_NOTAX_F,
               (-1) * :old.AMOUNT_TOTAL,
               (-1) * :old.AMOUNT_TOTAL_F
          from dual;

      --插入明细
      insert into Intf_To_Inv_Bill_line
        (INTF_TO_BILL_ID,
         INTF_TO_BILL_LINE_ID,
         INV_BILL_ID,
         INV_BILL_LINE_ID,
         ITEM_ID,
         WAREHOUSE_ID,
         BILL_QTY,
         PRICE_TAX,
         AMOUNT_TAX,
         PRICE_NOTAX,
         AMOUNT_NOTAX,
         CREATED_BY,
         CREATION_DATE,
         LAST_UPDATE_BY,
         LAST_UPDATE_DATE,
         REMARK)
        select head_id,
               SQ_INTF_BMS_TO_INVBILL_LINE.Nextval,
               l.inv_in_bill_head_id,
               l.inv_in_bill_line_id,
               l.item_id,
               l.warehouse_id,
               (-1) * l.qty_invbill,
               l.wtpricec_bill_f,
               nvl(l.wtpricec_bill_f * l.qty_invbill * (-1), 0),
               l.wtpricec_bill_f_notax,
               nvl(l.wtpricec_bill_f_notax * l.qty_invbill * (-1), 0),
               'admin',
               sysdate,
               'admin',
               sysdate,
               '将原审核的入库单改成未审核单据'
          from inv_in_bill_line l
         where l.inv_in_bill_head_id = :old.inv_in_bill_head_id;
    end if;

    --dgj 2016.04.05
    --销售退货入库、其它入库、其它入库红冲写入接口表
    if v_count = 1 then
      --审核时写入接口表
      if (:new.is_auditing_wh = 2) and (nvl(:old.is_auditing_wh, 0) <> 2) then
        --销售退货入库
        if (:new.billtypecode = '0206') then
          --取序列
          select sq_inv_out_to_ccs__head.nextval into v_head_id from dual;
          --插入表头
          insert into inv_out_to_ccs_head
            (INV_OUT_TO_CCS_HEAD_ID,
             ORGANIZATION_ID,
             INVBILLNO,
             SOURCE_HEAD_ID,
             WAREHOUSE_ID,
             DATE_INVBILL,
             YEAR_MONTH,
             BILLTYPECODE,
             BILLTYPE2CODE,
             VENDOR_ID,
             DEPT_ID,
             BASE_CURRENCY_ID,
             EXCH_RATE,
             TAX_RATE,
             AMOUNT_TOTAL_NOTAX,
             AMOUNT_TOTAL_NOTAX_F,
             AMOUNT_TOTAL,
             AMOUNT_TOTAL_F,
             CUST_ORDER_NO,
             EMPLOYEE_ID_WH,
             BLUERED,
             NOTE,
             IS_INIT_BILL,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             ATTRIBUTE1,
             ATTRIBUTE2,
             ATTRIBUTE3,
             ATTRIBUTE4,
             ATTRIBUTE5,
             IS_HAVE_ORDER,
             CUSTOMER_ID,
             ENTORGID,
             QTY_SUM,
             TOTAL_CUBAGE,
             ADDRESS1,
             CRM_ENTID,
             WTAMOUNT_DISCOUNT,
             WTAMOUNT_BILLING,
             WTAMOUNT_MONTH,
             AN_INVBILLNO,
             OUTBILL_DATE,
             TAKE_MAN,
             PHONE_CODE,
             SHIPMODE_ID,
             STATUS,
             ERROR_MES,
             WAREHOUSE_CODE,
             VENDOR_CODE,
             DEPT_CODE,
             EMPLOYEE_NAME_WH,
             CUSTOMER_CODE,
             BILL_TYPE)
            select v_head_id INV_IN_TO_CCS_HEAD_ID,
                   :new.organization_id ORGANIZATION_ID,
                   :new.invbillno INVBILLNO,
                   :new.inv_in_bill_head_id INV_IN_BILL_HEAD_ID,
                   :new.warehouse_id WAREHOUSE_ID,
                   :new.invbilldate INVBILLDATE,
                   :new.year_month YEAR_MONTH,
                   :new.billtypecode BILLTYPECODE,
                   :new.billtype2code BILLTYPE2CODE,
                   :new.vendor_id VENDOR_ID,
                   :new.dept_id DEPT_ID,
                   :new.BASE_CURRENCY_ID,
                   :new.EXCH_RATE,
                   :new.TAX_RATE,
                   :new.AMOUNT_TOTAL_NOTAX,
                   :new.AMOUNT_TOTAL_NOTAX_F,
                   :new.AMOUNT_TOTAL,
                   :new.AMOUNT_TOTAL_F,
                   :new.VENDORBILLNO,
                   :new.WHEMPLOYEE_ID,
                   :new.BLUERED,
                   :new.NOTE,
                   :new.IS_INIT_BILL,
                   :new.CREATED_BY,
                   :new.CREATION_DATE,
                   :new.LAST_UPDATED_BY,
                   :new.LAST_UPDATE_DATE,
                   :new.ATTRIBUTE1,
                   :new.ATTRIBUTE2,
                   :new.ATTRIBUTE3,
                   :new.ATTRIBUTE4,
                   :new.ATTRIBUTE5,
                   :new.IS_HAVE_ORDER,
                   :new.CUSTOMER_ID,
                   :new.ENTORGID,
                   :new.TOTAL_QTY,
                   :new.TOTAL_CUBAGE,
                   :new.ADDRESS1,
                   :new.CRM_ENTID,
                   0 WTAMOUNT_DISCOUNT,
                   0 WTAMOUNT_BILLING,
                   0 WTAMOUNT_MONTH,
                   '' AN_INVBILLNO,
                   '' OUTBILL_DATE,
                   '' TAKE_MAN,
                   '' PHONE_CODE,
                   0 SHIPMODE_ID,
                   0 STATUS,
                   '' ERROR_MES,
                   (select w.warehouse_code
                      from warehouse w
                     where w.warehouse_id = :new.warehouse_id
                       and w.organization_id = :new.organization_id) WAREHOUSE_CODE,
                   (select v.vendor_code
                      from vendor v
                     where v.vendor_id = :new.vendor_id) VENDOR_CODE,
                   (select d.dept_code
                      from dept d
                     where d.dept_id = :new.dept_id
                       and d.entid = :new.organization_id) DEPT_CODE,
                   (select s.EMPLOYEE_NAME
                      from erpemployee s
                     where s.EMPLOYEE_ID = :new.whemployee_id) WHEMPLOYEE_NAME,
                   (select c.customer_code
                      from customer c
                     where c.customer_id = :new.customer_id) CUSTOMER_CODE,
                   5 BILL_TYPE
              from dual;
          --插入明细
          insert into inv_out_to_ccs_line
            (INV_OUT_TO_CCS_HEAD_ID,
             INV_OUT_TO_CCS_LINE_ID,
             SOURCE_HEAD_ID,
             SOURCE_LINE_ID,
             LINENO,
             ITEM_ID,
             ITEM_CODE,
             QTY_BILL,
             PRICE_BILL,
             PRICE_BILL_NOTAX,
             PRICE_BILL_F,
             PRICE_BILL_NOTAX_F,
             AMOUNT_BILL_NOTAX_F,
             AMOUNT_BILL_F,
             AMOUNT_BILL_NOTAX,
             AMOUNT_BILL,
             REMARK,
             WAREHOUSE_ID,
             WAREHOUSE_CODE,
             QTY_RED,
             QTY_RED_BILL,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             ATTRIBUTE11,
             ATTRIBUTE21,
             ATTRIBUTE31,
             ATTRIBUTE41,
             ATTRIBUTE51,
             WTPRICEC_BILL_F,
             WTAMOUNT_BILL_F,
             DISCOUNT_TAX,
             DISCOUNT_BEFORE_PRICE,
             WTPRICEC_BILL_F_NOTAX,
             WTAMOUNT_BILL_F_NOTAX,
             DISCOUNT_BEFORE_PRICE_NOTAX,
             INSIDE_BALANCE_PRICE,
             WTAMOUNT_DISCOUNT,
             WTAMOUNT_DISCOUNT_NOTAX,
             WTAMOUNT_BILLING,
             WTAMOUNT_MONTH,
             DISCOUNT_MONTH,
             WTAMOUNT_BILLING_NOTAX)
            select v_head_id INV_IN_TO_CCS_HEAD_ID,
                   sq_inv_in_to_ccs_line.nextval INV_IN_TO_CCS_LINE_ID,
                   l.INV_IN_BILL_HEAD_ID,
                   l.INV_IN_BILL_LINE_ID,
                   l.LINE_NO,
                   l.ITEM_ID,
                   (select i.item_code
                      from item i
                     where i.item_id = l.item_id) ITEM_CODE,
                   l.QTY_INVBILL,
                   l.PRICE_BILL,
                   l.PRICE_BILL_NOTAX,
                   l.PRICEC_BILL_F,
                   l.PRICEC_BILL_NOTAX_F,
                   l.AMOUNT_BILL_NOTAX_F,
                   l.AMOUNT_BILL_F,
                   l.AMOUNT_BILL_NOTAX,
                   l.AMOUNT_BILL,
                   l.REMARK,
                   l.WAREHOUSE_ID,
                   (select w.warehouse_code
                      from warehouse w
                     where w.warehouse_id = l.warehouse_id
                       and w.organization_id = :new.organization_id) WAREHOUSE_CODE,
                   l.QTY_RED,
                   l.QTY_RED_BILL,
                   l.CREATED_BY,
                   l.CREATION_DATE,
                   l.LAST_UPDATED_BY,
                   l.LAST_UPDATE_DATE,
                   l.ATTRIBUTE1,
                   l.ATTRIBUTE2,
                   l.ATTRIBUTE3,
                   l.ATTRIBUTE4,
                   l.ATTRIBUTE5,
                   l.WTPRICEC_BILL_F,
                   l.WTAMOUNT_BILL_F,
                   l.DISCOUNT_TAX,
                   l.DISCOUNT_BEFORE_PRICE,
                   l.WTPRICEC_BILL_F_NOTAX,
                   l.WTAMOUNT_BILL_F_NOTAX,
                   l.DISCOUNT_BEFORE_PRICE_NOTAX,
                   l.INSIDE_BALANCE_PRICE,
                   0 WTAMOUNT_DISCOUNT,
                   0 WTAMOUNT_DISCOUNT_NOTAX,
                   0 WTAMOUNT_BILLING,
                   0 WTAMOUNT_MONTH,
                   0 DISCOUNT_MONTH,
                   0 WTAMOUNT_BILLING_NOTAX
              from inv_in_bill_line l
             where l.inv_in_bill_head_id = :new.inv_in_bill_head_id;
          --其它入库
        elsif (:new.billtypecode = '0199') and (:new.bluered = 'B') and
              (:new.billtype2code <> '061') and
              (:new.billtype2code <> '078') then
          --插入表头
          insert into inv_out_to_ccs_head
            (INV_OUT_TO_CCS_HEAD_ID,
             ORGANIZATION_ID,
             INVBILLNO,
             SOURCE_HEAD_ID,
             WAREHOUSE_ID,
             DATE_INVBILL,
             YEAR_MONTH,
             BILLTYPECODE,
             BILLTYPE2CODE,
             VENDOR_ID,
             DEPT_ID,
             BASE_CURRENCY_ID,
             EXCH_RATE,
             TAX_RATE,
             AMOUNT_TOTAL_NOTAX,
             AMOUNT_TOTAL_NOTAX_F,
             AMOUNT_TOTAL,
             AMOUNT_TOTAL_F,
             CUST_ORDER_NO,
             EMPLOYEE_ID_WH,
             BLUERED,
             NOTE,
             IS_INIT_BILL,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             ATTRIBUTE1,
             ATTRIBUTE2,
             ATTRIBUTE3,
             ATTRIBUTE4,
             ATTRIBUTE5,
             IS_HAVE_ORDER,
             CUSTOMER_ID,
             ENTORGID,
             QTY_SUM,
             TOTAL_CUBAGE,
             ADDRESS1,
             CRM_ENTID,
             WTAMOUNT_DISCOUNT,
             WTAMOUNT_BILLING,
             WTAMOUNT_MONTH,
             AN_INVBILLNO,
             OUTBILL_DATE,
             TAKE_MAN,
             PHONE_CODE,
             SHIPMODE_ID,
             STATUS,
             ERROR_MES,
             WAREHOUSE_CODE,
             VENDOR_CODE,
             DEPT_CODE,
             EMPLOYEE_NAME_WH,
             CUSTOMER_CODE,
             BILL_TYPE)
            select v_head_id INV_IN_TO_CCS_HEAD_ID,
                   :new.organization_id ORGANIZATION_ID,
                   :new.invbillno INVBILLNO,
                   :new.inv_in_bill_head_id INV_IN_BILL_HEAD_ID,
                   :new.warehouse_id WAREHOUSE_ID,
                   :new.invbilldate INVBILLDATE,
                   :new.year_month YEAR_MONTH,
                   :new.billtypecode BILLTYPECODE,
                   :new.billtype2code BILLTYPE2CODE,
                   :new.vendor_id VENDOR_ID,
                   :new.dept_id DEPT_ID,
                   :new.BASE_CURRENCY_ID,
                   :new.EXCH_RATE,
                   :new.TAX_RATE,
                   :new.AMOUNT_TOTAL_NOTAX,
                   :new.AMOUNT_TOTAL_NOTAX_F,
                   :new.AMOUNT_TOTAL,
                   :new.AMOUNT_TOTAL_F,
                   :new.VENDORBILLNO,
                   :new.WHEMPLOYEE_ID,
                   :new.BLUERED,
                   :new.NOTE,
                   :new.IS_INIT_BILL,
                   :new.CREATED_BY,
                   :new.CREATION_DATE,
                   :new.LAST_UPDATED_BY,
                   :new.LAST_UPDATE_DATE,
                   :new.ATTRIBUTE1,
                   :new.ATTRIBUTE2,
                   :new.ATTRIBUTE3,
                   :new.ATTRIBUTE4,
                   :new.ATTRIBUTE5,
                   :new.IS_HAVE_ORDER,
                   :new.CUSTOMER_ID,
                   :new.ENTORGID,
                   :new.TOTAL_QTY,
                   :new.TOTAL_CUBAGE,
                   :new.ADDRESS1,
                   :new.CRM_ENTID,
                   0 WTAMOUNT_DISCOUNT,
                   0 WTAMOUNT_BILLING,
                   0 WTAMOUNT_MONTH,
                   '' AN_INVBILLNO,
                   '' OUTBILL_DATE,
                   '' TAKE_MAN,
                   '' PHONE_CODE,
                   0 SHIPMODE_ID,
                   0 STATUS,
                   '' ERROR_MES,
                   (select w.warehouse_code
                      from warehouse w
                     where w.warehouse_id = :new.warehouse_id
                       and w.organization_id = :new.organization_id) WAREHOUSE_CODE,
                   (select v.vendor_code
                      from vendor v
                     where v.vendor_id = :new.vendor_id) VENDOR_CODE,
                   (select d.dept_code
                      from dept d
                     where d.dept_id = :new.dept_id
                       and d.entid = :new.organization_id) DEPT_CODE,
                   (select s.EMPLOYEE_NAME
                      from erpemployee s
                     where s.EMPLOYEE_ID = :new.whemployee_id) WHEMPLOYEE_NAME,
                   (select c.customer_code
                      from customer c
                     where c.customer_id = :new.customer_id) CUSTOMER_CODE,
                   6 BILL_TYPE
              from dual;
          --插入明细
          insert into inv_out_to_ccs_line
            (INV_OUT_TO_CCS_HEAD_ID,
             INV_OUT_TO_CCS_LINE_ID,
             SOURCE_HEAD_ID,
             SOURCE_LINE_ID,
             LINENO,
             ITEM_ID,
             ITEM_CODE,
             QTY_BILL,
             PRICE_BILL,
             PRICE_BILL_NOTAX,
             PRICE_BILL_F,
             PRICE_BILL_NOTAX_F,
             AMOUNT_BILL_NOTAX_F,
             AMOUNT_BILL_F,
             AMOUNT_BILL_NOTAX,
             AMOUNT_BILL,
             REMARK,
             WAREHOUSE_ID,
             WAREHOUSE_CODE,
             QTY_RED,
             QTY_RED_BILL,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             ATTRIBUTE11,
             ATTRIBUTE21,
             ATTRIBUTE31,
             ATTRIBUTE41,
             ATTRIBUTE51,
             WTPRICEC_BILL_F,
             WTAMOUNT_BILL_F,
             DISCOUNT_TAX,
             DISCOUNT_BEFORE_PRICE,
             WTPRICEC_BILL_F_NOTAX,
             WTAMOUNT_BILL_F_NOTAX,
             DISCOUNT_BEFORE_PRICE_NOTAX,
             INSIDE_BALANCE_PRICE,
             WTAMOUNT_DISCOUNT,
             WTAMOUNT_DISCOUNT_NOTAX,
             WTAMOUNT_BILLING,
             WTAMOUNT_MONTH,
             DISCOUNT_MONTH,
             WTAMOUNT_BILLING_NOTAX)
            select v_head_id INV_IN_TO_CCS_HEAD_ID,
                   sq_inv_in_to_ccs_line.nextval INV_IN_TO_CCS_LINE_ID,
                   l.INV_IN_BILL_HEAD_ID,
                   l.INV_IN_BILL_LINE_ID,
                   l.LINE_NO,
                   l.ITEM_ID,
                   (select i.item_code
                      from item i
                     where i.item_id = l.item_id) ITEM_CODE,
                   l.QTY_INVBILL,
                   l.PRICE_BILL,
                   l.PRICE_BILL_NOTAX,
                   l.PRICEC_BILL_F,
                   l.PRICEC_BILL_NOTAX_F,
                   l.AMOUNT_BILL_NOTAX_F,
                   l.AMOUNT_BILL_F,
                   l.AMOUNT_BILL_NOTAX,
                   l.AMOUNT_BILL,
                   l.REMARK,
                   l.WAREHOUSE_ID,
                   (select w.warehouse_code
                      from warehouse w
                     where w.warehouse_id = l.warehouse_id
                       and w.organization_id = :new.organization_id) WAREHOUSE_CODE,
                   l.QTY_RED,
                   l.QTY_RED_BILL,
                   l.CREATED_BY,
                   l.CREATION_DATE,
                   l.LAST_UPDATED_BY,
                   l.LAST_UPDATE_DATE,
                   l.ATTRIBUTE1,
                   l.ATTRIBUTE2,
                   l.ATTRIBUTE3,
                   l.ATTRIBUTE4,
                   l.ATTRIBUTE5,
                   l.WTPRICEC_BILL_F,
                   l.WTAMOUNT_BILL_F,
                   l.DISCOUNT_TAX,
                   l.DISCOUNT_BEFORE_PRICE,
                   l.WTPRICEC_BILL_F_NOTAX,
                   l.WTAMOUNT_BILL_F_NOTAX,
                   l.DISCOUNT_BEFORE_PRICE_NOTAX,
                   l.INSIDE_BALANCE_PRICE,
                   0 WTAMOUNT_DISCOUNT,
                   0 WTAMOUNT_DISCOUNT_NOTAX,
                   0 WTAMOUNT_BILLING,
                   0 WTAMOUNT_MONTH,
                   0 DISCOUNT_MONTH,
                   0 WTAMOUNT_BILLING_NOTAX
              from inv_in_bill_line l
             where l.inv_in_bill_head_id = :new.inv_in_bill_head_id;
          --其它入库红冲
        elsif (:new.billtypecode = '0199') and (:new.bluered = 'R') and
              (:new.billtype2code <> '061') and
              (:new.billtype2code <> '078') then
          --插入表头
          insert into inv_out_to_ccs_head
            (INV_OUT_TO_CCS_HEAD_ID,
             ORGANIZATION_ID,
             INVBILLNO,
             SOURCE_HEAD_ID,
             WAREHOUSE_ID,
             DATE_INVBILL,
             YEAR_MONTH,
             BILLTYPECODE,
             BILLTYPE2CODE,
             VENDOR_ID,
             DEPT_ID,
             BASE_CURRENCY_ID,
             EXCH_RATE,
             TAX_RATE,
             AMOUNT_TOTAL_NOTAX,
             AMOUNT_TOTAL_NOTAX_F,
             AMOUNT_TOTAL,
             AMOUNT_TOTAL_F,
             CUST_ORDER_NO,
             EMPLOYEE_ID_WH,
             BLUERED,
             NOTE,
             IS_INIT_BILL,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             ATTRIBUTE1,
             ATTRIBUTE2,
             ATTRIBUTE3,
             ATTRIBUTE4,
             ATTRIBUTE5,
             IS_HAVE_ORDER,
             CUSTOMER_ID,
             ENTORGID,
             QTY_SUM,
             TOTAL_CUBAGE,
             ADDRESS1,
             CRM_ENTID,
             WTAMOUNT_DISCOUNT,
             WTAMOUNT_BILLING,
             WTAMOUNT_MONTH,
             AN_INVBILLNO,
             OUTBILL_DATE,
             TAKE_MAN,
             PHONE_CODE,
             SHIPMODE_ID,
             STATUS,
             ERROR_MES,
             WAREHOUSE_CODE,
             VENDOR_CODE,
             DEPT_CODE,
             EMPLOYEE_NAME_WH,
             CUSTOMER_CODE,
             BILL_TYPE)
            select v_head_id INV_IN_TO_CCS_HEAD_ID,
                   :new.organization_id ORGANIZATION_ID,
                   :new.invbillno INVBILLNO,
                   :new.inv_in_bill_head_id INV_IN_BILL_HEAD_ID,
                   :new.warehouse_id WAREHOUSE_ID,
                   :new.invbilldate INVBILLDATE,
                   :new.year_month YEAR_MONTH,
                   :new.billtypecode BILLTYPECODE,
                   :new.billtype2code BILLTYPE2CODE,
                   :new.vendor_id VENDOR_ID,
                   :new.dept_id DEPT_ID,
                   :new.BASE_CURRENCY_ID,
                   :new.EXCH_RATE,
                   :new.TAX_RATE,
                   :new.AMOUNT_TOTAL_NOTAX,
                   :new.AMOUNT_TOTAL_NOTAX_F,
                   :new.AMOUNT_TOTAL,
                   :new.AMOUNT_TOTAL_F,
                   :new.VENDORBILLNO,
                   :new.WHEMPLOYEE_ID,
                   :new.BLUERED,
                   :new.NOTE,
                   :new.IS_INIT_BILL,
                   :new.CREATED_BY,
                   :new.CREATION_DATE,
                   :new.LAST_UPDATED_BY,
                   :new.LAST_UPDATE_DATE,
                   :new.ATTRIBUTE1,
                   :new.ATTRIBUTE2,
                   :new.ATTRIBUTE3,
                   :new.ATTRIBUTE4,
                   :new.ATTRIBUTE5,
                   :new.IS_HAVE_ORDER,
                   :new.CUSTOMER_ID,
                   :new.ENTORGID,
                   :new.TOTAL_QTY,
                   :new.TOTAL_CUBAGE,
                   :new.ADDRESS1,
                   :new.CRM_ENTID,
                   0 WTAMOUNT_DISCOUNT,
                   0 WTAMOUNT_BILLING,
                   0 WTAMOUNT_MONTH,
                   '' AN_INVBILLNO,
                   '' OUTBILL_DATE,
                   '' TAKE_MAN,
                   '' PHONE_CODE,
                   0 SHIPMODE_ID,
                   0 STATUS,
                   '' ERROR_MES,
                   (select w.warehouse_code
                      from warehouse w
                     where w.warehouse_id = :new.warehouse_id
                       and w.organization_id = :new.organization_id) WAREHOUSE_CODE,
                   (select v.vendor_code
                      from vendor v
                     where v.vendor_id = :new.vendor_id) VENDOR_CODE,
                   (select d.dept_code
                      from dept d
                     where d.dept_id = :new.dept_id
                       and d.entid = :new.organization_id) DEPT_CODE,
                   (select s.EMPLOYEE_NAME
                      from erpemployee s
                     where s.EMPLOYEE_ID = :new.whemployee_id) WHEMPLOYEE_NAME,
                   (select c.customer_code
                      from customer c
                     where c.customer_id = :new.customer_id) CUSTOMER_CODE,
                   7 BILL_TYPE
              from dual;
          --插入明细
          insert into inv_out_to_ccs_line
            (INV_OUT_TO_CCS_HEAD_ID,
             INV_OUT_TO_CCS_LINE_ID,
             SOURCE_HEAD_ID,
             SOURCE_LINE_ID,
             LINENO,
             ITEM_ID,
             ITEM_CODE,
             QTY_BILL,
             PRICE_BILL,
             PRICE_BILL_NOTAX,
             PRICE_BILL_F,
             PRICE_BILL_NOTAX_F,
             AMOUNT_BILL_NOTAX_F,
             AMOUNT_BILL_F,
             AMOUNT_BILL_NOTAX,
             AMOUNT_BILL,
             REMARK,
             WAREHOUSE_ID,
             WAREHOUSE_CODE,
             QTY_RED,
             QTY_RED_BILL,
             CREATED_BY,
             CREATION_DATE,
             LAST_UPDATED_BY,
             LAST_UPDATE_DATE,
             ATTRIBUTE11,
             ATTRIBUTE21,
             ATTRIBUTE31,
             ATTRIBUTE41,
             ATTRIBUTE51,
             WTPRICEC_BILL_F,
             WTAMOUNT_BILL_F,
             DISCOUNT_TAX,
             DISCOUNT_BEFORE_PRICE,
             WTPRICEC_BILL_F_NOTAX,
             WTAMOUNT_BILL_F_NOTAX,
             DISCOUNT_BEFORE_PRICE_NOTAX,
             INSIDE_BALANCE_PRICE,
             WTAMOUNT_DISCOUNT,
             WTAMOUNT_DISCOUNT_NOTAX,
             WTAMOUNT_BILLING,
             WTAMOUNT_MONTH,
             DISCOUNT_MONTH,
             WTAMOUNT_BILLING_NOTAX)
            select v_head_id INV_IN_TO_CCS_HEAD_ID,
                   sq_inv_in_to_ccs_line.nextval INV_IN_TO_CCS_LINE_ID,
                   l.INV_IN_BILL_HEAD_ID,
                   l.INV_IN_BILL_LINE_ID,
                   l.LINE_NO,
                   l.ITEM_ID,
                   (select i.item_code
                      from item i
                     where i.item_id = l.item_id) ITEM_CODE,
                   l.QTY_INVBILL,
                   l.PRICE_BILL,
                   l.PRICE_BILL_NOTAX,
                   l.PRICEC_BILL_F,
                   l.PRICEC_BILL_NOTAX_F,
                   l.AMOUNT_BILL_NOTAX_F,
                   l.AMOUNT_BILL_F,
                   l.AMOUNT_BILL_NOTAX,
                   l.AMOUNT_BILL,
                   l.REMARK,
                   l.WAREHOUSE_ID,
                   (select w.warehouse_code
                      from warehouse w
                     where w.warehouse_id = l.warehouse_id
                       and w.organization_id = :new.organization_id) WAREHOUSE_CODE,
                   l.QTY_RED,
                   l.QTY_RED_BILL,
                   l.CREATED_BY,
                   l.CREATION_DATE,
                   l.LAST_UPDATED_BY,
                   l.LAST_UPDATE_DATE,
                   l.ATTRIBUTE1,
                   l.ATTRIBUTE2,
                   l.ATTRIBUTE3,
                   l.ATTRIBUTE4,
                   l.ATTRIBUTE5,
                   l.WTPRICEC_BILL_F,
                   l.WTAMOUNT_BILL_F,
                   l.DISCOUNT_TAX,
                   l.DISCOUNT_BEFORE_PRICE,
                   l.WTPRICEC_BILL_F_NOTAX,
                   l.WTAMOUNT_BILL_F_NOTAX,
                   l.DISCOUNT_BEFORE_PRICE_NOTAX,
                   l.INSIDE_BALANCE_PRICE,
                   0 WTAMOUNT_DISCOUNT,
                   0 WTAMOUNT_DISCOUNT_NOTAX,
                   0 WTAMOUNT_BILLING,
                   0 WTAMOUNT_MONTH,
                   0 DISCOUNT_MONTH,
                   0 WTAMOUNT_BILLING_NOTAX
              from inv_in_bill_line l
             where l.inv_in_bill_head_id = :new.inv_in_bill_head_id;
        end if;

      end if;
    end if;

  end if;
end;
/

