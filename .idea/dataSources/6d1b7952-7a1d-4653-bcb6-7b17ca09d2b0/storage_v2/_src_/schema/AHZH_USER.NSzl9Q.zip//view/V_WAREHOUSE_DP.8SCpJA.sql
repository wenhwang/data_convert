create view V_WAREHOUSE_DP as
select a.warehouse_id,
       a.warehouse_code,
       a.warehouse_name,
       a.organization_id,
       a.warehouse_property,
       a.customer_id
  from warehouse a
 where a.is_end = 2
   and a.usable = 2
   and a.warehouse_type = 1
   and a.asset_property = 1
/

