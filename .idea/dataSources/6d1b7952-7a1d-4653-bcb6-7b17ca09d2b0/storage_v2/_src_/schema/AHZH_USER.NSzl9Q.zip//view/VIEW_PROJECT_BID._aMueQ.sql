create view VIEW_PROJECT_BID as
SELECT PROJECT_BID_NO, --单据编码
       ORGANIZATION_ID, --组织ID
       PROJECT_ID, --项目ID
       BID_OPEN_DATE, --开标日期
       BID_OPEN_ADDRESS, -- 开标地点
       BID_OPEN_METHOD, -- 开标方式
       BID_OPEN_PERSON_ID, --开标授权人
       AQ_END_DATE, --答疑截止时间
       BID_SECURITY, -- 保证金金额
       BID_SECURITY_END_DATE, --保证金支付截止时间
       BID_ORG_NAME, -- 招标机构名称
       BID_ORG_BANK, -- 招标机构开户行
       BID_ORG_ACCOUNT, -- 招标机构账号
       BID_ORG_USER_NAME, -- 招标机构开户名
       BID_ORG_LINKMAN, -- 招标机构联系人
       BID_ORG_PHONENO, --招标机构联系电话
       TECH_SERVICE_TYPE, -- 标书及技术使用(枚举：1 合伙人自制|2 在公司制作)
       IS_TO_PERFORMANCE, --保证金是否转履约(枚举：1|否、2|是）
       IS_AGREE_BID, --是否参与投标(枚举：1|否、2|是）
       BID_CHECK_REMARK --招标评审意见
  FROM EPM_PROJECT_BID_HEAD

  /*********************************************\
  * NAME(名称): VIEW_PROJECT_BID
  * PURPOSE(功能说明):  项目评审
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2019-07-23
  \*********************************************/
/

