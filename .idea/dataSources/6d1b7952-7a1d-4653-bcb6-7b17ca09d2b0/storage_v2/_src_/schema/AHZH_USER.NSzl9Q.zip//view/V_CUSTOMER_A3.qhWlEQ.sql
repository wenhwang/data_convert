create view V_CUSTOMER_A3 as
select customer.customer_id customer_id,/*瀹㈡？ID*/
			 customer.customer_code customer_code,/*瀹㈡？缂？？*/
			 customer.customer_name customer_name,/*瀹㈡？？岖О*/
			 customer_address.address1 customer_address,/*瀹㈡？？板？*/
			 customer_address.defaulted is_defaulted,/*？？？榛？？？板？ 1锛氩？锛?锛？？*/
			 customer_address.take_man take_man,/*？？揣浜*/
			 customer_address.phone_code take_Tel/*？？揣？佃？*/
	from customer,
			 customer_address
 where customer.customer_id = customer_address.customer_id
/

