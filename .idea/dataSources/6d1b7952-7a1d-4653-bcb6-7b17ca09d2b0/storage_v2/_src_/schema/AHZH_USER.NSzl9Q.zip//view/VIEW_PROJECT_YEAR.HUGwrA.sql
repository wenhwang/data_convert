create view VIEW_PROJECT_YEAR as
SELECT HEAD.PROJECT_ID, --项目ID
       HEAD.PROJECT_KK_APPLY_NO, --扣款单号
       APPLY_DATE, --扣款日期
       APPLY_PEOPLE, --经办人
       CHARGE_ITEM_ID,
       CHARGE_STD, --标准
       LINE.APPROVED_AMOUNT AMOUNT --金额
  FROM EPM_PROJECT_KK_APPLY_LINE LINE, EPM_PROJECT_KK_APPLY_HEAD HEAD
 WHERE HEAD.PROJECT_KK_APPLY_HEAD_ID = LINE.PROJECT_KK_APPLY_HEAD_ID
   AND LINE.CHARGE_TYPE = 'WITHHOLD_YEAR_AMOUNT'
   AND HEAD.STAT = 5

/*********************************************\
   * NAME(名称): VIEW_PROJECT_MANAGEMENT
   * PURPOSE(功能说明):  项目扣款-年费
   * AUTHOR(作者): NY
   * CREATE AT(创建时间): 2019-07-20
\*********************************************/
/

