create TYPE "PROJECT_STAT_BY_WECHAT_ROW" AS OBJECT
(
  STEP  INTEGER, --步骤
  STATE VARCHAR2(512) --状态
)
/*********************************************\
  * NAME(名称): PROJECT_STAT_BY_WECHAT_ROW
  * PURPOSE(功能说明):  微信小程序查询项目状态类型
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-09-23
  \*********************************************/
/

