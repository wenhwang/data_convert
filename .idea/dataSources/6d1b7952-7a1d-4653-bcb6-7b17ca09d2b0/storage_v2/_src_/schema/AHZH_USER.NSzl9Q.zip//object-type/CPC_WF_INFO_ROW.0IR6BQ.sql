create TYPE CPC_WF_INFO_ROW AS OBJECT
(
  WFID       INTEGER, --工作流
  USERID     VARCHAR2(96), --过程执行用户
  WFNAME     VARCHAR2(512), --工作流
  SUBJECT    VARCHAR2(375), --流程主题
  STATIME    VARCHAR2(30), --流程开始时间
  ENDTIME    VARCHAR2(30), --流程结束时间
  WF_APERIOD NUMBER(12, 4), --流程耗时

  PROCID       INTEGER, --节点步骤
  PROCNAME     VARCHAR2(96), --过程
  PERIOD       NUMBER(13, 2), --节点计划周期
  NODE_APERIOD NUMBER(12, 4), --节点实际周期
  SCORE        NUMBER(12, 4), --评分
  PSTATIME     VARCHAR2(30), --计划开始时间
  PENDTIME     VARCHAR2(30), --计划结束时间
  ASTATIME     VARCHAR2(30), --实际开始时间
  AENDTIME     VARCHAR2(30), --实际结束时间
  OPINION      VARCHAR2(2048) --处理方式
)

/*********************************************\
  * NAME(名称): CPC_WF_INFO_ROW
  * PURPOSE(功能说明):  流程监控类型
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-11-08
  \*********************************************/
/

