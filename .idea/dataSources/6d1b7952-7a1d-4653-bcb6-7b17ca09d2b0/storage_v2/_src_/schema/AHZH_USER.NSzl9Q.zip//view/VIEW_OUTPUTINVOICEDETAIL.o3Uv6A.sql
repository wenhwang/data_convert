create view VIEW_OUTPUTINVOICEDETAIL as
SELECT "PROJECT_CODE","PROJECT_NAME","INVOICE_CONTENT","INVOICE_TYPE_NAME","INVOICE_NUMBER","INVOICE_DATE","INVOICE_AMOUNT","TAX_RATE","TAX_AMOUNT"
          FROM (SELECT PROJECT_CODE,
                       PROJECT_NAME,
                       DETAIL.INVOICE_CONTENT,
                       DECODE(DETAIL.INVOICE_TYPE,
                              1,
                              '专用发票(纸)',
                              2,
                              '普通发票(纸)',
                              3,
                              '专用发票(电)',
                              4,
                              '普通发票(电)') INVOICE_TYPE_NAME,
                       DETAIL.INVOICE_NUMBER,
                       DETAIL.INVOICE_DATE,
                       DETAIL.INVOICE_AMOUNT,
                       DETAIL.TAX_RATE,
                       TAX_AMOUNT
                  FROM FD_OUTPUT_INVOICE_LIST DETAIL,
                       FD_OUTPUT_INVOICE_APPLY APPLY,
                       EPM_PROJECT
                 WHERE APPLY.OUTPUT_INVOICE_APPLY_ID = DETAIL.OUTPUT_INVOICE_APPLY_ID
                   AND APPLY.PROJECT_ID = EPM_PROJECT.PROJECT_ID(+)
                   AND APPLY.STAT = 5
                   AND DETAIL.IS_USABLE = 2)  WHERE 1 = 1
/*********************************************\
  * NAME(名称): VIEW_OUTPUTINVOICEDETAIL
  * PURPOSE(功能说明):  钉钉智能报表-项目开票明细
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-11-14
  \*********************************************/
/

