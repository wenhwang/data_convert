create PROCEDURE           PRO_RECEIPTS_RECORD(P_ORGANIZATION_ID FD_FUND_BUSINESS.ORGANIZATION_ID%TYPE,
                                                P_PROJECT_ID      FD_FUND_BUSINESS.PROJECT_ID%TYPE,
                                                P_PAYMENT_TYPE    FD_FUND_BUSINESS.PAYMENT_TYPE%TYPE,
                                                P_BUSINESS_TYPE   FD_FUND_BUSINESS.BUSINESS_TYPE%TYPE,
                                                P_AMOUNT_DEBIT    FD_FUND_BUSINESS.AMOUNT_DEBIT%TYPE) AS
BEGIN

  --2:业主
  IF P_PAYMENT_TYPE = 2 THEN
    CASE P_BUSINESS_TYPE
    -- 2.1工程款
      WHEN 6 THEN
        UPDATE EPM_PROJECT_ACCOUNT_BALANCE
           SET PROJECT_RECEIVE_AMOUNT = NVL(PROJECT_RECEIVE_AMOUNT, 0) +
                                        P_AMOUNT_DEBIT
         WHERE PROJECT_ID = P_PROJECT_ID
           AND ORGANIZATION_ID = P_ORGANIZATION_ID;

    -- 2.5投标保证金
      WHEN 5 THEN
        UPDATE EPM_PROJECT_ACCOUNT_BALANCE
           SET IN_AGENT_MARGIN_AMOUNT = NVL(IN_AGENT_MARGIN_AMOUNT, 0) +
                                        P_AMOUNT_DEBIT
         WHERE PROJECT_ID = P_PROJECT_ID
           AND ORGANIZATION_ID = P_ORGANIZATION_ID;

    -- 2.6履约保证金
      WHEN 6 THEN
        UPDATE EPM_PROJECT_ACCOUNT_BALANCE
           SET IN_AGENT_SECURITY_AMOUNT = NVL(IN_AGENT_SECURITY_AMOUNT, 0) +
                                          P_AMOUNT_DEBIT
         WHERE PROJECT_ID = P_PROJECT_ID
           AND ORGANIZATION_ID = P_ORGANIZATION_ID;

    END CASE;

  END IF;

  --3:合伙人
  IF P_PAYMENT_TYPE = 3 THEN
    CASE P_BUSINESS_TYPE

    -- 3.3 投资款
      WHEN 3 THEN
        UPDATE EPM_PROJECT_ACCOUNT_BALANCE
           SET LOAN_AMOUNT = NVL(LOAN_AMOUNT, 0) + P_AMOUNT_DEBIT
         WHERE PROJECT_ID = P_PROJECT_ID
           AND ORGANIZATION_ID = P_ORGANIZATION_ID;

    -- 3.4 投资款
      WHEN 4 THEN
        UPDATE EPM_PROJECT_ACCOUNT_BALANCE
           SET PROJECT_INVEST_AMOUNT = NVL(PROJECT_INVEST_AMOUNT, 0) +
                                       P_AMOUNT_DEBIT
         WHERE PROJECT_ID = P_PROJECT_ID
           AND ORGANIZATION_ID = P_ORGANIZATION_ID;

    -- 3.5 投标保证金
      WHEN 5 THEN
        UPDATE EPM_PROJECT_ACCOUNT_BALANCE
           SET IN_PARTNER_MARGIN_AMOUNT = NVL(IN_PARTNER_MARGIN_AMOUNT, 0) +
                                          P_AMOUNT_DEBIT
         WHERE PROJECT_ID = P_PROJECT_ID
           AND ORGANIZATION_ID = P_ORGANIZATION_ID;

    -- 3.6 履约保证金
      WHEN 6 THEN
        UPDATE EPM_PROJECT_ACCOUNT_BALANCE
           SET IN_PARTNER_SECURITY_AMOUNT = NVL(IN_PARTNER_SECURITY_AMOUNT,
                                                0) + P_AMOUNT_DEBIT
         WHERE PROJECT_ID = P_PROJECT_ID
           AND ORGANIZATION_ID = P_ORGANIZATION_ID;

    -- 3.8 材料
      WHEN 3 THEN
        UPDATE EPM_PROJECT_ACCOUNT_BALANCE
           SET AGENT_PURCHASE_IN_AMOUNT = NVL(AGENT_PURCHASE_IN_AMOUNT, 0) +
                                          P_AMOUNT_DEBIT
         WHERE PROJECT_ID = P_PROJECT_ID
           AND ORGANIZATION_ID = P_ORGANIZATION_ID;

    -- 3.9 往来调拨
      WHEN 3 THEN
        UPDATE EPM_PROJECT_ACCOUNT_BALANCE
           SET TRANSFER_IN_AMOUNTOUNT = NVL(TRANSFER_IN_AMOUNT, 0) +
                                        P_AMOUNT_DEBIT
         WHERE PROJECT_ID = P_PROJECT_ID
           AND ORGANIZATION_ID = P_ORGANIZATION_ID;
    END CASE;

  END IF;

  --提交
  COMMIT;
END;

  /*********************************************\
  * NAME(名称): PRO_RECEIPTS_RECORD
  * PURPOSE(功能说明):  更新项目余额表
  * PARAM(参数说明):   P_ORGANIZATION_ID INTEGER; --组织
                                    P_PROJECT_ID      INTEGER; --项目
                                    P_PAYMENT_TYPE    INTEGER; --回款单位类型 2: 业主 3:合伙人
                                   P_BUSINESS_TYPE   INTEGER; --回款类型: 1:工程款 2:年费
                                                                                                    3:公司借款 4:工程费用
                                                                                                    5:投标保证金 6:履约保证金
                                                                                                    8:材料 9往来调拨
                                                                                                   10:管理费 11:其他
                                   P_AMOUNT_DEBIT    NUMBER(12, 4) --金额
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2017-10-20
  \*********************************************/
/

