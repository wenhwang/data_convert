create view VIEW_GL_ACCOUNT_PERIOD as
Select c.Includecompany,
       c.Entid,
       c.Entname,
       Ga.Year_Month,
       Ga.Organization_Id,
       (Select Max(Gah.Chg_Time) Max_Chg_Time
          From Gl_Account_Period_History Gah
         Where Chg_Type = '镐昏处链？？'
           And Gah.Year_Month =
               To_Char(Add_Months(To_Date(Ga.Year_Month, 'yyyy-mm'), -1),
                       'yyyy-mm')
           And Gah.Organization_Id = Ga.Organization_Id) Close_Time
  From Gl_Account_Period Ga, Cpcent c
 Where Ga.Is_Current_Period_Gl = 2
   And Ga.Organization_Id = c.Entid
   And c.Isdisabled <> 2
      --灞？？宸茬？澶辨？？？？？？？镟寸？缁？？
   And c.Entid Not In (2, 15, 16, 22, 59, 62, 70)
 Order By Includecompany, Year_Month
/

