create Function           Fn_Scm_GetScCostPrice(p_Item_Id         Number,
                                               p_Organization_Id Number,
                                               p_Year_Month      Varchar2)
  Return Number Is
  Result   Number;
  price    Number;


  /*
  获取对应月份的成本价格，对应月份没有成本价就取最大月份的成本价
  p_Organization_Id  产品组织ID
  p_Item_Id  物料ID
  p_Year_Month  年月
  */
Begin

  price    := 0;


  SELECT SP1.PRICE
    into price
    FROM sc_costmaster SP1
   WHERE SP1.ITEM_ID = p_Item_Id AND SP1.YEAR_MONTH <= p_Year_Month AND
         sp1.organization_id = p_Organization_Id and SP1.PRICE > 0 AND
         NOT EXISTS
   (SELECT 1
            FROM sc_costmaster SP2
           WHERE SP2.ORGANIZATION_ID = SP1.ORGANIZATION_ID AND
                 SP2.ITEM_ID = SP1.ITEM_ID AND
                 SP2.YEAR_MONTH <= p_Year_Month AND SP2.PRICE > 0 AND
                 SP1.YEAR_MONTH < SP2.YEAR_MONTH);

  Result := price;

  RETURN NVL(Result, 0);

End Fn_Scm_GetScCostPrice;
/

