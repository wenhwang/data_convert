create view VIEW_FIN_RECEIPT_CROSSWISE as
SELECT "PROJECT_ID",
       "PROJECT_RECEIVE_AMOUNT",
       "PROJECT_INVEST_AMOUNT",
       "IN_PARTNER_MARGIN_AMOUNT",
       "IN_PARTNER_SECURITY_AMOUNT",
       "IN_YEAR_AMOUNT",
       "IN_MANAGE_AMOUNT",
       "IN_TAXATION_AMOUNT",
       "IN_OTHER_AMOUNT",
       "TRANSFER_IN_AMOUNT",
       "BORROW_IN_AMOUNT",
       "PAYMENT_IN_AMOUNT",
       "INPUT_INVOICE_AMOUNT",
       "INPUT_VAT_AMOUNT"
  FROM (SELECT PROJECT_ID, PAYMENT_TYPE_CODE, SUM(AMOUNT_DEBIT) AMOUNT_DEBIT
          FROM (SELECT LINE.PROJECT_ID, --收款金额
                       PAYMENT_TYPE_CODE,
                       (LINE.AMOUNT * LINE.PLUS_MINUS) AMOUNT_DEBIT
                  FROM FIN_RECEIPT_VOUCHER_LINE LINE,
                       FIN_RECEIPT_VOUCHER      HEAD,
                       FD_PAYMENT_TYPE          PAYMENT
                 WHERE LINE.FIN_RECEIPT_VOUCHER_ID =
                       HEAD.FIN_RECEIPT_VOUCHER_ID
                   AND HEAD.BUSINESS_TYPE = PAYMENT.FD_PAYMENT_TYPE_ID
                   AND PAYMENT_IO = 1
                   AND HEAD.STAT = 5
                UNION ALL
                SELECT HEAD.PROJECT_ID, --累计收票
                       'S98' PAYMENT_TYPE_CODE,
                       LINE.INVOICE_AMOUNT AMOUNT_DEBIT
                  FROM FD_INPUT_INVOICE_LINE LINE, FD_INPUT_INVOICE_HEAD HEAD
                 WHERE HEAD.INPUT_INVOICE_HEAD_ID =
                       LINE.INPUT_INVOICE_HEAD_ID
                   AND HEAD.STAT = 5
                UNION ALL
                SELECT HEAD.PROJECT_ID,
                       'S99' PAYMENT_TYPE_CODE, --进项票税额
                       LINE.TAX_AMOUNT AMOUNT_DEBIT
                  FROM FD_INPUT_INVOICE_LINE LINE, FD_INPUT_INVOICE_HEAD HEAD
                 WHERE HEAD.INPUT_INVOICE_HEAD_ID =
                       LINE.INPUT_INVOICE_HEAD_ID
                   AND HEAD.STAT = 5)
         GROUP BY PROJECT_ID, PAYMENT_TYPE_CODE) PIVOT(SUM(AMOUNT_DEBIT) FOR PAYMENT_TYPE_CODE IN (

       'S01' PROJECT_RECEIVE_AMOUNT, 'S02' PROJECT_INVEST_AMOUNT,

       'S03' IN_PARTNER_MARGIN_AMOUNT, 'S04' IN_PARTNER_SECURITY_AMOUNT,

       'S05' IN_YEAR_AMOUNT, 'S06' IN_MANAGE_AMOUNT,

       'S07' IN_TAXATION_AMOUNT, 'S08' IN_OTHER_AMOUNT,

       'S09' TRANSFER_IN_AMOUNT,

       'S10' BORROW_IN_AMOUNT,

       'S11' PAYMENT_IN_AMOUNT,

       'S98' INPUT_INVOICE_AMOUNT,

       'S99' INPUT_VAT_AMOUNT))

/*********************************************\
  * NAME(名称): VIEW_FIN_PAYING_CROSSWISE
  * PURPOSE(功能说明):  收款合计横向列表(业务单据)
                                    S01 收工程款 PROJECT_RECEIVE_AMOUNT
                                    S02 收投资款 PROJECT_INVEST_AMOUNT

                                    S03 收投标保证金 IN_PARTNER_MARGIN_AMOUNT
                                    S04 收履约保证金 IN_PARTNER_SECURITY_AMOUNT

                                    S05 收年费 IN_YEAR_AMOUNT
                                    S06 收管理费 IN_MANAGE_AMOUNT
                                    S07 收税费 IN_TAXATION_AMOUNT
                                    S08 收其他款项 IN_OTHER_AMOUNT

                                    S09 收到调拨款 TRANSFER_IN_AMOUNT

                                    S10 公司借入 BORROW_IN_AMOUNT

                                    S11 收到公司借支款 PAYMENT_IN_AMOUNT

                                    S98 累计收票 INPUT_INVOICE_AMOUNT

                                    S99 进项票税额 INPUT_VAT_AMOUNT

  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2017-12-18
  \*********************************************/
/

