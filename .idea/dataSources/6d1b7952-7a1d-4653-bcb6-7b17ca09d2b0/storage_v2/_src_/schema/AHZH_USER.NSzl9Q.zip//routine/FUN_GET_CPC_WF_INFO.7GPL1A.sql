create FUNCTION FUN_GET_CPC_WF_INFO(P_ORGANIZATION_IDS VARCHAR2, --组织
                                               P_USERID           VARCHAR2, --过程执行者
                                               P_START_DATE       VARCHAR2, --起始日期
                                               P_END_DATE         VARCHAR2 --终止日期
                                               ) RETURN CPC_WF_INFO_TABLE
  PIPELINED IS
  RESULT CPC_WF_INFO_ROW; --定义RESULT为行对象类型

  V_WFNAME     VARCHAR2(512); --工作流
  V_SUBJECT    VARCHAR2(375); --流程主题
  V_STATIME    VARCHAR2(30); --流程开始时间
  V_ENDTIME    VARCHAR2(30); --流程结束时间
  V_WF_APERIOD NUMBER(12, 4); --流程耗时
  V_OPINION    VARCHAR2(2048); --流程意见

BEGIN

  FOR V_CPC_WF_INFO IN (SELECT WFPROC.WFID,
                               PROCUSER.USERID, --过程执行用户
                               WFPROC.APERIOD, --总耗用时间
                               WFPROC.PROCID, --节点步骤
                               PROCNAME, --过程
                               WFPROC.PERIOD, --计划周期
                               WFPROC.SCORE, --评分
                               WFPROC.APERIOD NODE_APERIOD,
                               WFPROC.PSTATIME, --计划开始时间
                               WFPROC.PENDTIME, --计划结束时间
                               WFPROC.ASTATIME, --实际开始时间
                               WFPROC.AENDTIME --实际结束时间  
                          FROM CPCWFPROC_V WFPROC, CPCPROCUSER_V PROCUSER
                         WHERE WFPROC.WFID = PROCUSER.WFID
                           AND WFPROC.PROCID = PROCUSER.PROCID
                           AND (USERID = P_USERID OR P_USERID IS NULL)
                           AND SUBSTR(WFPROC.PSTATIME, 1, 10) >=
                               P_START_DATE
                           AND SUBSTR(WFPROC.PSTATIME, 1, 10) <= P_END_DATE) LOOP
  
    --1.判断流程是否所属指定组织(流程非指定组织,退出本次循环)
    BEGIN
      SELECT WFNAME, SUBJECT, STATIME, ENDTIME, APERIOD
        INTO V_WFNAME, V_SUBJECT, V_STATIME, V_ENDTIME, V_WF_APERIOD
        FROM CPCWF,
             (SELECT WFTEMP.WFTEMPID, CPCFDR.ENTIDS
                FROM CPCFDRREF, CPCFDR, CPCWFTEMP WFTEMP
               WHERE CPCFDR.FDRID = CPCFDRREF.FDRID
                 AND CPCFDRREF.REFID = WFTEMP.WFTEMPID
                 AND REFTYPE = 7) ORGANIZATIONS
       WHERE CPCWF.WFTEMPID = ORGANIZATIONS.WFTEMPID
         AND WFID = V_CPC_WF_INFO.WFID
         AND ENTIDS LIKE '%' || P_ORGANIZATION_IDS || '%';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        CONTINUE;
    END;
  
    --2.获取审批人审批意见
    BEGIN
      SELECT OPINION
        INTO V_OPINION
        FROM (SELECT WFID,
                     PROCID,
                     USERID,
                     OPINION,
                     ROW_NUMBER() OVER(PARTITION BY WFID, PROCID, USERID ORDER BY FREQ DESC) RN
                FROM CPCUSEROPINION_V)
       WHERE RN <= 1
         AND WFID = V_CPC_WF_INFO.WFID
         AND PROCID = V_CPC_WF_INFO.PROCID
         AND USERID = V_CPC_WF_INFO.USERID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_OPINION := '';
    END;
  
    RESULT := CPC_WF_INFO_ROW(V_CPC_WF_INFO.WFID,
                              V_CPC_WF_INFO.USERID,
                              V_WFNAME,
                              V_SUBJECT,
                              V_STATIME,
                              V_ENDTIME,
                              V_WF_APERIOD,
                              
                              V_CPC_WF_INFO.PROCID,
                              V_CPC_WF_INFO.PROCNAME,
                              V_CPC_WF_INFO.PERIOD,
                              V_CPC_WF_INFO.NODE_APERIOD,
                              V_CPC_WF_INFO.SCORE,
                              V_CPC_WF_INFO.PSTATIME,
                              V_CPC_WF_INFO.PENDTIME,
                              V_CPC_WF_INFO.ASTATIME,
                              V_CPC_WF_INFO.AENDTIME,
                              V_OPINION);
  
    PIPE ROW(RESULT);
  END LOOP;

  -- 返回数据
  RETURN;

END;

  /*********************************************\
  * NAME(名称): FUN_GET_CPC_WF_INFO
  * PURPOSE(功能说明):  获取流程执行明细
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-11-08
  \*********************************************/
/

