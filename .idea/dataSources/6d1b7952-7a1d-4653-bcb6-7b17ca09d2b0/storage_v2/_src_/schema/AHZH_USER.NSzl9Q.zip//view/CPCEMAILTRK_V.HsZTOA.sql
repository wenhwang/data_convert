create view CPCEMAILTRK_V as
select "SYSUSERID",
       "EMAILID",
       "SENDTO",
       "FLAG",
       "SIGNED",
       "RECEIVETIME",
       "READTIME",
       "SIGNTIME",
       "OPINION",
       "SOURCEUSER",
       "EMAILCID",
       "MYFLAG",
       "EMAILTYPE",
       "ISBCC"
  from cpcemailtrk
/

