create view VIEW_INV_IN_CGZG as
select iibh.organization_id, iibh.invbillno, iibh.year_month, iibh.invbilldate, vendor_code, vendor_name, item_code, item_name,
       iibh.is_have_order, iibh.bluered, iibh.red_type, iibh.iscredence, gch.credence_no, sph.pono, iibh.erp_order_no,
       warehouse_code, warehouse_name, iibl.price_bill_notax, iibl.pricec_bill_notax_f,
       (iibl.qty_invbill-iibl.qty_match_total) qty_zg,
       round((iibl.qty_invbill-iibl.qty_match_total)*iibl.price_bill_notax,2) amount_bill_notax,
       round((iibl.qty_invbill-iibl.qty_match_total)*iibl.price_bill_notax,2) amount_bill_notax_f
  from inv_in_bill_head iibh, inv_in_bill_line iibl, srm_po_head sph,
       srm_po_line spl, item i, vendor v, warehouse w, gl_credence_head gch
 where iibh.inv_in_bill_head_id = iibl.inv_in_bill_head_id
   and iibl.item_id = i.item_id(+)
   and iibh.vendor_id = v.vendor_id(+)
   and iibl.warehouse_id = w.warehouse_id(+)
   and iibl.srm_po_head_id = sph.srm_po_head_id(+)
   and iibl.srm_po_line_id = spl.srm_po_line_id(+)
   and iibh.gl_credence_head_id = gch.gl_credence_head_id(+)
   and iibh.is_auditing_wh = 2
   and iibh.billtypecode in ('0101')
   --and iibl.qty_invbill <> iibl.qty_match_total
   and (abs(iibl.Qty_InvBill) - abs(iibl.Qty_Match_Total)>0)
/

