create FUNCTION FUN_UNIX_TO_ORACLE(IN_NUMBER NUMBER) RETURN DATE IS
BEGIN
  RETURN(TO_DATE('19700101', 'YYYYMMDD') + IN_NUMBER / 86400 +
         TO_NUMBER(SUBSTR(TZ_OFFSET(SESSIONTIMEZONE), 1, 3)) / 24);

END FUN_UNIX_TO_ORACLE

  /*********************************************\
  * NAME(名称): FUN_UNIX_TO_ORACLE
  * PURPOSE(功能说明):  ORACLE UNIX时间戳与DATE转换
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2019-08-13
  \*********************************************/
;
/

