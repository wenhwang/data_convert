create view DRP_CUST as
SELECT a.customer_id      cust_id,
       a.customer_pid     cust_pid,
       a.customer_idpath  cust_idpath,
       a.customer_code    cust_code,
       a.customer_name    cust_name,
       a.short_name       short_name,
       10214                  orgid,
       0104050201               org_code,
       '链？？？？？'               org_name,
       null               idpath,
       b.areaid           areaid,
       b.customer_type    cust_type,
       b.address          address,
       b.usable           usable,
       b.created_by       creator,
       b.creation_date    create_time,
       b.last_updated_by  updator,
       b.last_update_date update_time,
       b.organization_id  entid,
       b.note             note
  FROM customer a, customer_org b
 where a.customer_id = b.customer_id
/

