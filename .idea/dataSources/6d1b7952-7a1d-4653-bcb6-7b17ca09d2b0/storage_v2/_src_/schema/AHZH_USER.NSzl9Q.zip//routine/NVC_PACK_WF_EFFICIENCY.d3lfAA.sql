create PROCEDURE           NVC_PACK_WF_EFFICIENCY(I_USERID    CPCUSER.USERID%TYPE,
                                                   I_ORGNAME   CPCORG.ORGNAME%TYPE,
                                                   I_STARTTIME CPCWFPROC.ASTATIME%TYPE,
                                                   I_ENDTIME   CPCWFPROC.AENDTIME%TYPE) AS

BEGIN
  /*0.------------------------------------ 清空表数据*/
  EXECUTE IMMEDIATE 'TRUNCATE TABLE CPC_WF_EFFICIENCY_ANALYSIS';

  /*1.------------------------------------ 接收流程数量*/
  INSERT
    INTO CPC_WF_EFFICIENCY_ANALYSIS(USERID, ORGNAME, SUBMITSUM)(
    SELECT WF.USERID, ORG.ORGNAME, SUBMITSUM
      FROM (SELECT CPCWFPROC_V.MANAGER USERID, COUNT(1) SUBMITSUM
              FROM CPCWFPROC_V
             WHERE (CPCWFPROC_V.PROCID <> 0 AND CPCWFPROC_V.PROCID <> 99999)
               AND CPCWFPROC_V.MANAGER IS NOT NULL
                  --时间段
               AND ((CPCWFPROC_V.ASTATIME >= I_STARTTIME OR
                   I_STARTTIME IS NULL) AND
                   (CPCWFPROC_V.AENDTIME <= I_ENDTIME OR I_ENDTIME IS NULL))
                  --评审员
               AND (CPCWFPROC_V.MANAGER = I_USERID OR I_USERID IS NULL)
             GROUP BY CPCWFPROC_V.MANAGER) WF,
           (SELECT USERID, WM_CONCAT(ORGNAME) ORGNAME
              FROM (SELECT CPCUSER.USERID, CPCORG.ORGNAME
                      FROM CPCUSER, CPCORG, CPCORGUSER
                     WHERE CPCORGUSER.ORGID = CPCORG.ORGID
                       AND CPCORGUSER.SYSUSERID = CPCUSER.SYSUSERID
                       AND (ORGNAME = I_ORGNAME OR I_ORGNAME IS NULL))
             GROUP BY USERID, ORGNAME) ORG
     WHERE WF.USERID = ORG.USERID(+));
  COMMIT;

  /*2.------------------------------------ 按时完成流程数量,按时完成平均处理时间*/
  UPDATE CPC_WF_EFFICIENCY_ANALYSIS ANALYSIS
     SET (PROCWFMINTIME, AVGRUNTIME) = (SELECT PROCWFMINTIME, AVGRUNTIME
                                          FROM (SELECT MANAGER USERID,
                                                       COUNT(1) PROCWFMINTIME,
                                                       ROUND(SUM(HOUSE) /
                                                             COUNT(1),
                                                             2) AVGRUNTIME
                                                  FROM (SELECT CPCWFPROC_V.MANAGER,
                                                               CPCWFPROC_V.STAT,
                                                               ROUND(NVC_FUNC_GET_WORKING_DAY(TO_DATE(CPCWFPROC_V.ASTATIME,
                                                                                                      'YYYY-MM-DD HH24:MI:SS'),
                                                                                              TO_DATE(CPCWFPROC_V.AENDTIME,
                                                                                                      'YYYY-MM-DD HH24:MI:SS')),
                                                                     2) HOUSE,
                                                               CPCWFPROC.PERIOD
                                                          FROM CPCWFPROC_V,
                                                               (SELECT CPCWF.WFID,
                                                                       CPCWFPROCTEMP.PROCTEMPID,
                                                                       CPCWFPROCTEMP.PERIOD
                                                                  FROM CPCWF,
                                                                       CPCWFPROCTEMP,
                                                                       CPCWFTEMP
                                                                 WHERE CPCWF.WFTEMPID =
                                                                       CPCWFTEMP.WFTEMPID
                                                                   AND CPCWFPROCTEMP.WFTEMPID =
                                                                       CPCWFTEMP.WFTEMPID
                                                                   AND (CPCWFPROCTEMP.PROCTEMPID <> 0 AND
                                                                       CPCWFPROCTEMP.PROCTEMPID <>
                                                                       99999)) CPCWFPROC
                                                         WHERE CPCWFPROC_V.WFID =
                                                               CPCWFPROC.WFID
                                                           AND CPCWFPROC_V.PROCID =
                                                               CPCWFPROC.PROCTEMPID
                                                           AND (CPCWFPROC_V.PROCID <> 0 AND
                                                               CPCWFPROC_V.PROCID <>
                                                               99999)
                                                           AND CPCWFPROC_V.MANAGER IS NOT NULL
                                                              --时间段
                                                           AND ((CPCWFPROC_V.ASTATIME >=
                                                               I_STARTTIME OR
                                                               I_STARTTIME IS NULL) AND
                                                               (CPCWFPROC_V.AENDTIME <=
                                                               I_ENDTIME OR
                                                               I_ENDTIME IS NULL))
                                                              --评审员
                                                           AND (CPCWFPROC_V.MANAGER =
                                                               I_USERID OR
                                                               I_USERID IS NULL))
                                                 WHERE STAT = 7
                                                   AND NVL(PERIOD, 0) >
                                                       NVL(HOUSE, 0)
                                                 GROUP BY MANAGER) DUAL
                                         WHERE DUAL.USERID = ANALYSIS.USERID);
  COMMIT;

  /*3.------------------------------------ 处理中流程数量*/
  UPDATE CPC_WF_EFFICIENCY_ANALYSIS ANALYSIS
     SET (BEINGPROCESSEDSUM) = (SELECT BEINGPROCESSEDSUM
                                  FROM (SELECT USERID,
                                               COUNT(1) BEINGPROCESSEDSUM
                                          FROM (SELECT CPCWFPROC_V.MANAGER USERID,
                                                       CPCWFPROC_V.STAT
                                                  FROM CPCWFPROC_V,
                                                       (SELECT CPCWF.WFID,
                                                               CPCWFPROCTEMP.PROCTEMPID,
                                                               CPCWFPROCTEMP.PERIOD
                                                          FROM CPCWF,
                                                               CPCWFPROCTEMP,
                                                               CPCWFTEMP
                                                         WHERE CPCWF.WFTEMPID =
                                                               CPCWFTEMP.WFTEMPID
                                                           AND CPCWFPROCTEMP.WFTEMPID =
                                                               CPCWFTEMP.WFTEMPID
                                                           AND (CPCWFPROCTEMP.PROCTEMPID <> 0 AND
                                                               CPCWFPROCTEMP.PROCTEMPID <>
                                                               99999)) CPCWFPROC
                                                 WHERE CPCWFPROC_V.WFID =
                                                       CPCWFPROC.WFID
                                                   AND CPCWFPROC_V.PROCID =
                                                       CPCWFPROC.PROCTEMPID
                                                   AND (CPCWFPROC_V.PROCID <> 0 AND
                                                       CPCWFPROC_V.PROCID <>
                                                       99999)
                                                   AND CPCWFPROC_V.MANAGER IS NOT NULL
                                                      --时间段
                                                   AND ((CPCWFPROC_V.ASTATIME >=
                                                       I_STARTTIME OR
                                                       I_STARTTIME IS NULL) AND
                                                       (CPCWFPROC_V.AENDTIME <=
                                                       I_ENDTIME OR
                                                       I_ENDTIME IS NULL))
                                                      --评审员
                                                   AND (CPCWFPROC_V.MANAGER =
                                                       I_USERID OR
                                                       I_USERID IS NULL))
                                         WHERE STAT = 4
                                         GROUP BY USERID) DUAL
                                 WHERE DUAL.USERID = ANALYSIS.USERID);
  COMMIT;

  /*4.------------------------------------ 超时完成流程数量, 超期完成平均处理时间*/
  UPDATE CPC_WF_EFFICIENCY_ANALYSIS ANALYSIS
     SET (OUTTIMESUM, PROCWFMAXTIME) = (SELECT OUTTIMESUM, PROCWFMAXTIME
                                          FROM (SELECT USERID,
                                                       COUNT(1) OUTTIMESUM,
                                                       ROUND(SUM(HOUSE) /
                                                             COUNT(1),
                                                             2) PROCWFMAXTIME
                                                  FROM (SELECT CPCWFPROC_V.MANAGER USERID,
                                                               CPCWFPROC_V.STAT,
                                                               ROUND(NVC_FUNC_GET_WORKING_DAY(TO_DATE(CPCWFPROC_V.ASTATIME,
                                                                                                      'YYYY-MM-DD HH24:MI:SS'),
                                                                                              TO_DATE(CPCWFPROC_V.AENDTIME,
                                                                                                      'YYYY-MM-DD HH24:MI:SS')),
                                                                     2) HOUSE,
                                                               CPCWFPROC.PERIOD
                                                          FROM CPCWFPROC_V,
                                                               (SELECT CPCWF.WFID,
                                                                       CPCWFPROCTEMP.PROCTEMPID,
                                                                       CPCWFPROCTEMP.PERIOD
                                                                  FROM CPCWF,
                                                                       CPCWFPROCTEMP,
                                                                       CPCWFTEMP
                                                                 WHERE CPCWF.WFTEMPID =
                                                                       CPCWFTEMP.WFTEMPID
                                                                   AND CPCWFPROCTEMP.WFTEMPID =
                                                                       CPCWFTEMP.WFTEMPID
                                                                   AND (CPCWFPROCTEMP.PROCTEMPID <> 0 AND
                                                                       CPCWFPROCTEMP.PROCTEMPID <>
                                                                       99999)) CPCWFPROC
                                                         WHERE CPCWFPROC_V.WFID =
                                                               CPCWFPROC.WFID
                                                           AND CPCWFPROC_V.PROCID =
                                                               CPCWFPROC.PROCTEMPID
                                                           AND (CPCWFPROC_V.PROCID <> 0 AND
                                                               CPCWFPROC_V.PROCID <>
                                                               99999)
                                                              --时间段
                                                           AND ((CPCWFPROC_V.ASTATIME >=
                                                               I_STARTTIME OR
                                                               I_STARTTIME IS NULL) AND
                                                               (CPCWFPROC_V.AENDTIME <=
                                                               I_ENDTIME OR
                                                               I_ENDTIME IS NULL))
                                                              --评审员
                                                           AND (CPCWFPROC_V.MANAGER =
                                                               I_USERID OR
                                                               I_USERID IS NULL))
                                                 WHERE STAT = 7
                                                   AND NVL(PERIOD, 0) <
                                                       NVL(HOUSE, 0)
                                                 GROUP BY USERID) DUAL
                                         WHERE DUAL.USERID = ANALYSIS.USERID);
  COMMIT;

  /*5.------------------------------------ 逾期未完成数量*/
  UPDATE CPC_WF_EFFICIENCY_ANALYSIS ANALYSIS
     SET (OVERTIMESUM) = (SELECT OVERTIMESUM
                            FROM (SELECT USERID, COUNT(1) OVERTIMESUM
                                    FROM (SELECT CPCWFPROC_V.MANAGER USERID,
                                                 CPCWFPROC_V.STAT,
                                                 ROUND(NVC_FUNC_GET_WORKING_DAY(TO_DATE(CPCWFPROC_V.ASTATIME,
                                                                                        'YYYY-MM-DD HH24:MI:SS'),
                                                                                TO_DATE(CPCWFPROC_V.AENDTIME,
                                                                                        'YYYY-MM-DD HH24:MI:SS')),
                                                       2) HOUSE,
                                                 CPCWFPROC.PERIOD
                                            FROM CPCWFPROC_V,
                                                 (SELECT CPCWF.WFID,
                                                         CPCWFPROCTEMP.PROCTEMPID,
                                                         CPCWFPROCTEMP.PERIOD
                                                    FROM CPCWF,
                                                         CPCWFPROCTEMP,
                                                         CPCWFTEMP
                                                   WHERE CPCWF.WFTEMPID =
                                                         CPCWFTEMP.WFTEMPID
                                                     AND CPCWFPROCTEMP.WFTEMPID =
                                                         CPCWFTEMP.WFTEMPID
                                                     AND (CPCWFPROCTEMP.PROCTEMPID <> 0 AND
                                                         CPCWFPROCTEMP.PROCTEMPID <>
                                                         99999)) CPCWFPROC
                                           WHERE CPCWFPROC_V.WFID =
                                                 CPCWFPROC.WFID
                                             AND CPCWFPROC_V.PROCID =
                                                 CPCWFPROC.PROCTEMPID
                                             AND (CPCWFPROC_V.PROCID <> 0 AND
                                                 CPCWFPROC_V.PROCID <> 99999)
                                                --时间段
                                             AND ((CPCWFPROC_V.ASTATIME >=
                                                 I_STARTTIME OR
                                                 I_STARTTIME IS NULL) AND
                                                 (CPCWFPROC_V.AENDTIME <=
                                                 I_ENDTIME OR
                                                 I_ENDTIME IS NULL))
                                                --评审员
                                             AND (CPCWFPROC_V.MANAGER =
                                                 I_USERID OR I_USERID IS NULL))
                                   WHERE STAT = 4
                                     AND NVL(PERIOD, 0) < NVL(HOUSE, 0)
                                   GROUP BY USERID) DUAL
                           WHERE DUAL.USERID = ANALYSIS.USERID);
  COMMIT;

  /*6.------------------------------------ 流程按时完成率*/
  UPDATE CPC_WF_EFFICIENCY_ANALYSIS ANALYSIS
     SET (OUTTIMEPARCENT) = (SELECT ROUND((PROCWFMINTIME / QTY), 2) OUTTIMEPARCENT
                               FROM (SELECT USERID, COUNT(1) QTY
                                       FROM (SELECT CPCWFPROC_V.MANAGER USERID,
                                                    CPCWFPROC_V.STAT
                                               FROM CPCWFPROC_V,
                                                    (SELECT CPCWF.WFID,
                                                            CPCWFPROCTEMP.PROCTEMPID,
                                                            CPCWFPROCTEMP.PERIOD
                                                       FROM CPCWF,
                                                            CPCWFPROCTEMP,
                                                            CPCWFTEMP
                                                      WHERE CPCWF.WFTEMPID =
                                                            CPCWFTEMP.WFTEMPID
                                                        AND CPCWFPROCTEMP.WFTEMPID =
                                                            CPCWFTEMP.WFTEMPID
                                                        AND (CPCWFPROCTEMP.PROCTEMPID <> 0 AND
                                                            CPCWFPROCTEMP.PROCTEMPID <>
                                                            99999)) CPCWFPROC
                                              WHERE CPCWFPROC_V.WFID =
                                                    CPCWFPROC.WFID
                                                AND CPCWFPROC_V.PROCID =
                                                    CPCWFPROC.PROCTEMPID
                                                AND (CPCWFPROC_V.PROCID <> 0 AND
                                                    CPCWFPROC_V.PROCID <>
                                                    99999)
                                                AND CPCWFPROC_V.MANAGER IS NOT NULL
                                                   --时间段
                                                AND ((CPCWFPROC_V.ASTATIME >=
                                                    I_STARTTIME OR
                                                    I_STARTTIME IS NULL) AND
                                                    (CPCWFPROC_V.AENDTIME <=
                                                    I_ENDTIME OR
                                                    I_ENDTIME IS NULL))
                                                   --评审员
                                                AND (CPCWFPROC_V.MANAGER =
                                                    I_USERID OR
                                                    I_USERID IS NULL))
                                      WHERE (STAT = 4 OR STAT = 7)
                                      GROUP BY USERID) DUAL
                              WHERE DUAL.USERID = ANALYSIS.USERID);
  COMMIT;
  --------------------------------------查询结果
  --SELECT * FROM CPC_WF_EFFICIENCY_ANALYSIS;

END;
/

