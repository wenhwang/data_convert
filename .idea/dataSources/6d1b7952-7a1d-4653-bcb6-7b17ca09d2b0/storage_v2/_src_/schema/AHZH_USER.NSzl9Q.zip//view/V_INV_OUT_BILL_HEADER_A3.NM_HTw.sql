create view V_INV_OUT_BILL_HEADER_A3 as
select h.organization_id, h.inv_out_bill_head_id, h.invbillno,h.customer_id ,c.customer_code,c.customer_name,h.billtypecode, h.auditing_date, h.note
	from inv_out_bill_head h,customer c
 where h.stat = 5
	 and h.is_auditing_wh = 2
	 and h.customer_id=c.customer_id(+)
/

