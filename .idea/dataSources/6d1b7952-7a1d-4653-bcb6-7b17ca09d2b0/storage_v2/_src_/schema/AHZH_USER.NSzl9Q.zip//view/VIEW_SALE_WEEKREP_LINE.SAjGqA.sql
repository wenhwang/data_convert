create view VIEW_SALE_WEEKREP_LINE as
select d.organization_id,
       d.weekrep_no,
       guider_id,
       guider_name,
       d.guider_code,
       d.terminal_name,
       d.terminal_code,
       d.dname,
       c.crm_entid,
       c.entorgid,
       c.spec,
       deduct_ratio,
       sum(sale_qty) sale_qty,
       sum(sale_qty * deduct_ratio) sale_amt,
       sum(sale_qty * nvl(deduct_ratio, 0)) deduct
  from mkt_itemclass_deduct    b,
       mkt_sale_weekrep_line   c,
       mkt_sale_weekrep_header d
 where c.spec = b.spec(+)
   and c.organization_id = b.organization_id(+)
   and c.weekrep_id = d.weekrep_id
   and d.stat = 5
   and d.organization_id = 61
   and period_type = 2
 group by d.organization_id,
          d.weekrep_no,
          guider_id,
          guider_name,
          d.guider_code,
          d.terminal_name,
          d.terminal_code,
          d.dname,
          c.crm_entid,
          c.entorgid,
          c.spec,
          deduct_ratio
/

