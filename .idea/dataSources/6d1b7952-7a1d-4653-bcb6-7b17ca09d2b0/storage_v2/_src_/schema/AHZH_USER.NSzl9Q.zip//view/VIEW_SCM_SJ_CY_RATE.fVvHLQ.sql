create view VIEW_SCM_SJ_CY_RATE as
Select Gl_Account_Subject_Id,
       Km_Code,
       Help_Code,
       Km_Name,
       Km_Type,
       Km_Property,
       Page_Type,
       Km_Level,
       g.Base_Currency_Id,
       b.Ismaster,
       e.Exch_Month,
       e.Exch_Rate
From   Gl_Account_Subject g,
       Base_Currency      b,
       Exchange_Rate      e
Where  g.Base_Currency_Id = b.Base_Currency_Id And
       b.Base_Currency_Id = e.Base_Currency_Id(+)
/

