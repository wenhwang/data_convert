create view ERPEMPLOYEE_BAK as
select a.sysuserid  as EMPLOYEE_ID,
       a.userid     as EMPLOYEE_CODE,
       a.username   as EMPLOYEE_NAME,
       a.Telo,
       a.Mobil,
       a.creator    as CREATED_BY,
       a.createtime as CREATION_DATE,
       b.orgid      as dept_id,
       a.actived
  from cpcuser a, cpcorguser b
 where a.sysuserid  = b.sysuserid (+)
  and b.isdefault(+)=2
/

