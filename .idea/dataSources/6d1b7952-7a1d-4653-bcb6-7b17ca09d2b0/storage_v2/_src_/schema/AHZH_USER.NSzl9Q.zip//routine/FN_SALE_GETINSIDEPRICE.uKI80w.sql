create Function           Fn_Sale_Getinsideprice(p_Item_Id              Number,
                                            p_Customer_Id          Number,
                                            p_Organization_Id      Number,
                                            P_Sa_Saleprice_Type_Id Number,
                                            p_Date                 Varchar2,
                                            p_is_team      Number default 1
                                            )
  Return Number Is
  Result Number;
  price  Number;
  count1 Number;

  /*
  获取物料销售价
  p_Item_Id  物料ID
  p_Customer_Id  客户ID
  p_Organization_Id  产品组织ID
  p_Date 日期
  */
Begin
  price  := 0;
  count1 := 0;
  select Count(*)
    into count1
    From Sa_Saleprice_Head Ssh, Sa_Saleprice_Line Ssl
   Where Ssh.Sa_Saleprice_Head_Id = Ssl.Sa_Saleprice_Head_Id
     And Ssh.Stat = 5
     And Ssl.Is_Cancellation = 1
     And Ssh.Organization_Id = p_Organization_Id
     And Nvl(Ssh.Customer_Id, 0) = p_Customer_Id
     --And ssl.Sa_Saleprice_Type_Id = P_Sa_Saleprice_Type_Id
     And ssh.Is_Sale_Promotion_Price = 2
     And Ssl.Item_Id = p_Item_Id
     And To_Date(p_Date, 'yyyy-mm-dd') Between
         Nvl(ssl.Start_Date, To_Date('1989-01-01', 'yyyy-mm-dd')) And
         Nvl(ssl.End_Date, To_Date('9999-12-31', 'yyyy-mm-dd'))
     And decode(nvl(Ssl.Is_Team,1),0,1,1,1,2,2)=p_is_team ;

  if (count1 is null) or (count1 = 0) Then
    Select Decode(ssl.inside_balance_price, null, 0, ssl.inside_balance_price)
      into price
      From Sa_Saleprice_Head Ssh, Sa_Saleprice_Line Ssl
     Where Ssh.Sa_Saleprice_Head_Id = Ssl.Sa_Saleprice_Head_Id
       And Ssh.Stat = 5
       And Ssl.Is_Cancellation = 1
       And Ssh.Organization_Id = p_Organization_Id
       And ssh.Is_Sale_Promotion_Price = 1
       And ssl.Sa_Saleprice_Type_Id = P_Sa_Saleprice_Type_Id
       And Ssl.Item_Id = p_Item_Id
       And To_Date(p_Date, 'yyyy-mm-dd') Between
           Nvl(ssl.Start_Date, To_Date('1989-01-01', 'yyyy-mm-dd')) And
           Nvl(ssl.End_Date, To_Date('9999-12-31', 'yyyy-mm-dd'))
      And decode(nvl(Ssl.Is_Team,1),0,1,1,1,2,2)=p_is_team
       and rownum = 1
     order By ssl.end_date ;
  Else
    Select Decode(ssl.inside_balance_price, null, 0, ssl.inside_balance_price)
      into price
      From Sa_Saleprice_Head Ssh, Sa_Saleprice_Line Ssl
     Where Ssh.Sa_Saleprice_Head_Id = Ssl.Sa_Saleprice_Head_Id
       And Ssh.Stat = 5
       And Ssl.Is_Cancellation = 1
       And Ssh.Organization_Id = p_Organization_Id
       And ssh.Customer_Id = p_Customer_Id
       And ssh.Is_Sale_Promotion_Price = 2
      -- And ssl.Sa_Saleprice_Type_Id = P_Sa_Saleprice_Type_Id
       And Ssl.Item_Id = p_Item_Id
       And To_Date(p_Date, 'yyyy-mm-dd') Between
           Nvl(ssl.Start_Date, To_Date('1989-01-01', 'yyyy-mm-dd')) And
           Nvl(ssl.End_Date, To_Date('9999-12-31', 'yyyy-mm-dd'))
       And decode(nvl(Ssl.Is_Team,1),0,1,1,1,2,2)=p_is_team
       and rownum = 1
     order By ssl.end_date ;
  end if;
  result := price;
  --end;
  -- end if;
  RETURN NVL(result, 0);
End Fn_Sale_Getinsideprice;
/

