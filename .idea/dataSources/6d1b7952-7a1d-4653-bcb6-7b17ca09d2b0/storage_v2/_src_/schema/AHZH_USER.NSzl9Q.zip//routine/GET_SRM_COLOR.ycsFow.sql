create Function           Get_Srm_Color(p_Srm_Po_Head_Id  Number,
                                         p_Organization_Id Number)
  Return Varchar2 Is
  Result    Varchar2(20);
  Is_Red    Number;
  Is_Yellow Number;
Begin
  Select Max(Nvl(Case
                   When Trunc(Sysdate) - Trunc(Spl.Polinedate) > 0 And
                        Spl.Qty_Ponofinish > 0 And Spl.Polinestatus = 6 And
                        (Select (Select Trunc(Sysdate) - Trunc(Spl.Polinedate) -
                                        To_Number(Sp.Param_Value)
                                   From Srm_Param Sp
                                  Where Sp.Param_Code = 'BILL_COLOR_YELLOW'
                                    And Sp.Organization_Id = p_Organization_Id)
                           From Dual) >= 0 Then
                    1
                   Else
                    0
                 End,
                 0)) Is_Yellow,
         Max(Nvl(Case
                   When Trunc(Sysdate) - Trunc(Spl.Polinedate) > 0 And
                        Spl.Qty_Ponofinish > 0 And Spl.Polinestatus = 6 And
                        (Select (Select Trunc(Sysdate) - Trunc(Spl.Polinedate) -
                                        To_Number(Sp.Param_Value)
                                   From Srm_Param Sp
                                  Where Sp.Param_Code = 'BILL_COLOR_RED'
                                    And Sp.Organization_Id = p_Organization_Id)
                           From Dual) >= 0 Then
                    1
                   Else
                    0
                 End,
                 0)) Is_Red
    Into Is_Yellow, Is_Red
    From Srm_Po_Line Spl
   Where Spl.Srm_Po_Head_Id = p_Srm_Po_Head_Id;
  Select Case
           When Is_Yellow > 0 And Is_Red > 0 Then
            'red'
           When Is_Yellow = 0 And Is_Red > 0 Then
            'red'
           When Is_Yellow > 0 And Is_Red = 0 Then
            'yellow'
           When Is_Yellow = 0 And Is_Red = 0 Then
            'white'
         End
    Into Result
    From Dual;
  Return(Result);
End Get_Srm_Color;
/

