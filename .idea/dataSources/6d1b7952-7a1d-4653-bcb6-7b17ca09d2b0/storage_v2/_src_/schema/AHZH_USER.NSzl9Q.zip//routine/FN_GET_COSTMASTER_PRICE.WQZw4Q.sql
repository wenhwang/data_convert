create Function Fn_Get_Costmaster_Price(p_Organization_Id Number,
                                                   p_Item_Id         In Number)
  Return Number Is
  Result Number;
Begin
  --取最后成本价
  Select Iisp.Price
    Into Result
    From Inv_Item_Stk_Price Iisp,
         (Select Isp.Item_Id, Max(Isp.Year_Month) Year_Month
            From Inv_Item_Stk_Price Isp
           Where Isp.Organization_Id = p_Organization_Id
             And Isp.Item_Id = p_Item_Id
           Group By Isp.Item_Id) t
   Where Iisp.Item_Id = t.Item_Id
     And Iisp.Year_Month = t.Year_Month
     And Iisp.Organization_Id = p_Organization_Id
     And Iisp.Item_Id = p_Item_Id;
  Return Nvl(Result, 0);
End Fn_Get_Costmaster_Price;
/

