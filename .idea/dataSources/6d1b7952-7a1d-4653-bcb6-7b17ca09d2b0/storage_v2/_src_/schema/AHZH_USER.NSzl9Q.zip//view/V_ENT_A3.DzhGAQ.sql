create view V_ENT_A3 as
select c.entid, c.entname, c.organization_id from cpcent c where c.isdisabled=1
/

