create procedure usp_fd_daycheckout(v_SET_OF_BOOKS_ID number,
                                               v_orgid           Number,
                                               vstrartMonth      varchar2, --开帐月份
                                               vvcurPeriodMonth  varchar2, --当前出纳轧账月份
                                               vvStrEDate        varchar2) --终止计算日记
 as
  vcurrClsPeriodMonth varchar2(7); --上次出纳轧账月份
  vENDPeriodMonth     varchar2(7); --最大业务月份
  vcurPeriodMonth     varchar2(7); --当前出纳轧账月份
  vStrSDate           DATE; --开始计算日期
  vStrEDate           DATE; --终止计算日记
  vStrPrevDate        DATE; --上一会计期间
begin

  -- vstrartMonth    := '2004-09';
  -- vcurPeriodMonth := '2007-11';
  --当前期间的第一天
  vcurPeriodMonth := vvcurPeriodMonth;
  vStrSDate       := TO_DATE(vcurPeriodMonth || '-01', 'YYYY-MM-DD');
  vStrEDate       := TO_DATE(substr(vvStrEDate, 1, 10), 'YYYY-MM-DD');
  vENDPeriodMonth := TO_CHAR(vStrEDate, 'YYYY-MM');

  if vStrEDate <
     to_date(to_char(to_date(vcurPeriodMonth || '-28', 'yyyy-mm-dd') + 4,
                     'yyyy-mm') || '-01',
             'yyyy-mm-dd') - 1 then
    vStrEDate := to_date(to_char(to_date(vcurPeriodMonth || '-28',
                                         'yyyy-mm-dd') + 4,
                                 'yyyy-mm') || '-01',
                         'yyyy-mm-dd') - 1;
  end if;

  --取上月份
  vcurrClsPeriodMonth := SUBSTR(TO_CHAR(TO_DATE(vcurPeriodMonth || '-01',
                                                'YYYY-MM-DD') - 1,
                                        'YYYY-MM-DD'),
                                1,
                                7);

  ---1、算日当前余额
  if vstrartMonth = vcurPeriodMonth then
    --把所有记录删除掉
    delete from FD_DATE_FUND_BALANCE
     Where SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
       And organization_id = v_orgid;
  else
    --删除大于等于当前期间的记录
    DELETE FROM FD_DATE_FUND_BALANCE
     WHERE SUBSTR(TO_CHAR(DATE_FUND, 'YYYY-MM-DD'), 1, 7) >=
           vcurPeriodMonth
       AND SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
       And organization_id = v_orgid;
  end if;

  --删除帐户启用日期大于等于当前月份的记录
  DELETE FROM FD_DATE_FUND_BALANCE
   WHERE FD_FUND_ACCOUNT_ID in
         (select FD_FUND_ACCOUNT_ID
            FROM FD_FUND_ACCOUNT A, GL_ACCOUNT_PERIOD B
           WHERE A.ORGANIZATION_ID = B.ORGANIZATION_ID
             AND B.year_month >= vcurPeriodMonth
             and A.DATE_STARTUSE between start_date and end_date
             and A.SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
             And a.organization_id = v_orgid);

  --插入启用日期大于等于当前月份的帐户的期初余额(i.e.上月的期末结余)
  Insert INTO FD_DATE_FUND_BALANCE
    (SET_OF_BOOKS_ID,
     organization_id,
     DATE_FUND,
     FD_FUND_ACCOUNT_ID,
     AMOUNT_BLNC)
    SELECT SET_OF_BOOKS_ID,
           organization_id,
           vStrSDate - 1,
           FD_FUND_ACCOUNT_ID,
           AMOUNT_LM
      FROM FD_FUND_ACCOUNT
     WHERE SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
       And organization_id = v_orgid
       and to_char(DATE_STARTUSE, 'yyyy-mm') >= vcurPeriodMonth;

  --插入发生额
  -- 现金、银行日记账
  INSERT INTO FD_DATE_FUND_BALANCE
    (Set_Of_Books_Id,
     organization_id,
     DATE_FUND,
     FD_FUND_ACCOUNT_ID,
     AMOUNT_LM,
     AMOUNT_IN,
     AMOUNT_OUT,
     AMOUNT_BLNC)
    SELECT Set_Of_Books_Id,
           organization_id,
           DATE_FUND,
           FD_FUND_ACCOUNT_ID,
           0,
           SUM(AMOUNT_DEBIT),
           SUM(AMOUNT_CREDIT),
           0
      FROM FD_FUND_BUSINESS
     WHERE YEAR_MONTH >= vcurPeriodMonth
       AND RECORD_TYPE = 0
          --And (nvl(is_ar_fund,0)<>2 Or nvl(is_ap_fund,0)<>2)
       AND SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
       And organization_id = v_orgid
       and IS_AUDITING = 2
     GROUP BY Set_Of_Books_Id,
              organization_id,
              DATE_FUND,
              FD_FUND_ACCOUNT_ID;

  -- 票据账户余额计算
  Insert Into Fd_Date_Fund_Balance
    (Set_Of_Books_Id,
     Organization_Id,
     Date_Fund,
     Fd_Fund_Account_Id,
     Amount_Lm,
     Amount_In,
     Amount_Out,
     Amount_Blnc)
    Select Set_Of_Books_Id,
           Organization_Id,
           Date_Fund,
           Fd_Fund_Account_Id,
           0 Amount_Lm,
           Sum(Amount_Debit) Amount_Debit,
           Sum(Amount_Credit) Amount_Credit,
           0 Amount_Blnc
      From ( /** 应收票据登记 */
            Select Set_Of_Books_Id,
                    Organization_Id,
                    Date_Fund,
                    Fd_Fund_Account_Id,
                    0 Amount_Lm,
                    Sum(Amount_Debit) Amount_Debit,
                    0 Amount_Credit,
                    0 Amount_Blnc
              From Fd_Fund_Business
             Where Year_Month >= vcurPeriodMonth
               And Record_Type = 1
               And Check_Property = 2
               And Organization_Id = v_orgid
               And Is_Auditing = 2
               And nvl(is_init_bill, 1) <> 2
               And fd_fund_account_id > 0 -- 应收票据 历史数据没有
             Group By Set_Of_Books_Id,
                       Organization_Id,
                       Date_Fund,
                       Fd_Fund_Account_Id
            Union All /** 应收票据日记账 */
            SELECT Set_Of_Books_Id,
                   organization_id,
                   DATE_FUND,
                   FD_FUND_ACCOUNT_ID,
                   0,
                   SUM(AMOUNT_DEBIT),
                   SUM(AMOUNT_CREDIT),
                   0
              FROM FD_FUND_BUSINESS
             WHERE YEAR_MONTH >= vcurPeriodMonth
               AND RECORD_TYPE = 7
               AND SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
               And organization_id = v_orgid
               and IS_AUDITING = 2
             GROUP BY Set_Of_Books_Id,
                      organization_id,
                      DATE_FUND,
                      FD_FUND_ACCOUNT_ID) tmp
     Group By Set_Of_Books_Id,
              Organization_Id,
              Date_Fund,
              Fd_Fund_Account_Id;

  -- 循环计算日资金余额
  WHILE vStrSDate <= vStrEDate LOOP
    VStrPrevDate := VStrSDate - 1;
    --更新已存在的日期的期初余额
    Update FD_DATE_FUND_BALANCE xx
       Set xx.Amount_LM = (SELECT a.AMOUNT_Blnc
                             From FD_DATE_FUND_BALANCE a
                            WHERE SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
                              And organization_id = v_orgid
                              and a.FD_FUND_ACCOUNT_ID =
                                  xx.FD_FUND_ACCOUNT_ID
                              and a.Date_Fund = VStrPrevDate)
     Where xx.Date_Fund = VStrSDate
       AND xx.SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
       And organization_id = v_orgid
       AND exists (select 'X'
              from FD_DATE_FUND_BALANCE a
             WHERE SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
               And organization_id = v_orgid
               and a.FD_FUND_ACCOUNT_ID = xx.FD_FUND_ACCOUNT_ID
               and a.Date_Fund = VStrPrevDate);
  
    --插入不存在日期的资金余额（延续前一天）
    INSERT INTO FD_DATE_FUND_BALANCE
      (Set_Of_Books_Id,
       organization_id,
       DATE_FUND,
       FD_FUND_ACCOUNT_ID,
       AMOUNT_LM,
       AMOUNT_IN,
       AMOUNT_OUT,
       AMOUNT_BLNC)
      Select a.Set_Of_Books_Id,
             a.organization_id,
             VStrSDate,
             a.FD_FUND_ACCOUNT_ID,
             a.Amount_Blnc,
             0,
             0,
             a.Amount_Blnc
        From FD_DATE_FUND_BALANCE a, FD_DATE_FUND_BALANCE b
       Where a.FD_FUND_ACCOUNT_ID = b.FD_FUND_ACCOUNT_ID(+)
         And a.Date_Fund = VStrPrevDate
         AND a.SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
         And a.organization_id = v_orgid
         And b.Date_Fund(+) = VStrSDate
         AND b.SET_OF_BOOKS_ID(+) = v_SET_OF_BOOKS_ID
         And b.organization_id(+) = v_orgid
         AND b.DATE_FUND is null;
    --commit;
    --更新期末余额
    Update FD_DATE_FUND_BALANCE
       Set Amount_Blnc = Amount_Lm + Amount_In - Amount_Out
     Where Date_Fund = VStrSDate
       AND SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
       And organization_id = v_orgid;
  
    --日期加1
    vStrSDate := VStrSDate + 1;
  END LOOP;

  --2、算资金月收发存表
  if vstrartMonth = vcurPeriodMonth then
    DELETE FROM FD_MONTH_BALANCE
     WHERE SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
       And organization_id = v_orgid;
  ELSE
    DELETE FROM FD_MONTH_BALANCE
     WHERE SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
       And organization_id = v_orgid
       AND YEAR_MONTH >= vcurPeriodMonth;
  END IF;

  --帐户启用日期大于等于当前月份的记录
  DELETE FROM FD_MONTH_BALANCE
   WHERE FD_FUND_ACCOUNT_ID in
         (select FD_FUND_ACCOUNT_ID
            from FD_FUND_ACCOUNT
           where to_char(DATE_STARTUSE, 'yyyy-mm') >= vcurPeriodMonth
             AND SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
             And organization_id = v_orgid);

  -- 循环计算资金月度收发存
  WHILE vcurPeriodMonth <= vENDPeriodMonth LOOP
  
    INSERT INTO FD_MONTH_BALANCE
      (Set_Of_Books_Id,
       organization_id,
       FD_FUND_ACCOUNT_ID,
       YEAR_MONTH,
       AMOUNT_LM,
       AMOUNT_IN,
       AMOUNT_OUT,
       AMOUNT_BLNC)
      Select set_of_books_id,
             organization_id,
             FD_FUND_ACCOUNT_ID,
             YEAR_MONTH,
             Sum(amount_lm) amount_lm,
             Sum(amount_in) amount_in,
             Sum(amount_out) amount_out,
             Sum(amount_lm + amount_in - amount_out) amount_blnc
        From ( /*-- 当月启动的帐户的初始化数据 */
              SELECT a.Set_Of_Books_Id,
                      a.organization_id,
                      a.FD_FUND_ACCOUNT_ID,
                      B.YEAR_MONTH,
                      a.AMOUNT_LM,
                      0 amount_in,
                      0 amount_out
                FROM FD_FUND_ACCOUNT A, GL_ACCOUNT_PERIOD B
               WHERE A.ORGANIZATION_ID = B.ORGANIZATION_ID
                 AND B.year_month = vcurPeriodMonth
                 and A.DATE_STARTUSE between start_date and end_date
                 and SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
                 And a.organization_id = v_orgid
              Union All /** 非当月初始化帐户的上月余额 */
              SELECT Set_Of_Books_Id,
                     organization_id,
                     FD_FUND_ACCOUNT_ID,
                     vcurPeriodMonth,
                     AMOUNT_BLNC amount_lm,
                     0 amount_in,
                     0 amount_out
                FROM FD_MONTH_BALANCE
               WHERE SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
                 And organization_id = v_orgid
                 AND YEAR_MONTH = vcurrClsPeriodMonth
              Union All /** 本月发生数 */
              SELECT Set_Of_Books_Id,
                     organization_id,
                     FD_FUND_ACCOUNT_ID,
                     vcurPeriodMonth YEAR_MONTH,
                     0 amount_lm,
                     Sum(amount_in) amount_in,
                     Sum(amount_out) amount_out
                FROM fd_date_fund_balance
               WHERE SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
                 And organization_id = v_orgid
                 AND to_char(date_fund, 'yyyy-mm') = vcurPeriodMonth
               Group By Set_Of_Books_Id, organization_id, FD_FUND_ACCOUNT_ID)
       Group By set_of_books_id,
                organization_id,
                FD_FUND_ACCOUNT_ID,
                YEAR_MONTH;
    --月份加1
    vcurrClsPeriodMonth := vcurPeriodMonth;
    vcurPeriodMonth     := TO_CHAR(TO_DATE(vcurPeriodMonth || '-28',
                                           'YYYY-MM-DD') + 4,
                                   'YYYY-MM');
  
  END LOOP;

  -- 加入更新会计期间的金额
  delete FD_CUR_PERIOD_FUND_BALANCE
   WHERE SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
     And organization_id = v_orgid;

  INSERT INTO FD_CUR_PERIOD_FUND_BALANCE
    (Set_Of_Books_Id, organization_id, FD_FUND_ACCOUNT_ID, AMOUNT_BLNC)
    Select Set_Of_Books_Id,
           organization_id,
           FD_FUND_ACCOUNT_ID,
           AMOUNT_BLNC
      from FD_MONTH_BALANCE
     where YEAR_MONTH = vcurPeriodMonth
       And organization_id = v_orgid
       AND SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID;

  -- 更新当前资金余额表
  delete FD_CUR_FUND_BALANCE
   WHERE SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
     And organization_id = v_orgid;

  INSERT INTO FD_CUR_FUND_BALANCE
    (Set_Of_Books_Id, ORGANIZATION_ID, FD_FUND_ACCOUNT_ID, AMOUNT_BLNC)
    Select Set_Of_Books_Id,
           ORGANIZATION_ID,
           FD_FUND_ACCOUNT_ID,
           AMOUNT_BLNC
      from FD_MONTH_BALANCE
     where YEAR_MONTH = vENDPeriodMonth
       AND SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
       And ORGANIZATION_ID = v_orgid;

  -- 应付票据日余额存储
  Delete From fd_date_payablebill_blnc
   Where SET_OF_BOOKS_ID = v_SET_OF_BOOKS_ID
     And Date_Sys = trunc(Sysdate)
     And organization_id = v_orgid;

  Insert Into Fd_Date_Payablebill_Blnc
    (Date_Sys,
     Fd_Fund_Business_Id,
     Set_Of_Books_Id,
     Organization_Id,
     Bill_No,
     Ordinal_No,
     Reference_No,
     Date_Fund,
     Year_Month,
     Fd_Fund_Account_Id,
     Fd_Fund_Bill_Type_Id,
     Docket,
     Attached_Remark,
     Exch_Rate,
     Base_Currency_Id,
     Amount_Debit,
     Amount_Credit,
     Base_Balance_Type_Id,
     Customer_Id,
     Vendor_Id,
     Employee_Id,
     Dept_Id,
     Is_Auditing,
     Auditing_By,
     Check_Type,
     Fd_Check_Status_Id,
     Date_Check,
     Date_Atterm,
     Amount_Assure,
     Fd_Fund_Bank_Id,
     Date_Dealwith,
     Object_Dealwith,
     Object_Divaricate,
     Note,
     Created_By,
     Creation_Date,
     Last_Updated_By,
     Last_Update_Date,
     Amount_Blnc,
     Is_Exp,
     Rate_Bail,
     Is_Red,
     Syscreate_Type,
     Fd_Fund_Account_Id_Re,
     Amount_Bill,
     Base_Ac_Object_Id,
     Crm_Entid,
     Entorgid,
     Bluered,
     Is_Rollback,
     p_Fd_Fund_Business_Id,
     Is_From_Unionbill,
     Fd_Fund_Biz_Union_Head_Id,
     Fd_Fund_Biz_Union_Line_Id,
     Check_Status,
     Fd_Fund_Biz_Union_Head_No,
     Fd_Io_Type_Id,
     Is_Init_Bill,
     Amount_Orgassure,
     Amount_Repay,
     Amount_Balance)
    Select Trunc(Sysdate) Date_Sys,
           Fd_Fund_Business_Id,
           Set_Of_Books_Id,
           Organization_Id,
           Bill_No,
           Ordinal_No,
           Reference_No,
           Date_Fund,
           Year_Month,
           Fd_Fund_Account_Id,
           Fd_Fund_Bill_Type_Id,
           Docket,
           Attached_Remark,
           Exch_Rate,
           Base_Currency_Id,
           Amount_Debit,
           Amount_Credit,
           Base_Balance_Type_Id,
           Customer_Id,
           Vendor_Id,
           Employee_Id,
           Dept_Id,
           Is_Auditing,
           Auditing_By,
           Check_Type,
           Fd_Check_Status_Id,
           Date_Check,
           Date_Atterm,
           Amount_Assure,
           Fd_Fund_Bank_Id,
           Date_Dealwith,
           Object_Dealwith,
           Object_Divaricate,
           Note,
           Created_By,
           Creation_Date,
           Last_Updated_By,
           Last_Update_Date,
           Amount_Blnc,
           Is_Exp,
           Rate_Bail,
           Is_Red,
           Syscreate_Type,
           Fd_Fund_Account_Id_Re,
           Amount_Bill,
           Base_Ac_Object_Id,
           Crm_Entid,
           Entorgid,
           Bluered,
           Is_Rollback,
           p_Fd_Fund_Business_Id,
           Is_From_Unionbill,
           Fd_Fund_Biz_Union_Head_Id,
           Fd_Fund_Biz_Union_Line_Id,
           Check_Status,
           Fd_Fund_Biz_Union_Head_No,
           Fd_Io_Type_Id,
           Is_Init_Bill,
           Amount_Orgassure,
           Amount_Repay,
           Amount_Blnc
      From Fd_Fund_Business Ffb
     Where Ffb.Organization_Id = v_orgid
       And Ffb.Record_Type = 1
       And Ffb.Check_Property = 1
       And Nvl(Ffb.Amount_Blnc, 0) <> 0;
end;
/

