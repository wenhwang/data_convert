create function           getclob(
                                   v_id       in varchar2,
                                   v_pos      in number) return varchar2 is
  lobloc    clob;
  buffer    varchar2(32767);
  amount    number := 2000;
  offset    number := 1;
  query_str varchar2(1000);
begin
  query_str := 'select content from t_news  where id = :id';
  EXECUTE IMMEDIATE query_str
    INTO lobloc
    USING v_id;
  offset := offset + (v_pos - 1) * 2000;
  dbms_lob.read(lobloc, amount, offset, buffer);
  return buffer;
exception
  when no_data_found then
    return buffer;
end;
/

