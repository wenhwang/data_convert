create view VIEW_DRP_ITEM_SPEC as
Select io.item_id,
       i.Item_Code,
       i.Item_Name,
       i.Item_Desc,
       i.uom_id,
       trim(Io.SPECS) SPEC,
       i.Old_Item_Code,
       i.Old_Item_Name,
       Ic1.Item_Class_Id   As SMALLC_Id,
       Ic1.Item_Class_Code As SMALLC_CODE,
       Ic1.Item_Class_Name As SMALLC_NAME,
       Ic2.Item_Class_ID   AS Bigc_ID,
       Ic2.Item_Class_Code As Bigc_Code,
       Ic2.Item_Class_Name As Bigc_Name,
       Ic3.Item_Class_Id   As SERIES_ID,
       Ic3.Item_Class_Code As SERIES_CODE,
       Ic3.Item_Class_Name As SERIES_NAME,
       Um.Uom_Code,
       Um.Uom_Name,
       IO.ORGANIZATION_ID,
       IO.ORGANIZATION_ID ENTID,
       2 USABLE,
       ic1.ITEM_TYPE_ID,-- CCS绯荤？涓？？浣跨？
       io.CRM_ENTID,
       io.ENTORGID
  From Item_Org Io,
       Item i,
       Uom Um,
       Item_Class Ic1,
       Item_Class Ic2,
       Item_Class Ic3/*,
       (
        select organization_id, min(io2.item_id) item_id
          from item_org io2
         where 1 = 1
           and io2.item_usable = 2 -- ？？？
           and io2.Item_Class2 > 0 -- 澶х被涓崭负绌?           and trim(nvl(io2.specs, '绌?)) <> '绌?
           and is_retail=2
         group by trim(io2.specs), organization_id
   )Io2*/
 Where /*Io.organization_id=Io2.organization_id
   and Io.item_id=Io2.item_id
   and */
   Io.Item_Id = i.Item_Id
   And i.Uom_Id = Um.Uom_Id(+)
   And Io.Item_Class1 = Ic1.Item_Class_Id(+)
   And Io.Item_Class2 = Ic2.Item_Class_Id(+)
   And Io.Item_Class3 = Ic3.Item_Class_Id(+)
   And Io.Specs is not null
   --added 2009.10.26
   and exists (select null from item_org io2
         where 1 = 1
           and io2.item_usable = 2 -- ？？？
           and io2.Item_Class2 > 0 -- 澶х被涓崭负绌?           and trim(nvl(io2.specs, '绌?)) <> '绌?
           and is_retail=2
           and io2.item_id = io.item_id
           and io2.organization_id = io.organization_id)
   and not exists (select null from item_org io3
         where 1 = 1
           and io3.item_usable = 2 -- ？？？
           and io3.Item_Class2 > 0 -- 澶х被涓崭负绌?           and trim(nvl(io3.specs, '绌?)) <> '绌?
           and is_retail=2
           and io3.item_id < io.item_id
           and io3.organization_id = io.organization_id
           and trim(io3.specs) = trim(io.specs))
/

