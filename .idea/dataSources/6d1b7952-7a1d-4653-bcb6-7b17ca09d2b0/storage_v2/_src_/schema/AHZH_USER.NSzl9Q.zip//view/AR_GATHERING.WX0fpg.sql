create view AR_GATHERING as
select fb.organization_id,
       fb.date_fund,
       fb.year_month,
       fb.Customer_Id,
       fb.Amount_Debit,
       fb.is_credence,
       gch.credence_no,
       fb.exch_rate,
       fb.docket,
       fb.Is_Prepay_Fund,
       fb.base_currency_id,
       fb.is_auditing,
       fb.amount_credit,
       fb.is_ar_fund,
       fb.note,
       fb.amount_cancel_ivc,
       fb.bill_no,
       fb.ordinal_no,
       fb.base_balance_type_id,
       fb.dept_id,
       fb.fd_fund_business_id,
       fb.sale_employee_id,
       fb.crm_entid,
       fb.entorgid
  from fd_fund_business fb,gl_credence_head gch
 Where fb.gl_credence_head_id = gch.gl_credence_head_id(+)
   and fb.is_ar_fund = 2
   And fb.record_type = 2
/

