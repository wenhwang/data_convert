create view VIEW_PAYINGVOUCHERDETAIL as
SELECT "PROJECT_CODE",
       "PROJECT_NAME",
       "ORDINAL_NO",
       "DATE_FUND",
       "PAYMENT_TYPE_NAME",
       "RECEIVER_NAME",
       "BALANCE_TYPE_NAME",
       "BUSINESS_TYPE_NAME",
       "FUND_ACCOUNT_NAME",
       "AMOUNT_CREDIT"
  FROM (SELECT PROJECT_CODE,
               PROJECT_NAME,
               ORDINAL_NO,
               DATE_FUND,
               DECODE(HEAD.PAYMENT_TYPE,
                      1,
                      '供应商',
                      2,
                      '业主/招标机构',
                      3,
                      '合伙人',
                      4,
                      '潜在客户',
                      5,
                      '个人') PAYMENT_TYPE_NAME,
               RECEIVER_NAME,
               BALANCE_TYPE_NAME,
               PAYMENT_TYPE_NAME BUSINESS_TYPE_NAME,
               FUND_ACCOUNT_NAME,
               AMOUNT_CREDIT
          FROM FIN_PAYING_VOUCHER HEAD,
               EPM_PROJECT,
               FD_FUND_ACCOUNT,
               FD_PAYMENT_TYPE,
               BASE_BALANCE_TYPE
         WHERE HEAD.PROJECT_ID = EPM_PROJECT.PROJECT_ID(+)
           AND HEAD.FD_FUND_ACCOUNT_ID =
               FD_FUND_ACCOUNT.FD_FUND_ACCOUNT_ID(+)
           AND HEAD.BUSINESS_TYPE = FD_PAYMENT_TYPE.FD_PAYMENT_TYPE_ID(+)
           AND HEAD.BASE_BALANCE_TYPE_ID =
               BASE_BALANCE_TYPE.BASE_BALANCE_TYPE_ID(+)
           AND HEAD.STAT = 5)
 WHERE 1 = 1
/*********************************************\
  * NAME(名称): VIEW_PAYINGVOUCHERDETAIL
  * PURPOSE(功能说明):  钉钉智能报表-项目付款明细
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-11-14
  \*********************************************/
/

