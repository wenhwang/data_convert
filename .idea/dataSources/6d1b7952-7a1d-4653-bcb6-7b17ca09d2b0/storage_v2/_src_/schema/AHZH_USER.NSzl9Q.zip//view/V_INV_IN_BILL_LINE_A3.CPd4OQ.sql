create view V_INV_IN_BILL_LINE_A3 as
select l.inv_in_bill_head_id, l.inv_in_bill_line_id,l.line_no, l.item_id, i.item_code, i.item_name, l.qty_match_total,
			 l.qty_invbill, l.warehouse_id, w.warehouse_code, w.warehouse_name
	from inv_in_bill_line l, item i, warehouse w
 where l.item_id = i.item_id
	 and l.warehouse_id = w.warehouse_id
	 and exists (select 1
					from inv_in_bill_head h
				 where h.inv_in_bill_head_id = l.inv_in_bill_head_id
					 and h.stat = 5
					 and h.is_auditing_wh = 2)
/

