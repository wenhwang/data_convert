create view VIEW_SA_OUT_BILL_HEAD_DX as
select sobh.Organization_Id,
       sobh.sa_salebillno,
       sobh.date_invbill,
       case
         when (select sp.param_value
                 from sys_param sp
                where sp.enterprise_id = sobh.Organization_Id
                  and sp.param_code = 'Is_Start_Old_Code_Report') = '2' then
          co.attribute2
         else
          c.Customer_Code
       end Customer_Code,
       case
         when (select sp.param_value
                 from sys_param sp
                where sp.enterprise_id = sobh.Organization_Id
                  and sp.param_code = 'Is_Start_Old_Code_Report') = '2' then
          co.attribute3
         else
          c.Customer_Name
       end Customer_Name,
       case
         when (select sp.param_value
                 from sys_param sp
                where sp.enterprise_id = sobh.Organization_Id
                  and sp.param_code = 'Is_Start_Old_Code_Report') = '2' then
          w.attribute11
         else
          w.Warehouse_Code
       end TmpWarehouse_Code,
       case
         when (select sp.param_value
                 from sys_param sp
                where sp.enterprise_id = sobh.Organization_Id
                  and sp.param_code = 'Is_Start_Old_Code_Report') = '2' then
          w.attribute21
         else
          w.Warehouse_Name
       end TmpWarehouse_Name,
       case
         when (select sp.param_value
                 from sys_param sp
                where sp.enterprise_id = sobh.Organization_Id
                  and sp.param_code = 'Is_Start_Old_Code_Report') = '2' then
          wd.attribute11
         else
          wd.Warehouse_Code
       end warehouse_code,
       case
         when (select sp.param_value
                 from sys_param sp
                where sp.enterprise_id = sobh.Organization_Id
                  and sp.param_code = 'Is_Start_Old_Code_Report') = '2' then
          wd.attribute21
         else
          wd.Warehouse_Name
       end warehouse_name,
       i.item_code,
       i.item_name,
       sobl.qty_bill,
       sobl.price_bill_f,
       sobl.amount_bill_f,
       sobh.address1,
       sobh.take_man,
       sobh.phone_code,
       sobh.mo_remark,
       dd.dictname   Crm_Entid
  from sa_out_bill_head sobh,
       sa_out_bill_line sobl,
       item i,
       customer c,
       customer_org co,
       warehouse w,
       warehouse wd,
       (select d.dictname, d.dictvalue, d.entid
          from cpcdict d
         where lower(d.dictcode) like 'crm_entid%') dd
 where sobh.sa_out_bill_head_id = sobl.sa_out_bill_head_id
   and sobl.item_id = i.item_id
   and sobh.customer_id = c.customer_id
   and sobh.Customer_Id = co.Customer_Id
   and sobh.warehouse_id = wd.warehouse_id
   and sobl.warehouse_id = w.warehouse_id
   and sobh.organization_id = wd.organization_id
   and sobh.organization_id = w.organization_id
   And sobh.Organization_Id = co.Organization_Id
   and sobh.crm_entid = dd.dictvalue(+)
   and sobh.organization_id = dd.entid(+)
   and sobh.bluered = 'B'
   and sobh.sale_type = 3
   and sobh.bill_type = 1
 order by sobh.sa_salebillno desc
/

