create view VIEW_PARTNER_CONTRACT_LIST as
SELECT SALE_COMPACT_NUM, --合同编号
       CONTRACT_TYPE, --合同类型
       CONTRACT_STATUS, --合同状态
       HEAD.CUSTOMER_ID, --合伙人
       CUSTOMER_CODE, --客户编码
       CUSTOMER_NAME, --客户名称
       DEPT_ID, --所属部门
       DEPT_CODE,
       DEPT_NAME,
       SALE_AREA_ID, --所属销售区域
       SALE_AREA_CODE,
       SALE_AREA_NAME,
       START_DATE, --起始日期
       END_DATE, --到期日期
       UNDERWRITE_DATE, --签订日期
       TOTAL_QTY, --免费商务服务数
       SIGNER, --签订人
       TOTAL_AMOUNT, --合同金额
       PAYMENT_NO, --回款单号
       PLAN_PAY_AMOUNT, --计划回款金额
       PLAN_PAY_TIME, --预计回款日期
       PAYMENT_STATUS, --回款状态
       PAY_TIME, --回款时间
       UN_PAYMENT_AMOUNT --未回款金额
  FROM VIEW_BCS_CUSTOMER       CUSTOMER,
       SA_KACONTRACT_BILL_LINE LINE,
       SA_KACONTRACT_BILL_HEAD HEAD
 WHERE HEAD.SA_KACONTRACT_BILL_HEAD_ID = LINE.SA_KACONTRACT_BILL_HEAD_ID
   AND HEAD.CUSTOMER_ID = CUSTOMER.CUSTOMER_ID(+)

/*********************************************\
  * NAME(名称): VIEW_PROJECT_BASE
  * PURPOSE(功能说明):  合伙人协议基本信息
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2019-07-17
  \*********************************************/
/

