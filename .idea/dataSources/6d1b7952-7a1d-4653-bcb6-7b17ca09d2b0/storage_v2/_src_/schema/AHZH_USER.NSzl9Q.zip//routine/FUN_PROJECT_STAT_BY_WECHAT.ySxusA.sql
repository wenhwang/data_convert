create FUNCTION FUN_PROJECT_STAT_BY_WECHAT(P_PROJECT_ID INTEGER --项目ID
                                                      )
  RETURN PROJECT_STAT_BY_WECHAT_TABLE
  PIPELINED IS
  RESULT PROJECT_STAT_BY_WECHAT_ROW; --定义RESULT为行对象类型

  V_STEP  INTEGER; --步骤
  V_STATE VARCHAR2(512); --状态

  V_COUNT INTEGER; --计数

  V_STAT           INTEGER; --单据状态
  V_CHECK_REMARK   VARCHAR2(16); --项目资格审核结果  
  V_REVIEW_RESULTS VARCHAR2(16); --招标文件解读审核结果
  V_IS_BID_WIN     INTEGER; --是否中标
  V_BILL_NO        VARCHAR2(16); --保证金转出单号
BEGIN

  --1.项目报备(未启动、已完成)------------------------------------------
  V_STEP  := 1;
  V_STATE := '项目报备[已完成]';
  V_COUNT := 0;
  --BEGIN
  SELECT COUNT(1)
    INTO V_COUNT
    FROM EPM_PROJECT HEAD
   WHERE HEAD.PROJECT_ID = P_PROJECT_ID;
  IF (V_COUNT = 0) THEN
    V_STATE := '项目报备[未启动]';
  END IF;

  RESULT := PROJECT_STAT_BY_WECHAT_ROW(V_STEP, V_STATE);
  PIPE ROW(RESULT);

  --2.资格审核 (未启动、已完成：通过 未通过, 1未启动 5 已完成)------------------------------------------
  V_STEP  := 2;
  V_STATE := '';
  BEGIN
    SELECT STAT, CHECK_REMARK
      INTO V_STAT, V_CHECK_REMARK
      FROM EPM_PROJECT HEAD
     WHERE HEAD.PROJECT_ID = P_PROJECT_ID;
  
    IF (V_STAT = 1) THEN
      V_STATE := '资格审核[未启动]';
    END IF;
  
    IF (V_STAT > 1 AND V_STAT <> 5) THEN
      V_STATE := '资格审核[已启动]';
    END IF;
  
    IF (V_STAT = 5) THEN
      V_STATE := '资格审核[已完成,审核结果:' || V_CHECK_REMARK || ']';
    END IF;
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_STATE := '资格审核[未启动]';
  END;

  RESULT := PROJECT_STAT_BY_WECHAT_ROW(V_STEP, V_STATE);
  PIPE ROW(RESULT);

  --3.项目报名(未启动、已完成) ------------------------------------------
  V_STEP  := 3;
  V_STATE := '项目报名[已完成]';
  V_COUNT := 0;

  SELECT COUNT(1)
    INTO V_COUNT
    FROM EPM_PROJECT_SIGNUP HEAD
   WHERE HEAD.PROJECT_ID = P_PROJECT_ID;
  IF (V_COUNT = 0) THEN
    V_STATE := '项目报名[未启动]';
  END IF;

  RESULT := PROJECT_STAT_BY_WECHAT_ROW(V_STEP, V_STATE);
  PIPE ROW(RESULT);

  --4.招标文件解读 (未启动、已完成:商务评审通过、技术评审通过) ------------------------------------------
  V_STEP           := 4;
  V_STATE          := '';
  V_REVIEW_RESULTS := '';
  --4.1商务评审 
  BEGIN
    SELECT HEAD.REVIEW_RESULTS
      INTO V_REVIEW_RESULTS
      FROM EPM_BUSINESS_REVIEW_HEAD HEAD
     WHERE HEAD.PROJECT_ID = P_PROJECT_ID;
    V_STATE := '商务评审:' || V_REVIEW_RESULTS;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_STATE := '商务评审:未启动';
  END;

  --4.2技术评审
  V_REVIEW_RESULTS := '';
  BEGIN
    SELECT HEAD.REVIEW_RESULTS
      INTO V_REVIEW_RESULTS
      FROM EPM_TECHNICAL_REVIEW_HEAD HEAD
     WHERE HEAD.PROJECT_ID = P_PROJECT_ID;
    V_STATE := V_STATE || ';技术评审:' || V_REVIEW_RESULTS;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_STATE := V_STATE || ';技术评审:未启动';
  END;

  V_STATE := '招标文件解读[' || V_STATE || ']';

  RESULT := PROJECT_STAT_BY_WECHAT_ROW(V_STEP, V_STATE);
  PIPE ROW(RESULT);

  --5.项目评审(未启动、已启动、已完成)  ------------------------------------------
  V_STEP  := 5;
  V_STATE := '';
  BEGIN
    SELECT HEAD.STAT
      INTO V_STAT
      FROM EPM_PROJECT_BID_HEAD HEAD
     WHERE HEAD.PROJECT_ID = P_PROJECT_ID;
  
    IF (V_STAT >= 1 AND V_STAT <> 5) THEN
      V_STATE := '项目评审[已启动]';
    END IF;
  
    IF (V_STAT = 5) THEN
      V_STATE := '项目评审[已完成]';
    END IF;
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_STATE := '项目评审[未启动]';
  END;

  RESULT := PROJECT_STAT_BY_WECHAT_ROW(V_STEP, V_STATE);
  PIPE ROW(RESULT);

  --6.项目报备(未启动、已完成)------------------------------------------
  V_STEP  := 6;
  V_STATE := '标书编制[已完成]';
  V_COUNT := 0;
  --BEGIN
  SELECT COUNT(1)
    INTO V_COUNT
    FROM EPM_MAKING_TENDER HEAD
   WHERE HEAD.PROJECT_ID = P_PROJECT_ID;
  IF (V_COUNT = 0) THEN
    V_STATE := '标书编制[未启动]';
  END IF;

  RESULT := PROJECT_STAT_BY_WECHAT_ROW(V_STEP, V_STATE);
  PIPE ROW(RESULT);

  --7.投标文件评审(未启动、已完成)   ------------------------------------------
  V_STEP  := 7;
  V_STATE := '';
  BEGIN
    SELECT HEAD.STAT
      INTO V_STAT
      FROM EPM_PROJECT_BID_REVIEW_HEAD HEAD
     WHERE HEAD.PROJECT_ID = P_PROJECT_ID;
  
    IF (V_STAT >= 1 AND V_STAT <> 5) THEN
      V_STATE := '投标文件评审[已启动]';
    END IF;
  
    IF (V_STAT = 5) THEN
      V_STATE := '投标文件评审[已完成]';
    END IF;
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_STATE := '投标文件评审[未启动]';
  END;

  RESULT := PROJECT_STAT_BY_WECHAT_ROW(V_STEP, V_STATE);
  PIPE ROW(RESULT);

  --8.封标核查 (未启动、已完成)  ------------------------------------------
  V_STEP  := 8;
  V_STATE := '封标核查[已完成]';
  V_COUNT := 0;
  SELECT COUNT(1)
    INTO V_COUNT
    FROM EPM_PROJECT_BID_SEALED HEAD
   WHERE HEAD.PROJECT_ID = P_PROJECT_ID;
  IF (V_COUNT = 0) THEN
    V_STATE := '封标核查[未启动]';
  END IF;

  RESULT := PROJECT_STAT_BY_WECHAT_ROW(V_STEP, V_STATE);
  PIPE ROW(RESULT);

  --9.现场开标(未启动、已完成)  ------------------------------------------
  V_STEP  := 9;
  V_STATE := '现场开标[已完成]';
  V_COUNT := 0;
  --BEGIN
  SELECT COUNT(1)
    INTO V_COUNT
    FROM EPM_PROJECT_BID_OPEN HEAD
   WHERE HEAD.PROJECT_ID = P_PROJECT_ID;
  IF (V_COUNT = 0) THEN
    V_STATE := '现场开标[未启动]';
  END IF;

  RESULT := PROJECT_STAT_BY_WECHAT_ROW(V_STEP, V_STATE);
  PIPE ROW(RESULT);

  --10.开标结果分析(未启动、已完成中标、未中标) 
  V_STEP       := 10;
  V_STATE      := '';
  V_IS_BID_WIN := 0;
  BEGIN
    SELECT NVL(HEAD.IS_BID_WIN, 0) IS_BID_WIN
      INTO V_IS_BID_WIN
      FROM EPM_PROJECT_BID_RESULT HEAD
     WHERE HEAD.PROJECT_ID = P_PROJECT_ID;
  
    IF (V_IS_BID_WIN = 2) THEN
      V_STATE := '开标结果分析[已中标]';
    END IF;
  
    IF (V_IS_BID_WIN = 1) THEN
      V_STATE := '开标结果分析[未中标]';
    END IF;
  
    IF (V_IS_BID_WIN = 0) THEN
      V_STATE := '开标结果分析[未启动]';
    END IF;
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_STATE := '开标结果分析[未启动]';
  END;

  RESULT := PROJECT_STAT_BY_WECHAT_ROW(V_STEP, V_STATE);
  PIPE ROW(RESULT);

  --11.付保证金(未启动、已启动、已支付)------------------------------------------
  V_STEP  := 11;
  V_STATE := '';
  V_STAT  := 0;
  BEGIN
    --11.1付保证金申请
    SELECT STAT, HEAD.BILL_NO
      INTO V_STAT, V_BILL_NO
      FROM EPM_PROJECT_MARGIN_APPLY HEAD
     WHERE HEAD.PROJECT_ID = P_PROJECT_ID;
  
    IF (V_STAT = 1) THEN
      V_STATE := '付保证金[未启动]';
    END IF;
  
    IF (V_STAT > 1 AND V_STAT <> 5) THEN
      V_STATE := '付保证金[已启动]';
    END IF;
  
    IF (V_STAT = 5) THEN
      V_STATE := '付保证金[已完成]';
    END IF;
  
    --11.2付保证金付款
    BEGIN
      V_STAT := 0;
      SELECT STAT
        INTO V_STAT
        FROM FIN_PAYING_VOUCHER HEAD
       WHERE HEAD.SYSCREATE_TYPE = 5
         AND HEAD.BILL_NO = V_BILL_NO;
    
      IF (V_STAT = 5) THEN
        V_STATE := '付保证金[已支付]';
      ELSE
        V_STATE := '付保证金[未支付]';
      END IF;
    
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_STATE := '付保证金[未支付]';
    END;
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_STATE := '付保证金[未启动]';
  END;

  RESULT := PROJECT_STAT_BY_WECHAT_ROW(V_STEP, V_STATE);
  PIPE ROW(RESULT);

  -- 返回数据
  RETURN;

END;

  /*********************************************\
  * NAME(名称): FUN_PROJECT_STAT_BY_WECHAT
  * PURPOSE(功能说明):  微信小程序查询项目状态
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-09-23
  \*********************************************/
/

