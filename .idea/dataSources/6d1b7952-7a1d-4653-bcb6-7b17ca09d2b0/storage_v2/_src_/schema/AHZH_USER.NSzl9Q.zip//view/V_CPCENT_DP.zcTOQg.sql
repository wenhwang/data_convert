create view V_CPCENT_DP as
select sh.entid, sh.entname from cpcent sh
/

