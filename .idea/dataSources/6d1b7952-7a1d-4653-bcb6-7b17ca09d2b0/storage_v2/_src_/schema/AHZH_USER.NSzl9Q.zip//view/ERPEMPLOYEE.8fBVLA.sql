create view ERPEMPLOYEE as
select a.sysuserid  as EMPLOYEE_ID,
       a.userid     as EMPLOYEE_CODE,
       a.username   as EMPLOYEE_NAME,
       a.Telo,
       a.Mobil,
       a.creator    as CREATED_BY,
       a.createtime as CREATION_DATE,
       0     as dept_id,
       a.actived
  from cpcuser a
 where 1  = 1
/

