create view V_CCS_BCS_RETURN as
    select iibh.organization_id,
       ct.entname,
       c.customer_id,
       c.customer_code,
       c.customer_name,
       i.item_code,
       i.item_name,
       w.warehouse_id,
       w.warehouse_code,
       w.warehouse_name,
       ib.billtypecode,
       ib.billtypename,
       iibh.invbilldate,
       iibh.creation_date,
       iibh.invbillno,
       iibl.qty_invbill
  from inv_in_bill_head iibh,
       inv_in_bill_line iibl,
       cpcent           ct,
       customer         c,
       item             i,
       warehouse        w,
       inv_billtype     ib
 where iibh.inv_in_bill_head_id = iibl.inv_in_bill_head_id
   and iibh.organization_id = ct.entid(+)
   and iibl.item_id = i.item_id(+)
   and iibl.warehouse_id = w.warehouse_id(+)
   and iibh.customer_id = c.customer_id(+)
   and iibh.billtypecode = ib.billtypecode(+)
   and iibh.billtypecode = '0206'
   and iibh.bluered = 'R'
   and iibh.stat = 5
   union all
select sobh.organization_id,
       ct.entname,
       c.customer_id,
       c.customer_code,
       c.customer_name,
       i.item_code,
       i.item_name,
       w.warehouse_id,
       w.warehouse_code,
       w.warehouse_name,
       '' billtypecode,
       '' billtypename,
       sobh.date_invbill invbilldate,
       sobh.creation_date,
       sobh.sa_salebillno invbillno,
       sobl.qty_bill qty_invbill
  from sa_out_bill_head sobh,
       sa_out_bill_line sobl,
       cpcent           ct,
       customer         c,
       item             i,
       warehouse        w
 where sobh.sa_out_bill_head_id = sobl.sa_out_bill_head_id
   and sobh.organization_id = ct.entid(+)
   and sobl.item_id = i.item_id(+)
   and sobl.warehouse_id = w.warehouse_id(+)
   and sobh.customer_id = c.customer_id(+)
   and sobh.bill_type = 2
   and sobh.sale_type = 3
   and sobh.stat = 5
/

