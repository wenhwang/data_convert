create view V_INV_IN_BILL_HEADER_A3 as
select h.organization_id organization_id, h.inv_in_bill_head_id, h.invbillno,h.customer_id,c.customer_code,c.customer_name,h.billtypecode, h.auditing_date, h.note,h.vendorbillno
	from inv_in_bill_head h,customer c
 where h.stat = 5
	 and h.is_auditing_wh = 2
	 and h.customer_id=c.customer_id(+)
/

