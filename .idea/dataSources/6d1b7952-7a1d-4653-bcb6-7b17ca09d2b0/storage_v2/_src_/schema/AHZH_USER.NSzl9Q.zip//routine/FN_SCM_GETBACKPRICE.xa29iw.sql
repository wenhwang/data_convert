create Function           Fn_Scm_Getbackprice(p_Item_Id         Number,
                                             p_Vendor_Id       Number,
                                             p_Organization_Id Number
                                             )
  Return Number Is
  Result Number;
  price  Number;
  --count1 Number;
 -- srm_purchase_price_id Number;
 -- max_qty Number;

  /*
  获取物料采购价
  p_Organization_Id  产品组织ID
  p_Item_Id  物料ID

  */
Begin
  price  := 0;


        --取最近采购价格
        select  nvl(b.price_potaxprice,0)
        into price
        from  srm_po_head a, srm_po_line b
        where a.srm_po_head_id=b.srm_po_head_id
        and a.stat=5
        and b.item_id=p_Item_Id
        and a.vendor_id=p_Vendor_Id
        and a.organization_id=p_Organization_Id
        and rownum = 1
        order by a.creation_date desc ;

      result := price;
      RETURN NVL(result, 0);
   -- end;

  --RETURN NVL(result, 0);
End Fn_Scm_Getbackprice;
/

