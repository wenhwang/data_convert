create FUNCTION FUN_EPM_GET_LOCK_AMOUNT(P_ORGANIZATION_ID IN NUMBER,
                                                   P_PROJECT_ID      IN NUMBER)
  RETURN NUMBER IS
  O_RESULT NUMBER;

  /*********************************************\
  * NAME(名称): FUN_EPM_GET_LOCK_AMOUNT
  * PURPOSE(功能说明):  获取项目冻结金额
  *PARAM(参数说明)：P_ORGANIZATION_ID 组织
                                 P_PROJECT_ID 项目ID
  
                                 O_RESULT 冻结金额
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2017-10-27
  \*********************************************/

BEGIN

  SELECT NVL(SUM(AMOUNT), 0)
    INTO O_RESULT
    FROM VIEW_PROJECT_LOACK_AMOUNT_LIST
   WHERE PROJECT_ID = P_PROJECT_ID;

  RETURN O_RESULT;

END;
/

