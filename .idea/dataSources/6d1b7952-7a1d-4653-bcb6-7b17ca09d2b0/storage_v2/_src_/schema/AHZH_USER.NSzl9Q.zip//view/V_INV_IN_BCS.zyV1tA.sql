create view V_INV_IN_BCS as
select iih.vendorbillno,
       sph.pono,
       iih.invbillno,
       c.customer_code,
       c.customer_name,
       sph.srm_po_head_id,
       ct.entname,
       ct.entid
  from inv_in_bill_head iih,
       inv_in_bill_line iil,
       srm_po_head      sph,
       customer         c,
       cpcent           ct
 where iih.inv_in_bill_head_id = iil.inv_in_bill_head_id
   and iih.organization_id = ct.entid
   and iil.srm_po_head_id = sph.srm_po_head_id(+)
   and sph.customer_id = c.customer_id(+)
   and iih.billtypecode = '0101'
   and iih.stat = 5
/

