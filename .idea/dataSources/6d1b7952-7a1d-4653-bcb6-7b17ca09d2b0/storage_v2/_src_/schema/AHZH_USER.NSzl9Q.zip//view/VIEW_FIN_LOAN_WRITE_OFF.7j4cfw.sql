create view VIEW_FIN_LOAN_WRITE_OFF as
SELECT LOAN_NO, NVL(SUM(BX_LINE.CX_AMT), 0) CX_AMT
  FROM FIN_FEE_BX_HEADER BX_HEAD,
       FIN_FEE_BX_LINE   BX_LINE,
       MKT_LOAN_HEADER   LOAN
 WHERE BX_HEAD.BX_ID = BX_LINE.BX_ID
   AND NVL(BX_HEAD.LOAN_ID, 0) <> 0
   AND BX_HEAD.LOAN_ID = LOAN.LOAN_ID(+)
 GROUP BY LOAN_NO

/*********************************************\
  * NAME(名称): VIEW_FIN_LOAN_WRITE_OFF
  * PURPOSE(功能说明):  借款冲销金额
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-07-21
  \*********************************************/
/

