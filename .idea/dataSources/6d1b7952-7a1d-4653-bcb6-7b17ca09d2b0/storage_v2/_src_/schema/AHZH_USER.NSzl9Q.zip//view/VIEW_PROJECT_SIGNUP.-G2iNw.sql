create view VIEW_PROJECT_SIGNUP as
SELECT PROJECT_ID, SIGNUP_TIME, SIGNUP_METHOD, SIGNUP_PEOPLE
  FROM EPM_PROJECT_SIGNUP

/*********************************************\
  * NAME(名称): VIEW_PROJECT_SIGNUP
  * PURPOSE(功能说明):  项目报名
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2019-07-18
  \*********************************************/
/

