create view VIEW_DINGTALK_BUSINESSDATA as
SELECT "SALE_AREA_NAME","AREA","SALES_NAME","PROJECT_CODE","PROJECT_NAME","PROJECT_TYPE_NAME","FUTURE_PRICES","PROJECT_STATUS","PARTNER","HOLDER","REPORT_TIME","IS_NOT_BID","SIGNUP_TIME","BID_SECURITY_END_DATE","BID_SECURITY","BID_ORG_NAME","BID_DOC_MAKER","BID_SEALED_TIME","BID_OPEN_TIME","IS_BID_WIN","BID_WINNER","BID_WIN_TIME","BID_WIN_AMOUNT","PUBLICITY_PM","PM_PUBLICITY_TIME","CONTRACT_SIGNUP_DATE","CONTRACT_AMOUNT","STARTUP_TIME"
          FROM (SELECT SALE_AREA_NAME,
                       AREA,
                       SALES_NAME,
                       PROJECT_CODE,
                       PROJECT_NAME,
                       PROJECT_TYPE_NAME,
                       FUTURE_PRICES,
                       PROJECT_STATUS,
                       PARTNER,
                       HOLDER,
                       REPORT_TIME,
                       IS_NOT_BID,
                       SIGNUP_TIME,
                       BID_SECURITY_END_DATE,
                       BID_SECURITY,
                       BID_ORG_NAME,
                       (SELECT BID_DOC_MAKER
                          FROM EPM_PROJECT_BID_REVIEW_HEAD BID_REVIEW
                         WHERE BID_REVIEW.PROJECT_ID = PROJECT.PROJECT_ID
                           AND ROWNUM = 1) BID_DOC_MAKER,
                       (SELECT BID_SEALED_TIME
                          FROM EPM_PROJECT_BID_SEALED BID_SEALED
                         WHERE BID_SEALED.PROJECT_ID = PROJECT.PROJECT_ID
                           AND ROWNUM = 1) BID_SEALED_TIME,
                       BID_OPEN_TIME,
                       IS_BID_WIN,
                       (SELECT BID_WINNER
                          FROM EPM_PROJECT_BID_RESULT BID_RESULT
                         WHERE BID_RESULT.PROJECT_ID = PROJECT.PROJECT_ID
                           AND ROWNUM = 1) BID_WINNER,
                       BID_WIN_TIME,
                       BID_WIN_AMOUNT,
                       PUBLICITY_PM,
                       PM_PUBLICITY_TIME,
                       CONTRACT_SIGNUP_DATE,
                       CONTRACT_AMOUNT,
                       (SELECT STARTUP_TIME
                          FROM EPM_PROJECT_STARTUP_HEAD BID_RESULT
                         WHERE BID_RESULT.PROJECT_ID = PROJECT.PROJECT_ID
                           AND ROWNUM = 1) STARTUP_TIME
                  FROM VIEW_BASE_PROJECT PROJECT,
                       (SELECT PROJECT_ID,
                               BID_SECURITY,
                               BID_SECURITY_END_DATE,
                               BID_ORG_NAME
                          FROM EPM_PROJECT_BID_HEAD
                         WHERE STAT = 5) BID
                 WHERE PROJECT.PROJECT_ID = BID.PROJECT_ID(+))
         WHERE 1 = 1
/*********************************************\
  * NAME(名称): VIEW_DINGTALK_BUSINESSDATASUMMARY
  * PURPOSE(功能说明):  钉钉智能报表-商务数据
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-11-14
  \*********************************************/
/

