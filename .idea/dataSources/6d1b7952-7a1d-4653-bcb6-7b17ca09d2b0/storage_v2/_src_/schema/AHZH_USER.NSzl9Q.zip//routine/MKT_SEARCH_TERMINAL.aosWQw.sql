create function           Mkt_Search_Terminal(Terminal_Code varchar2)
  return varchar2 is
  Result varchar2(256);

  sqls varchar2(1024);
begin
  sqls := 'select terminal_name ' || ' from mkt_terminal ' ||
          ' where terminal_code like ''' || '%' ||Terminal_Code || '%' || '''';

   execute immediate sqls
      into Result;

  --Result := Terminal_Code || ' : ' || sqls; --'绮や？？？？？靛？娼？？搴?;

  return nvl(Result, '链垒？板？镣');

end Mkt_Search_Terminal;
/

