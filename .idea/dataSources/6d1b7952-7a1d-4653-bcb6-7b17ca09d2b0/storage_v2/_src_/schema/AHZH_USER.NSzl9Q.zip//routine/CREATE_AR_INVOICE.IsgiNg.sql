create Procedure           Create_Ar_Invoice(p_Inv_Out_Bill_Head_Id Number,
                                              p_Organization_Id      Number,
                                              p_Invoice_Bill_No      Varchar2) Is
  t_Ar_Invoice_Head_Id Number;
  t_Ar_Invoice_Line_Id Number;
  t_Dept_Id            Number;
  t_Customer_Id        Number;
  t_Bank               Varchar2(192);
  t_Bank_No            Varchar2(96);
  t_NOTE               Varchar2(560);
  t_Base_Currency_Id   Number;
  t_Tax_Rate           Number;
  t_Exch_Rate          Number:=1;
  t_Date_Invbill       Date;
  t_Invoice_Line_No    Number := 0;
  t_Refer_No           Varchar2(45);
  t_Days_Gathering     Number := 0;---2010.02.02 王代来修改，增加一上预计收款日
  t_created_by         varchar2(45);
  t_last_updated_by    varchar2(45);
  t_is_cash_settlement Number;
  t_base_balance_type_id Number;
  t_fd_fund_account_id Number;
  t_crm_entid          Number;
  t_entorgid           Number;
  --出库表明细游标
  Cursor Invoutbillline Is
    Select nvl(Iobl.Sa_Out_Bill_Head_Id, 0) as Sa_Out_Bill_Head_Id,
           nvl(Iobl.Sa_Out_Bill_Line_Id, 0) as Sa_Out_Bill_Line_Id,
           nvl(Iobl.Inv_Out_Bill_Head_Id, 0) as Inv_Out_Bill_Head_Id,
           nvl(Iobl.Inv_Out_Bill_Line_Id, 0) as Inv_Out_Bill_Line_Id,
           Iobl.Item_Id,
           Iobl.Qty_Bill,
           --无销售订单出库Sa_Out_Bill_Line_Id=0,则取出库价格金额,否则取订单价格金额
           Sobl.Price_Bill_f,
           Sobl.Price_Bill_Notax_f,
           Iobl.Wtpricec_Bill_f,
           Iobl.remark
      From Inv_Out_Bill_Line Iobl, Sa_Out_Bill_Line Sobl
     Where Iobl.Sa_Out_Bill_Line_Id = Sobl.Sa_Out_Bill_Line_Id(+)
       And Iobl.Inv_Out_Bill_Head_Id = p_Inv_Out_Bill_Head_Id;
Begin
  --查询出库单表头数据
  Select Sq_Ar_Invoice_Head.Nextval,
         Iobh.Dept_Id,
         Iobh.Customer_Id,
         Co.Bank,
         Co.Bank_Accno,
         Co.Base_Currency_Id,
         Co.Tax_Rate,
         iobh.Note || iobh.Mo_Remark As Note,
         Iobh.Date_Invbill,
         Iobh.Invbillno,
         nvl(co.Days_Gathering,0) Days_Gathering,
         iobh.created_by,
         iobh.last_updated_by,
         iobh.is_cash_settlement,
         iobh.base_balance_type_id,
         iobh.fd_fund_account_id,
         iobh.crm_entid,
         iobh.entorgid
    Into t_Ar_Invoice_Head_Id,
         t_Dept_Id,
         t_Customer_Id,
         t_Bank,
         t_Bank_No,
         t_Base_Currency_Id,
         t_Tax_Rate,
         t_NOTE,
         t_Date_Invbill,
         t_Refer_No,
         t_Days_Gathering,
         t_created_by,
         t_last_updated_by,
         t_is_cash_settlement,
         t_base_balance_type_id,
         t_fd_fund_account_id,
         t_crm_entid,
         t_entorgid
    From Inv_Out_Bill_Head Iobh, Customer_Org Co
   Where Iobh.Customer_Id = Co.Customer_Id(+)
     And Co.Organization_Id(+) = p_Organization_Id
     And Iobh.Inv_Out_Bill_Head_Id = p_Inv_Out_Bill_Head_Id;
  --取汇率
/*  Select Nvl(Decode(Ismaster, 2, 1, Er.Exch_Rate), 0)
    Into t_Exch_Rate
    From Base_Currency Bc, Exchange_Rate Er
   Where Bc.Base_Currency_Id = Er.Base_Currency_Id(+)
     And Bc.Base_Currency_Id = t_Base_Currency_Id
     And Er.Exch_Month(+) = To_Char(t_Date_Invbill, 'YYYY-MM')
     And Rownum = 1;*/
  --插入表头
  Insert Into Ar_Invoice_Head
    (Organization_Id,
     Ar_Invoice_Head_Id,
     Invoice_Bill_No,
     Invoicet_Property,
     Invoice_Type,
     Bill_Type,
     Export_Trade_Type,
     Is_Auditing,
     Is_Credence,
     Dept_Id,
     Customer_Id,
     Bank,
     Bank_No,
     Base_Currency_Id,
     Tax_Rate,
     Exch_Rate,
     Date_Invoice,
     Date_Bill,
     Year_Month,
     NOTE,
     Refer_No,
     GATHERING_DATE,
     CREATED_BY,
     LAST_UPDATED_BY,
     is_cash_settlement,
     base_balance_type_id,
     fd_fund_account_id,
     crm_entid,
     entorgid,
     Sourcebilltype,
     sourcebillid)
  Values
    (p_Organization_Id,
     t_Ar_Invoice_Head_Id,
     p_Invoice_Bill_No,
     3,
     0,
     1,
     1,
     2,
     1,
     t_Dept_Id,
     t_Customer_Id,
     t_Bank,
     t_Bank_No,
     t_Base_Currency_Id,
     t_Tax_Rate,
     t_Exch_Rate,
     t_Date_Invbill,
     t_Date_Invbill,
     To_Char(t_Date_Invbill, 'YYYY-MM'),
     t_NOTE,
     t_Refer_No,
     t_Date_Invbill+t_Days_Gathering,
     t_created_by,
     t_last_updated_by,
     t_is_cash_settlement,
     t_base_balance_type_id,
     t_fd_fund_account_id,
     t_crm_entid,
     t_entorgid,
     1,
     p_Inv_Out_Bill_Head_Id);
  --Commit;
  --循环插入明细
  For Rec In Invoutbillline Loop
    Select Sq_Ar_Invoice_Line.Nextval Into t_Ar_Invoice_Line_Id From Dual;
    t_Invoice_Line_No := t_Invoice_Line_No + 1;
    Insert Into Ar_Invoice_Line
      (Ar_Invoice_Line_Id,
       Ar_Invoice_Head_Id,
       Invoice_Line_No,
       Sa_Out_Bill_Head_Id,
       Sa_Out_Bill_Line_Id,
       Inv_Out_Bill_Head_Id,
       Inv_Out_Bill_Line_Id,
       Item_Id,
       Qty_Bill,
       Price_Tax,
       Price_Notax,
       Amount_Notax,
       Amount_Tax,
       AMOUNT_BILL,
       Bill_Type_Match,
       note)
    Values
      (t_Ar_Invoice_Line_Id,
       t_Ar_Invoice_Head_Id,
       t_Invoice_Line_No,
       Rec.Sa_Out_Bill_Head_Id,
       Rec.Sa_Out_Bill_Line_Id,
       Rec.Inv_Out_Bill_Head_Id,
       Rec.Inv_Out_Bill_Line_Id,
       Rec.Item_Id,
       Rec.Qty_Bill,
       Rec.Wtpricec_Bill_f, --含税价
       (Rec.Wtpricec_Bill_f / (1 + t_Tax_Rate / 100.000000)), --未税价
       /*    round((Rec.Wtpricec_Bill_f / (1 + t_Tax_Rate / 100.000000)) * Rec.Qty_Bill,2), --货款
                     round(Rec.Wtpricec_Bill_f * Rec.Qty_Bill, 2)
                        - round(Rec.Wtpricec_Bill_f / (1 + t_Tax_Rate / 100.000000) * Rec.Qty_Bill, 2), --税额
                     1);*/
       round(round(Rec.Wtpricec_Bill_f * Rec.Qty_Bill, 2) -
             round(Rec.Wtpricec_Bill_f / (1 + t_Tax_Rate / 100.000000) *
                   (t_Tax_Rate / 100.000000) * Rec.Qty_Bill,
                   2),
             2), -- 货款 = 发票金额 - 税款
       round(Rec.Wtpricec_Bill_f / (1 + t_Tax_Rate / 100.000000) *
             (t_Tax_Rate / 100.000000) * Rec.Qty_Bill,
             2), --税额 = 发票金额 ÷1.17 ×0.17
       round(Rec.Wtpricec_Bill_f * Rec.Qty_Bill, 2), --发票金额
       1,
       Rec.remark);
    --更新出库单发票匹配数量金额
    Update Inv_Out_Bill_Line Iobl
       Set Iobl.Qty_Cancel_Invoice         = Iobl.Qty_Bill,
           Iobl.Qty_Match_Total            = Iobl.Qty_Bill,
           Iobl.Amount_Bnotax_f_Cl_Invoice = Iobl.Amount_Bill_Notax_f
     Where Iobl.Inv_Out_Bill_Line_Id = Rec.Inv_Out_Bill_Line_Id;
    --更新销售订单发票匹配数量金额
    --更新销售订单发票匹配数量金额
    --Modified By: Ding Hua 2009.6.25
    --Description: 订单可能多次出库，所以应该是追加
    Update Sa_Out_Bill_Line Sobl
       Set Sobl.Qty_Cancel_Invoice = Nvl(Sobl.Qty_Cancel_Invoice, 0) +
                                     Rec.Qty_Bill
     Where Sobl.Sa_Out_Bill_Line_Id = Rec.Sa_Out_Bill_Line_Id;
  End Loop;
  --Commit;
  --更新发票表头金额
  Update Ar_Invoice_Head Aih
     Set (Aih.Amount_Tax_f, Aih.Amount_Bill_f, Aih.Amount_Goods_f) = (Select Sum(Ail.Amount_Tax) Amount_Tax,
                                                                             Sum(Ail.Amount_Tax) +
                                                                             Sum(Ail.Amount_Notax) Amount_Notax,
                                                                             Sum(Ail.Amount_Notax) Amount_Goods_f
                                                                        From Ar_Invoice_Line Ail
                                                                       Where Ail.Ar_Invoice_Head_Id =
                                                                             Aih.Ar_Invoice_Head_Id)
   Where Aih.Ar_Invoice_Head_Id = t_Ar_Invoice_Head_Id;
 -- Commit;
  -- Modified By: DingHua 2010.4.7
  -- Description: 系统生成发票，出库单不用生成凭证，故更新为已生成凭证状态
  update inv_out_bill_head iobh
     set iobh.iscredence = 2,
         iobh.is_taocan_sale = 2,
         iobh.attribute3 = p_Invoice_Bill_No
   where iobh.inv_out_bill_head_id = p_Inv_Out_Bill_Head_Id;

   --关闭游标
   IF  Invoutbillline%ISOPEN THEN
       CLOSE Invoutbillline;
   END IF;

/*Exception
  When Others Then
    --关闭游标
    IF  Invoutbillline%ISOPEN THEN
       CLOSE Invoutbillline;
    END IF;

    Rollback;
    Raise_Application_Error(-20001, Sqlerrm);
  Raise_Application_Error(-20001, 'dhtest');*/
End Create_Ar_Invoice;
/

