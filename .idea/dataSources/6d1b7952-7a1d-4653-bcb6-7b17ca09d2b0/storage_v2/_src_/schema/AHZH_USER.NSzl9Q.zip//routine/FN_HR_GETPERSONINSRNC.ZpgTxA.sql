create Function           Fn_Hr_GetPersonInsrnc(
                              Insrnc_Type_Names varchar2,
                              year_month Varchar2,
                              organization_id Varchar2)
 Return varchar2 Is
  v_sql Varchar2(3000);
  v_Names Varchar2(300);
  /**
   * 绀句缭涓？汉缂寸撼棰?
   *
   * @Insrnc_Type_Ids: 绀句缭绫诲？IDs
   * @year_month: ？？？璁＄？链？唤
   * @organization_id:缁？？ID
   *
   *  瀛？？涓叉浔浠剁？ {}镟挎？''锛?
   *   eg: year_month = '2010-10'？？？ year_month = {2010-10}
   */
Begin
/*
  绀句缭涓？汉缂寸撼棰?
  ？？？？？链？？涓？？？朵腑update？椤？澶？溃

Update hr_count_salary_line t
   Set f_salary3 = nvl((Select sum(s.personal_money)
                      From hr_insrnc_month_sum s
                     Where s.employee_id = t.employee_id
                       And s.year_month = '2010-09'
                       And s.hr_insrnc_type_id In (2,3,1)
                       And s.organization_id = 40),0)
 Where hr_count_salary_head_id = 1
*/

 /** v_Names := replace(Insrnc_Type_Names,':',''','''); */
   v_Names := replace(Insrnc_Type_Names,':','},{');

  v_sql := 'nvl((select nvl(sum(s.personal_money),0)'
         ||' from hr_insrnc_month_sum s, hr_insrnc_type t'
         ||' where s.employee_id = t.employee_id'
         ||'   and s.hr_insrnc_type_id = t.hr_insrnc_type_id'
         ||'   and s.year_month = {'||year_month||'}'
         ||'   and t.insrnc_type_name In ({'||v_Names||'})'
         ||'   and s.organization_id = '||organization_id||'),0)';

  return v_sql;

End Fn_Hr_GetPersonInsrnc;
/

