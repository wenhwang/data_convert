create view VIEW_CUSTOMER_ORG_LIST as
select co."CUSTOMER_ORG_ID",co."ORGANIZATION_ID",co."CUSTOMER_ID",co."BASE_BALANCE_TYPE_ID",co."BASE_SALE_TYPE_ID",co."DEPT_ID",co."AREAID",co."CUSTOMER_TYPE",co."SHIPMODE_ID",co."SALE_EMPLOYEE_ID",co."WAREHOUSE_ID",co."RANK",co."IS_QD",co."ADDRESS",co."WEBSITE",co."EMAIL",co."LAW_MAN",co."FAX_LAW_MAN",co."TEL_HOME__LAW_MAN",co."TELE_LAW_MAN",co."TEL_MB_LAW_MAN",co."MANAGER",co."CONTACT",co."FAX",co."TEL_HOME_CONTACT",co."TELE",co."TEL_MB_CONTACT",co."CONTACT_FN",co."FAX_CONTACT_FN",co."TEL_HOME_CONTACT_FN",co."ACCOUNT_TELE",co."TEL_MB_CONTACT_FN",co."BASE_CURRENCY_ID",co."BANK",co."BANK_ACCNO",co."LIMIT_SHIP",co."USABLE",co."SALINVOICECANCELMODE",co."GL_ACCOUNT_SUBJECT_ID_YSZK",co."GL_ACCOUNT_SUBJECT_ID_ZYYSL",co."GL_ACCOUNT_SUBJECT_ID_QTYWSL",co."GL_ACCOUNT_SUBJECT_ID_ZYYWCB",co."GL_ACCOUNT_SUBJECT_ID_QTYWZC",co."GL_ACCOUNT_SUBJECT_ID_QTYS",co."GL_ACCOUNT_SUBJECT_ID_AR",co."TAX_RATE",co."TAX_NO",co."IS_RELATION",co."IN_OUT_SIDE_CLASS",co."SUBSCRIPTION_PROPORTION",co."CREBIT_CTRL",co."CREBIT_AMT",co."CUSTOMER_ORG_PID",co."CUSTOMER_ORG_IDPATH",co."IDPATH",co."STAT",co."WFID",co."WFFLAG",co."CREATED_BY",co."NOTE",co."CREATION_DATE",co."LAST_UPDATED_BY",co."LAST_UPDATE_DATE",co."ATTRIBUTE1",co."ATTRIBUTE2",co."ATTRIBUTE3",co."ATTRIBUTE4",co."ATTRIBUTE5",co."SA_SALEPRICE_TYPE_ID",co."SALEPRICE_TYPE_NAME1",co."SALE_TYPE",co."SALE_AREA_ID",co."SALE_AREA_CODE",co."SALE_AREA_NAME",co."AR_TYPE",co."CRM_CUST_ID",co."CRM_CUST_CODE",co."CRM_CUST_NAME",co."CRM_ENTID",co."IS_GROUPCUSTOMER",co."GROUP_CUSTOMER_ID",co."ENTORGIDS",co."DAYS_GATHERING",co."RESOURCE_TYPE",
       c.customer_code,
       c.customer_name,
       c.short_name,
       c.customer_name_en,
       bc.currency_code,
       bc.currency_name,
       a.areacode,
       a.areaname,
       bst.sale_type_code,
       bst.sale_type_name,
       s.shipmode_code,
       s.shipmode_name,
       e.EMPLOYEE_CODE,
       e.EMPLOYEE_NAME,
       d.dept_code,
       d.DEPT_NAME,
       w.warehouse_code,
       st.saleprice_type_code,
       st.saleprice_type_name,
       w.warehouse_name,
       b.balance_type_code,
       b.balance_type_name,
       yszk.km_code code_yszk,
       yszk.km_name name_yszk,
       zyysl.km_code code_zyysl,
       zyysl.km_name name_zyysl,
       qtywsl.km_code code_qtywsl,
       qtywsl.km_name name_qtywsl,
       zyywcb.km_code code_zyywcb,
       zyywcb.km_name name_zyywcb,
       qtywzc.km_code code_qtywzc,
       qtywzc.km_name name_qtywzc,
       qtys.km_code code_qtys,
       qtys.km_name name_qtys,
       ar.km_code code_ar,
       ar.km_name name_ar,
       Ca.Address1,
       Ca.Take_Man,
       Ca.Phone_Code,
       gp.customer_code Group_Customer_Code,
       gp.customer_name Group_Customer_Name
  from customer_org       co,
       customer           c,
       base_currency      bc,
       cpcarea            a,
       base_sale_type     bst,
       shipmode           s,
       sale_employee      se,
       erpemployee        e,
       dept               d,
       warehouse          w,
       Customer_Address   Ca,
       sa_saleprice_type  st,
       base_balance_type  b,
       gl_account_subject yszk,
       gl_account_subject zyysl,
       gl_account_subject qtywsl,
       gl_account_subject zyywcb,
       gl_account_subject qtywzc,
       gl_account_subject qtys,
       gl_account_subject ar,
       customer           gp
 where co.customer_id = c.customer_id(+)
   and co.base_currency_id = bc.base_currency_id(+)
   and co.sa_saleprice_type_id = st.sa_saleprice_type_id(+)
   and co.areaid = a.areaid(+)
   and Co.Customer_Id = Ca.Customer_Id(+)
--   and Ca.Defaulted(+) = 2
   and co.usable = 2
   and co.base_sale_type_id = bst.base_sale_type_id(+)
   and co.shipmode_id = s.shipmode_id(+)
   and co.sale_employee_id = se.sale_employee_id(+)
   and se.employee_id = e.EMPLOYEE_ID(+)
   and co.dept_id = d.dept_id(+)
   and co.warehouse_id = w.warehouse_id(+)
   and co.Group_Customer_Id = gp.customer_id(+)
   and co.base_balance_type_id = b.base_balance_type_id(+)
   and co.gl_account_subject_id_yszk = yszk.gl_account_subject_id(+)
   and co.gl_account_subject_id_zyysl = zyysl.gl_account_subject_id(+)
   and co.gl_account_subject_id_qtywsl = qtywsl.gl_account_subject_id(+)
   and co.gl_account_subject_id_zyywcb = zyywcb.gl_account_subject_id(+)
   and co.gl_account_subject_id_qtywzc = qtywzc.gl_account_subject_id(+)
   and co.gl_account_subject_id_qtys = qtys.gl_account_subject_id(+)
   and co.gl_account_subject_id_ar = ar.gl_account_subject_id(+)
 order by c.customer_code
/

