create view V_KNOWL as
select FDRNAME,knowlid as bbsid, SUBJECT,CONTENT, CREATOR,CREATETIME,UPDATOR,UPDATETIME
  from (select fdr.fdrname,
               knowlid,
               subject,
               content,
               creator,
               createtime,
               updator,
               updatetime
          from knowl,
               (select cpcfdrref.refid, cpcfdr.fdrname
                  from cpcfdrref, cpcfdr
                 where cpcfdrref.fdrid = cpcfdr.fdrid
                   and reftype = 82) fdr
         where knowlid = fdr.refid)
/

