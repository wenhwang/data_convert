create Procedure           Usp_Inv_Periodcheck(Int_Organization_Id       Number,
                                                p_Date_Invbill_Begin      varchar2,
                                                p_Date_Invbill_End        varchar2,
                                                p_warehouse_id            number,
                                                TmpTab_Inv_DatePeriodSum  varchar2,
                                                TmpTab_Inv_DatePeriodSum2 varchar2,
                                                TmpTab_Item               varchar2) As

  --？╂？链？？？跺？瀛？〃
  --xuji
  --2009.03.26

  Str_Sql      Varchar2(10000);
  Str_Premonth Varchar2(10); --？？？涓？？浠?
Begin
  --？？？涓？？浠?
  Select To_Char(add_months(To_Date(p_Date_Invbill_Begin, 'yyyy-mm-dd'), -1),
                 'yyyy-mm')
    Into Str_Premonth
    From Dual;
  --銮峰？涓娄釜链？？瀛？？
  Str_Sql := 'insert into ' || TmpTab_Inv_DatePeriodSum ||
             '  (organization_id,' || '   item_id,' || '   warehouse_id,' ||
             '   Qty_Lm,' || '   PRICE,' || '   AMOUNT_LM,' ||
             '   PRICE_BLNC,' || '   PRICE_IN,' ||
             '   PRICE_Out,QTY_IN,AMOUNT_IN,QTY_OUT,AMOUNT_OUT,QTY_BLNC,AMOUNT_BLNC)' ||
             '  select m.organization_id,' || '         m.item_id,' ||
             '         m.warehouse_id,' ||
             '         sum(m.qty_blnc) as qty_lm,' ||
             '         m.price_blnc as Price_Lm,' ||
             '         sum(m.amount_blnc) as AMOUNT_LM,' ||
             '         m.price_blnc as PRICE_BLNC,' ||
             '         m.price_blnc as PRICE_IN,' ||
             '         m.price_blnc as PRICE_Out,0,0,0,0,0,0' ||
             '    from inv_monthsum m' || '   where m.organization_id = ' ||
             to_char(Int_Organization_Id) || '     and m.year_month = ''' ||
             Str_Premonth || '''';
  if (p_warehouse_id > 0) then
    Str_Sql := Str_Sql || ' and warehouse_id=' || to_char(p_warehouse_id);
  end if;
  if (length(trim(TmpTab_Item)) > 0) then
    Str_Sql := Str_Sql || ' and m.item_id in (select t.item_id from ' ||
               TmpTab_Item || ' t)';
  end if;
  Str_Sql := Str_Sql ||
             '   group by m.organization_id, m.item_id, m.warehouse_id, m.price_blnc';
  Execute Immediate Str_Sql;

  --銮峰？涓？？？ㄤ复镞惰〃涓？？？村？搴？？瀛？？
  Str_Sql := 'insert into ' || TmpTab_Inv_DatePeriodSum ||
             '  (organization_id, item_id, warehouse_id, qty_in)' ||
             '  select h.organization_id,' || '         l.item_id,' ||
             '         l.warehouse_id,' ||
             '         sum(l.qty_invbill) as qty_in' ||
             '    from inv_in_bill_head h, inv_in_bill_line l' ||
             '   where h.inv_in_bill_head_id = l.inv_in_bill_head_id' ||
             '     and h.organization_id = ' ||
             to_char(Int_Organization_Id) ||
             '     and h.is_auditing_wh = 2' ||
             '     and h.invbilldate between to_date(''' ||
             p_Date_Invbill_Begin || ''', ''yyyy-mm-dd'') and' ||
             '         to_date(''' || p_Date_Invbill_End ||
             ''', ''yyyy-mm-dd'')' || '     and not exists (select * from ' ||
             TmpTab_Inv_DatePeriodSum || ')';
  if (p_warehouse_id > 0) then
    Str_Sql := Str_Sql || ' and l.warehouse_id=' || to_char(p_warehouse_id);
  end if;
  if (length(trim(TmpTab_Item)) > 0) then
    Str_Sql := Str_Sql || ' and l.item_id in (select t.item_id from ' ||
               TmpTab_Item || ' t)';
  end if;
  Str_Sql := Str_Sql ||
             '   group by h.organization_id, l.item_id, l.warehouse_id';
  Execute Immediate Str_Sql;

  --瀵煎？涓？？？ㄥ？搴？？瀛？？镊崇？浜？复镞惰〃
  Str_Sql := 'insert into ' || TmpTab_Inv_DatePeriodSum2 ||
             '  (organization_id, item_id, warehouse_id, qty)' ||
             '  select h.organization_id,' || '         l.item_id,' ||
             '         l.warehouse_id,' ||
             '         sum(l.qty_invbill) as qty' ||
             '    from inv_in_bill_head h, inv_in_bill_line l' ||
             '   where h.inv_in_bill_head_id = l.inv_in_bill_head_id' ||
             '     and h.organization_id = ' ||
             to_char(Int_Organization_Id) ||
             '     and h.is_auditing_wh = 2' ||
             '     and h.invbilldate between to_date(''' ||
             p_Date_Invbill_Begin || ''', ''yyyy-mm-dd'') and' ||
             '         to_date(''' || p_Date_Invbill_End ||
             ''', ''yyyy-mm-dd'')' || '     and exists (select * from ' ||
             TmpTab_Inv_DatePeriodSum || ')';
  if (p_warehouse_id > 0) then
    Str_Sql := Str_Sql || ' and l.warehouse_id=' || to_char(p_warehouse_id);
  end if;
  if (length(trim(TmpTab_Item)) > 0) then
    Str_Sql := Str_Sql || ' and l.item_id in (select t.item_id from ' ||
               TmpTab_Item || ' t)';
  end if;
  Str_Sql := Str_Sql ||
             '   group by h.organization_id, l.item_id, l.warehouse_id';

  Execute Immediate Str_Sql;

  --镟存？涓讳复镞惰〃？ュ？缁揿？？?
  Str_Sql := 'update ' || TmpTab_Inv_DatePeriodSum || ' s' ||
             '   set qty_in = (select qty' || '                   from ' ||
             TmpTab_Inv_DatePeriodSum2 || ' s2' ||
             '                  where s.item_id = s2.item_id' ||
             '                    and s.organization_id = s2.organization_id' ||
             '                    and s.warehouse_id = s2.warehouse_id)' ||
             ' where s.organization_id = ' || to_char(Int_Organization_Id);

  Execute Immediate Str_Sql;

  --銮峰？涓？？？ㄤ复镞惰〃涓？？？村？搴？？瀛？？
  Str_Sql := 'insert into ' || TmpTab_Inv_DatePeriodSum ||
             '  (organization_id, item_id, warehouse_id, qty_out)' ||
             '  select h.organization_id,' || '         l.item_id,' ||
             '         l.warehouse_id,' ||
             '         sum(l.qty_bill) as qty_out' ||
             '    from inv_out_bill_head h, inv_out_bill_line l' ||
             '   where h.inv_out_bill_head_id = l.inv_out_bill_head_id' ||
             '     and h.organization_id = ' ||
             to_char(Int_Organization_Id) ||
             '     and h.is_auditing_wh = 2' ||
             '     and h.date_invbill between to_date(''' ||
             p_Date_Invbill_Begin || ''', ''yyyy-mm-dd'') and' ||
             '         to_date(''' || p_Date_Invbill_End ||
             ''', ''yyyy-mm-dd'')' || '     and not exists (select * from ' ||
             TmpTab_Inv_DatePeriodSum || ')';
  if (p_warehouse_id > 0) then
    Str_Sql := Str_Sql || ' and l.warehouse_id=' || to_char(p_warehouse_id);
  end if;
  if (length(trim(TmpTab_Item)) > 0) then
    Str_Sql := Str_Sql || ' and l.item_id in (select t.item_id from ' ||
               TmpTab_Item || ' t)';
  end if;
  Str_Sql := Str_Sql ||
             '   group by h.organization_id, l.item_id, l.warehouse_id';
  Execute Immediate Str_Sql;

  Str_Sql := 'Delete From ' || TmpTab_Inv_DatePeriodSum2;
  Execute Immediate Str_Sql;

  --瀵煎？涓？？？ㄥ？搴？？瀛？？镊崇？浜？复镞惰〃
  Str_Sql := 'insert into ' || TmpTab_Inv_DatePeriodSum2 ||
             '  (organization_id, item_id, warehouse_id, qty)' ||
             '  select h.organization_id,' || '         l.item_id,' ||
             '         l.warehouse_id,' ||
             '         sum(l.qty_bill) as qty' ||
             '    from inv_out_bill_head h, inv_out_bill_line l' ||
             '   where h.inv_out_bill_head_id = l.inv_out_bill_head_id' ||
             '     and h.organization_id = ' ||
             to_char(Int_Organization_Id) ||
             '     and h.is_auditing_wh = 2' ||
             '     and h.date_invbill between to_date(''' ||
             p_Date_Invbill_Begin || ''', ''yyyy-mm-dd'') and' ||
             '         to_date(''' || p_Date_Invbill_End ||
             ''', ''yyyy-mm-dd'')' || '     and exists (select * from ' ||
             TmpTab_Inv_DatePeriodSum || ')';
  if (p_warehouse_id > 0) then
    Str_Sql := Str_Sql || ' and l.warehouse_id=' || to_char(p_warehouse_id);
  end if;
  if (length(trim(TmpTab_Item)) > 0) then
    Str_Sql := Str_Sql || ' and l.item_id in (select t.item_id from ' ||
               TmpTab_Item || ' t)';
  end if;
  Str_Sql := Str_Sql ||
             '   group by h.organization_id, l.item_id, l.warehouse_id';

  Execute Immediate Str_Sql;

  --镟存？涓讳复镞惰〃？哄？缁揿？？?
  Str_Sql := 'update ' || TmpTab_Inv_DatePeriodSum || ' s' ||
             '   set qty_out = (select qty' || '                   from ' ||
             TmpTab_Inv_DatePeriodSum2 || ' s2' ||
             '                  where s.item_id = s2.item_id' ||
             '                    and s.organization_id = s2.organization_id' ||
             '                    and s.warehouse_id = s2.warehouse_id)' ||
             ' where s.organization_id = ' || to_char(Int_Organization_Id);

  Execute Immediate Str_Sql;

  --镟存？？╂？\浠揿？\？？？？寸？瀛？？绛？俊？?
  Str_Sql := 'update ' || TmpTab_Inv_DatePeriodSum || ' m' ||
             '   set (          m.item_code, m.item_name, m.uom_id, m.uom_name, m.item_class_id, m.item_class_code, m.item_class_name) = (select i.item_code,' ||
             '                                                                                                                                   i.item_name,' ||
             '                                                                                                                                   i.uom_id,' ||
             '                                                                                                                                   u.uom_name,' ||
             '                                                                                                                                   ic.item_class_id,' ||
             '                                                                                                                                   ic.item_class_code,' ||
             '                                                                                                                                   ic.item_class_name' ||
             '                                                                                                                              from item_org   io,' ||
             '                                                                                                                                   item       i,' ||
             '                                                                                                                                   item_class ic,' ||
             '                                                                                                                                   uom        u' ||
             '                                                                                                                             where io.organization_id =' ||
             '                                                                                                                                   m.organization_id' ||
             '                                                                                                                               and io.item_id =' ||
             '                                                                                                                                   i.item_id' ||
             '                                                                                                                               and i.uom_id =' ||
             '                                                                                                                                   u.uom_id(+)' ||
             '                                                                                                                               and io.item_class1 =' ||
             '                                                                                                                                   ic.item_class_id(+)' ||
             '                                                                                                                               and io.item_id =' ||
             '                                                                                                                                   m.item_id),' ||
             '       (          m.warehouse_code, m.warehouse_name) = (select w.warehouse_code,' ||
             '                                                                w.warehouse_name' ||
             '                                                           from warehouse w' ||
             '                                                          where m.warehouse_id =' ||
             '                                                                w.warehouse_id' ||
             '                                                            and m.organization_id =' ||
             '                                                                w.organization_id),' ||
             '       AMOUNT_IN   = nvl(QTY_IN, 0) * nvl(PRICE_IN, 0),' ||
             '       AMOUNT_out  = nvl(QTY_out, 0) * nvl(PRICE_out, 0),' ||
             '       QTY_BLNC    = (nvl(QTY_LM, 0) + nvl(QTY_IN, 0) - nvl(QTY_OUT, 0)),' ||
             '       AMOUNT_BLNC = (nvl(amount_LM, 0) + nvl(QTY_IN, 0)*nvl(PRICE_BLNC, 0) - nvl(QTY_OUT, 0) *' ||
             '                     nvl(PRICE_BLNC, 0))' || '' ||
             ' where m.organization_id = ' || to_char(Int_Organization_Id);
  Execute Immediate Str_Sql;
  Commit;

End Usp_Inv_Periodcheck;
/

