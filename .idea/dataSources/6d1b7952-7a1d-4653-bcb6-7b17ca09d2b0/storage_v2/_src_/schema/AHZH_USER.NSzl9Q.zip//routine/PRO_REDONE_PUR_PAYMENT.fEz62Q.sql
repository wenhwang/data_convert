create PROCEDURE PRO_REDONE_PUR_PAYMENT AS
  /*********************************************\
  * NAME(名称): PRO_REDONE_PUR_PAYMENT
  * PURPOSE(功能说明):  以付款单为基准更新采购付款单中本次已付款金额、是否结案
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2017-11-29
  \*********************************************/
BEGIN

  UPDATE PUR_PAYMENT_APPLY_HEAD HEAD
     SET HEAD.PAID_AMOUNT = (SELECT AMOUNT_CREDIT
                               FROM (SELECT SALEORDER_NO BILL_NO,
                                            NVL(SUM(AMOUNT_CREDIT), 0) AMOUNT_CREDIT
                                       FROM FD_FUND_BUSINESS
                                      WHERE SALEORDER_NO IS NOT NULL
                                        AND SYSCREATE_TYPE = 3 --3|采购付款申请
                                        AND STAT = 5 --已审核
                                        AND IS_AP_FUND = 2 --是否销售回款
                                        AND RECORD_TYPE = 3
                                      GROUP BY SALEORDER_NO)
                              WHERE APPLY_NO  = BILL_NO),
         IS_CLOSED        = 2 --单次付款
   WHERE EXISTS (SELECT 1
            FROM (SELECT SALEORDER_NO BILL_NO
                    FROM FD_FUND_BUSINESS
                   WHERE SALEORDER_NO IS NOT NULL
                     AND SYSCREATE_TYPE = 3 --3|采购付款申请
                     AND STAT = 5 --已审核
                     AND IS_AP_FUND = 2 --是否销售回款
                     AND RECORD_TYPE = 3 --回款
                  )
           WHERE APPLY_NO = BILL_NO);

  COMMIT;
END;
/

