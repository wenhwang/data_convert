create Function           Fn_Onhand_Qty(p_Organization_Id Number,
                                         p_Item_Id         In Number,
                                         P_warehouse_type    In Number,
                                         p_WAREHOUSE_ID    In Number,
                                         p_Inv_Batch_Id    In Number,
                                         p_Warehouse_Property  In Number:=0)
  Return Number Is
  Result       Number;
  Sqlwhere     Varchar(600);
  Cur_Ap       Integer;
  Num_Ap       Integer;
  l_QTY_ONHAND inv_current_inv.QTY_ONHAND%Type;
  /*

  /*
  获取物料正式入库库存或待检库存
  p_Organization_Id  产品组织ID
  p_Item_Id  物料ID
  P_warehouse_type 库存类型  =1 表示正式入库库存,2-表示待检库存
  p_WAREHOUSE_ID  库存ID 如等于 -1 表示所有物料库存 0 表示本厂仓+外驻仓（不属于供应商的外驻仓）
  p_Inv_Batch_Id  批次id  如等于 -1 表示所有批次库存
  p_Warehouse_Property 仓库属性,-1 表示所有仓库类型
  */
Begin
  Sqlwhere := 'Select Sum(Nvl(i.QTY_ONHAND, 0)) TOTAL_QOH ' ||
              'From   inv_current_inv i, warehouse w ' ||
              'Where  i.organization_id = w.organization_id and  ' ||
              '       i.warehouse_id = w.warehouse_id and ' ||
              '       w.usable = 2 and  w.warehouse_type = ' ||
              P_warehouse_type || ' and i.Organization_Id = ' ||
              p_Organization_Id || '  and i.Item_Id = ' || p_Item_Id;
  ---仓库
  If (p_WAREHOUSE_ID > 0) Then
    Sqlwhere := Sqlwhere || ' and i.WAREHOUSE_ID=' || p_WAREHOUSE_ID;
  End If;

  ---仓库为零
  If (p_WAREHOUSE_ID = 0) Then
    Sqlwhere := Sqlwhere || ' and i.WAREHOUSE_ID not in (SELECT DISTINCT nvl(WAREHOUSE_ID, 0) FROM VENDOR_ORG) ';
  End If;


  ---批次
  If (p_Inv_Batch_Id >= 0) Then
    Sqlwhere := Sqlwhere || ' and i.Inv_Batch_Id=' || p_Inv_Batch_Id;
  End If;
  ---仓库类型
  If (p_Warehouse_Property > 0) Then
    Sqlwhere := Sqlwhere || ' and w.Warehouse_Property=' || p_Warehouse_Property;
  End If;


  Cur_Ap := Dbms_Sql.Open_Cursor;
  Dbms_Sql.Parse(Cur_Ap, Sqlwhere, Dbms_Sql.V7);
  --Dbms_Output.Put_Line('step1-1' || Cur_Ap);
  Dbms_Sql.Define_Column(Cur_Ap, 1, l_QTY_ONHAND);
  Num_Ap := Dbms_Sql.Execute(Cur_Ap);
  Loop
    If Dbms_Sql.Fetch_Rows(Cur_Ap) > 0 Then
      Dbms_Sql.Column_Value(Cur_Ap, 1, l_QTY_ONHAND);
      Result := l_QTY_ONHAND;
      --Dbms_Output.Put_Line('step3' || result);
    Else
      Exit;
    End If;
  End Loop;
  Dbms_Sql.Close_Cursor(Cur_Ap);

  Return Nvl(Result, 0);
Exception
  When Others Then
    If Dbms_Sql.Is_Open(Cur_Ap) Then
      Dbms_Sql.Close_Cursor(Cur_Ap);
    End If;
    --Dbms_Output.Put_Line(sqlcode);
    Return - 1;
End Fn_Onhand_Qty;
/

