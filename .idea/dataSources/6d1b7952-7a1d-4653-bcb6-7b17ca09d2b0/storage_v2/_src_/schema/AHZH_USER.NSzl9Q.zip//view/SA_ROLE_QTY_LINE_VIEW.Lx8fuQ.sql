create view SA_ROLE_QTY_LINE_VIEW as
    select srql.sa_role_qty_line_id,
           srql.sa_role_qty_head_id,
           srql.dept_id,
           2 monthn,
           srql.feb_qty qty
      from sa_role_qty_line srql
    union all
    select srql.sa_role_qty_line_id,
           srql.sa_role_qty_head_id,
           srql.dept_id,
           3 monthn,
           srql.mar_qty
      from sa_role_qty_line srql
    union all
    select srql.sa_role_qty_line_id,
           srql.sa_role_qty_head_id,
           srql.dept_id,
           4 monthn,
           srql.apr_qty
      from sa_role_qty_line srql
    union all
    select srql.sa_role_qty_line_id,
           srql.sa_role_qty_head_id,
           srql.dept_id,
           5 monthn,
           srql.may_qty
      from sa_role_qty_line srql
    union all
    select srql.sa_role_qty_line_id,
           srql.sa_role_qty_head_id,
           srql.dept_id,
           6 monthn,
           srql.jun_qty
      from sa_role_qty_line srql
    union all
    select srql.sa_role_qty_line_id,
           srql.sa_role_qty_head_id,
           srql.dept_id,
           7 monthn,
           srql.jul_qty
      from sa_role_qty_line srql
    union all
    select srql.sa_role_qty_line_id,
           srql.sa_role_qty_head_id,
           srql.dept_id,
           8 monthn,
           srql.aug_qty
      from sa_role_qty_line srql
    union all
    select srql.sa_role_qty_line_id,
           srql.sa_role_qty_head_id,
           srql.dept_id,
           9 monthn,
           srql.sep_qty
      from sa_role_qty_line srql
    union all
    select srql.sa_role_qty_line_id,
           srql.sa_role_qty_head_id,
           srql.dept_id,
           10 monthn,
           srql.oct_qty
      from sa_role_qty_line srql
    union all
    select srql.sa_role_qty_line_id,
           srql.sa_role_qty_head_id,
           srql.dept_id,
           11 monthn,
           srql.nov_qty
      from sa_role_qty_line srql
    union all
    select srql.sa_role_qty_line_id,
           srql.sa_role_qty_head_id,
           srql.dept_id,
           12 monthn,
           srql.dec_qty
      from sa_role_qty_line srql
    union all
    select srql.sa_role_qty_line_id,
           srql.sa_role_qty_head_id,
           srql.dept_id,
           1 monthn,
           srql.next_jan_qty
      from sa_role_qty_line srql
/

