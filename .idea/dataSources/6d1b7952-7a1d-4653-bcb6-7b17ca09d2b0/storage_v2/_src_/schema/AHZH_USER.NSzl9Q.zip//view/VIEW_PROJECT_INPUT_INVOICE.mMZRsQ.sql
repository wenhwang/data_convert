create view VIEW_PROJECT_INPUT_INVOICE as
SELECT HEAD.PROJECT_ID, --项目ID
       PARTNER_ID, --合伙人ID
       --PUR_CONTRACT_ID    采购合同ID
       HEAD.BILL_NO, --申请单号
       HEAD.BILL_DATE, --申请日期
       HEAD.OPERATOR, --申请人
       HEAD.INVOICE_QTY, --本次收票张数
       LINE.INVOICE_TYPE, --发票类型(枚举:1|专用发票（纸）、2|普通发票(纸)、3|专用发票（电）、4|普通发票(电))
       LINE.INVOICE_NUMBER, --发票号
       LINE.INVOICE_DATE, --发票日期
       LINE.INVOICE_CONTENT, --开票内容
       LINE.INVOICE_AMOUNT, --发票金额
       LINE.TAX_RATE, --税率（17%、11%、6%、3%）
       LINE.TAX_AMOUNT --发票税额=发票金额/(1+税率%)*税率%
  FROM FD_INPUT_INVOICE_LINE LINE, FD_INPUT_INVOICE_HEAD HEAD
 WHERE HEAD.INPUT_INVOICE_HEAD_ID = LINE.INPUT_INVOICE_HEAD_ID
   AND HEAD.STAT = 5
 /*********************************************\
  * NAME(名称): VIEW_PROJECT_INPUT_INVOICE
  * PURPOSE(功能说明):  收票明细
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2019-07-19
  \*********************************************/
/

