create view VIEW_CUSTOMER_USE_AMOUNT_EC as
select ssb.Customer_Code,
       ssb.Customer_Name,
       ssb.customer_id,
       ssb.organization_id,
       sum(ssb.Believe_Amount) Believe_Amount,
       sum(ssb.Invoice_Total) Invoice_Total,
       sum(ssb.Invoice_Receivable) Invoice_Receivable,
       sum(ssb.Actual_Total) Actual_Total,
       sum(ssb.No_Invoice_Total) No_Invoice_Total,
       sum(ssb.Actual_Mc_Amount)+nvl(sum(ssb.May_Consignment_Amount_N),0) Actual_Mc_Amount,
       sum(ssb.Crebit_Ctrl) Crebit_Ctrl,
       sum(ssb.Inv_Out_Total) Inv_Out_Total,
       sum(ssb.Out_Total) Out_Total,
       sum(ssb.Cost_Total) Cost_Total,
       sum(ssb.On_Way) On_Way,
       sum(nvl(ssb.Profit_Total,0)) Profit_Total,
       sum(ssb.May_Consignment_Amount_N) May_Consignment_Amount_N,
       sum(ssb.May_Consignment_Amount_P) May_Consignment_Amount_P
    from (
--BMS瀹㈡？棰？害
Select c.Customer_Code,
       c.Customer_Name,
       c.customer_id,
       co.organization_id,
       Nvl(comtex_all.Believe_Amount, 0) Believe_Amount,
       Nvl(comtex_all.Invoice_Total, 0) Invoice_Total,
       Nvl(comtex_all.Invoice_Receivable, 0) Invoice_Receivable,
       Nvl(comtex_all.Actual_Total, 0) Actual_Total,
       Nvl(comtex_all.Qbill, 0) No_Invoice_Total,
       Nvl(comtex_all.Believe_Amount, 0) + Nvl(comtex_all.Actual_Total, 0) -
       Nvl(comtex_all.Invoice_Total, 0) -
       Nvl(comtex_all.Invoice_Receivable, 0) - Nvl(comtex_all.Qbill, 0) as Actual_Mc_Amount,
       nvl(Co.crebit_ctrl, 1) Crebit_Ctrl,
       Nvl(comtex_all.Believe_Amount, 0) + Nvl(comtex_all.Actual_Total, 0) -
       Nvl(comtex_all.Invoice_Total, 0) -
       Nvl(comtex_all.Invoice_Receivable, 0) - Nvl(comtex_all.Qbill, 0) as May_Consignment_Amount_P,
       0 Inv_Out_Total,
       0 Out_Total,
       0 Cost_Total,
       0 On_Way,
       0 Profit_Total,
       0 May_Consignment_Amount_N
  From Customer c,
       Customer_Org Co,
       (select comtex.Customer_Id,
               sum(comtex.Believe_Amount) as Believe_Amount,
               sum(comtex.Invoice_Total) as Invoice_Total,
               sum(comtex.Invoice_Receivable) as Invoice_Receivable,
               sum(comtex.Actual_Total) as Actual_Total,
               sum(comtex.Qbill) as Qbill
          from ((Select Customer_Id,
                        Nvl(Sum(Scb.Amount - Scb.Fact_Amount), 0) Believe_Amount,
                        0 Invoice_Total,
                        0 Invoice_Receivable,
                        0 Actual_Total,
                        0 Qbill
                   From Sa_Confer_Believe Scb
                  Where Scb.Is_Cancellation = 1
                    And Scb.Stat = 5
                    And Trunc(sysdate) Between Trunc(Scb.Star_Date) And
                        Trunc(Scb.End_Date)
                  Group By Customer_Id) union all
                (select customer_id,
                        0 Believe_Amount,
                        sum(invoice_total) invoice_total,
                        0 Invoice_Receivable,
                        0 Actual_Total,
                        0 Qbill
                   from (Select Customer_Id,
                                0 Believe_Amount,
                                --Nvl(Sum(Aih.Amount_Bill_f), 0) Invoice_Total,
                                Nvl(Sum(aa.Qty_Bill*aa.PRICE_TAX), 0) Invoice_Total,
                                0 Invoice_Receivable,
                                0 Actual_Total,
                                0 Qbill
                           From Ar_Invoice_Head Aih,ar_invoice_line aa
                          Where aih.ar_invoice_head_id = aa.ar_invoice_head_id
                            and Aih.Is_Auditing = 2
                            And Aih.Is_Blank_Out = 1
                            And aih.BILL_STAT <> 2
                            And aih.bill_type <> 2
                            and not exists (select 1
                                   from ar_invoice_line   al,
                                        inv_out_bill_head iobh
                                  where aih.ar_invoice_head_id =
                                        al.ar_invoice_head_id
                                    and al.inv_out_bill_head_id =
                                        iobh.inv_out_bill_head_id
                                    and aa.ar_invoice_line_id = al.ar_invoice_line_id
                                    and nvl(iobh.is_from_ec,0) = 2
                                    and iobh.is_auditing_wh = 2)
                            and not exists (select 1
                                   from ar_invoice_line   al,
                                        inv_in_bill_head iibh
                                  where aih.ar_invoice_head_id =
                                        al.ar_invoice_head_id
                                    and al.inv_in_bill_head_id =
                                        iibh.inv_in_bill_head_id
                                    and aa.ar_invoice_line_id = al.ar_invoice_line_id
                                    and nvl(iibh.is_from_ec,0) = 2
                                    and iibh.is_auditing_wh = 2)
                          Group By Customer_Id
                         union all
                         select iobh.customer_id,
                                0 Believe_Amount,
                                sum((iobl.qty_bill - iobl.qty_match_total) *
                                    nvl(iobl.wtpricec_bill_f, 0)) Invoice_Total,
                                0 Invoice_Receivable,
                                0 Actual_Total,
                                0 Qbill
                           from Inv_Out_Bill_Line Iobl, Inv_Out_Bill_Head Iobh
                          where iobl.inv_out_bill_head_id =
                                iobh.inv_out_bill_head_id
                            and iobh.is_auditing_wh = 2
                            and iobh.billtypecode = '0204'
                            and nvl(iobh.is_from_ec,0) <> 2
                            and iobl.qty_bill <> iobl.qty_match_total
                          group by iobh.customer_id
                         union all
                         select iibh.customer_id,
                                0 Believe_Amount,
                                -sum((iibl.qty_invbill - iibl.qty_match_total) *
                                     nvl(iibl.wtpricec_bill_f, 0)) Invoice_total,
                                0 Invoice_Receivable,
                                0 Actual_Total,
                                0 Qbill
                           from Inv_In_Bill_Line iibl, inv_in_bill_head iibh
                          where iibl.inv_in_bill_head_id =
                                iibh.inv_in_bill_head_id
                            and iibh.is_auditing_wh = 2
                            and iibh.billtypecode = '0206'
                            and nvl(iibh.is_from_ec,0) <> 2
                            and iibl.qty_invbill <> iibl.qty_match_total
                          group by iibh.customer_id)
                  group by customer_id) union all
                (Select Customer_Id,
                        0 Believe_Amount,
                        0 Invoice_Total,
                        Nvl(Sum(Aih.Amount_Bill_f), 0) Invoice_Receivable,
                        0 Actual_Total,
                        0 Qbill
                   From Ar_Invoice_Head Aih
                  Where Aih.Is_Auditing = 2
                    And Aih.Is_Blank_Out = 1
                    And aih.BILL_STAT <> 2
                    And aih.bill_type = 2
                  Group By Customer_Id) union all
                (Select Customer_Id,
                        0 Believe_Amount,
                        0 Invoice_Total,
                        0 Invoice_Receivable,
                        Nvl(Sum(Ag.Amount_Debit), 0) Actual_Total,
                        0 Qbill
                   From Fd_Fund_Business Ag
                  Where Ag.Is_Auditing = 2
                    and ag.is_ar_fund = 2
                    and ag.record_type = 2
                    and nvl(ag.is_from_ec,0) <> 2
                  Group By Customer_Id) union all
                (Select Customer_Id,
                        0 Believe_Amount,
                        0 Invoice_Total,
                        0 Invoice_Receivable,
                        0 Actual_Total,
                        Nvl(Sum(Qbill), 0) Qbill
                   From (Select Customer_Id,
                                0 Believe_Amount,
                                0 Invoice_Total,
                                0 Invoice_Receivable,
                                0 Actual_Total,
                                Nvl(Sum((Sobl.Qty_Bill -
                                        (select nvl(sum(iol.qty_bill), 0)
                                            from inv_out_bill_head ioh,
                                                 inv_out_bill_line iol
                                           where ioh.inv_out_bill_head_id =
                                                 iol.inv_out_bill_head_id
                                             and iol.sa_out_bill_line_id =
                                                 sobl.sa_out_bill_line_id
                                             and ioh.is_auditing_wh = 2
                                             and ioh.billtypecode = '0204')) *
                                        Sobl.Price_Bill_f),
                                    0) Qbill
                           From Sa_Out_Bill_Head Sobh, Sa_Out_Bill_Line Sobl
                          Where Sobh.Sa_Out_Bill_Head_Id =
                                Sobl.Sa_Out_Bill_Head_Id
                            And Sobh.Is_Auditing_Wh = 2
                            And Sobh.Bill_Type = 1
                            and sobh.Sale_Type <> 3
                            and Sobh.BILL_STATS not in (2, 3)
                            and not exists
                          (select iil.sa_out_bill_head_id
                                   from inv_out_bill_head iih,
                                        inv_out_bill_line iil
                                  where iih.inv_out_bill_head_id =
                                        iil.inv_out_bill_head_id
                                    and iil.sa_out_bill_head_id =
                                        sobh.sa_out_bill_head_id
                                    and iih.billtypecode = '0204'
                                    and iih.Is_Auditing_Wh = 2
                                    and iih.is_have_order = 2
                                    and nvl(iih.is_confirm, 1) = 2
                                    and nvl(iil.sa_out_bill_head_id, 0) > 0)
                          Group By Customer_Id
                         Union All
                         Select Iobh.Customer_Id,
                                0 Believe_Amount,
                                0 Invoice_Total,
                                0 Invoice_Receivable,
                                0 Actual_Total,
                                Nvl(Sum(Iobl.Wtamount_Bill_f -
                                        Iobl.Wtpricec_Bill_f * Iobl.Qty_Red),
                                    0) Qbill
                           From Inv_Out_Bill_Head Iobh, Inv_Out_Bill_Line Iobl
                          Where Iobh.Inv_Out_Bill_Head_Id =
                                Iobl.Inv_Out_Bill_Head_Id
                            And Iobh.Is_Have_Order = 1
                            And Iobh.Billtypecode = '0204'
                            And Iobh.Inv_Out_Type = 1
                            And Iobh.Is_Auditing_Wh <> 2
                            And Iobh.Stat > 1
                          Group By Iobh.Customer_Id
                         Union All
                         Select Customer_Id,
                                0 Believe_Amount,
                                0 Invoice_Total,
                                0 Invoice_Receivable,
                                0 Actual_Total,
                                Nvl(Sum(Sobl.Qty_Bill * Sobl.Price_Bill_f), 0) Qbill
                           From Sa_Out_Bill_Head Sobh, Sa_Out_Bill_Line Sobl
                          Where Sobh.Sa_Out_Bill_Head_Id =
                                Sobl.Sa_Out_Bill_Head_Id
                            And Sobh.Is_Auditing_Wh <> 2
                            And (Nvl(Sobh.Stat, 0) > 1)
                            And Sobh.Bill_Type = 1
                            and sobh.Sale_Type <> 3
                          Group By Customer_Id)
                  Group By Customer_Id)) comtex
         group by customer_id) comtex_all
 Where c.Customer_Id = Co.Customer_Id
   And c.Customer_Id = comtex_all.Customer_Id(+)
 /*
 fxh 2013-08-06 ？？blink？逛负webservice妯″纺
 union all
 --？靛？瀹㈡？棰？害
select cc.customer_code,
        cc.customer_name,
        cc.customer_id,
        cco.organization_id,
       0 Believe_Amount,
       0 Invoice_Total,
       0 Invoice_Receivable,
       0 Actual_Total,
       0 No_Invoice_Total,
       0 Actual_Mc_Amount,
       0 Crebit_Ctrl,
       0 May_Consignment_Amount_P,
       sum(cb.long_credit) Inv_Out_Total,
       sum(cb.start_balance) Out_Total,
       sum(cb.pay_amount) Cost_Total,
       sum(cb.order_amount) On_Way,
       sum(nvl(cb.other_amount,0)) Profit_Total,
       nvl(sum(cb.start_balance),0)+nvl(sum(cb.long_credit),0)+nvl(sum(cb.pay_amount),0)+nvl(sum(cb.other_amount),0)-nvl(sum(cb.order_amount),0)-nvl(sum(cb.bonus_used_amount),0) May_Consignment_Amount_N
  from (select a.member_id,
               sm.customer_code,
               nvl(a.end_balance, 0) start_balance,
               0 pay_amount,
               0 order_amount,
               0 long_credit,
               0 other_amount,
               0 bonus_used_amount
          from shop_available_amount_Balance@shop_ec a,shop_member@shop_ec sm
         where a.member_id = sm.member_id
           and nvl(sm.Is_SharingCredit,0) = 2
           and sm.customer_code is not null
           and a.bal_month =
               (select param_value
                  from shop_param@shop_ec
                 where param_code = 'available_amount_month')
        union all
        select m.member_id,sm.customer_code, 0, 0, 0, m.long_credit, 0,0
          from shop_member@shop_ec m,shop_member@shop_ec sm
         where m.member_id = sm.member_id
           and nvl(sm.Is_SharingCredit,0) = 2
           and sm.customer_code is not null
           and m.long_credit <> 0
        union all
        select b.member_id,
               sm.customer_code,
               0,
               nvl(b.pay_amount, 0) pay_amount,
               nvl(b.order_amount, 0) order_amount,
               0 long_credit,
               b.other_amount,
               b.bonus_used_amount
          from view_account_available_amount@shop_ec b,shop_member@shop_ec sm
         where b.member_id = sm.member_id
           and nvl(sm.Is_SharingCredit,0) = 2
           and sm.customer_code is not null
           and b.update_time >=
               (select to_date(to_char(add_months(to_date(param_value,
                                                          'yyyy-mm'),
                                                  1),
                                       'yyyy-mm') || '-01',
                               'yyyy-mm-dd')
                  from shop_param@shop_ec
                 where param_code = 'available_amount_month')
           and b.order_stat not in (1, 99)) cb,
       customer cc,customer_org cco
 where  cc.customer_code = cb.customer_code
   and cc.customer_id = cco.customer_id
 group by cc.customer_code,cc.customer_id,cc.customer_name,cco.organization_id*/) ssb
where 1=1
  group by ssb.Customer_Code,
       ssb.Customer_Name,
       ssb.customer_id,
       ssb.organization_id
/

