create view BASE_VIEW_ITEM_ORG as
SELECT ITEM_ORG.ORGANIZATION_ID, --产品组织ID
       ITEM_ORG.ITEM_ORG_ID, --ITEM_ORG_ID
       ITEM_ORG.ITEM_ID, --物料主文件ID,从BAS_ITEM来源
       ITEM.ITEM_CODE, --产品编码
       ITEM.ITEM_NAME, --产品名称
       ITEM.UOM_ID, --单位
       UOM.UOM_CODE,
       UOM.UOM_NAME,
       ITEM_ORG.BUYER_ID, --采购员,从BUYER来源
       ITEM_ORG.WAREHOUSE_ID, --缺省仓库,从WAREHOUSE来源
       WAREHOUSE_CODE,
       WAREHOUSE_NAME,
       ITEM_ORG.WHEMPLOYEE_ID, --缺省仓管员,从WHEMPLOYEE来源
       ITEM_ORG.CAN_SALE, --可销售:否：1，是：2
       ITEM_ORG.ABC, --ABC类码:A、B、C
       ITEM_ORG.CLASS_CODE, --存货分类
       ITEM_ORG.QTY_MAX, --最大库存
       ITEM_ORG.QTY_MIN, --安全库存
       ITEM_ORG.GL_ACCOUNT_SUBJECT_ID_ZC, --资产科目ID
       ITEM_ORG.SPECS, --规格
       ITEM_ORG.ITEM_TYPE, --物料类别:1  普通物料、3 参考、4  结构虚项、5  组合商品、6 虚拟商品
       ITEM_ORG.PM_CODE, --制购码:1  制造、2   采购、3   委外加工、4 特销件
       ITEM_ORG.BAR_CODE, --条码
       ITEM_ORG.ITEM_CLASS1, --小类
       ITEM_ORG.ITEM_CLASS2, --大类
       ITEM_ORG.ITEM_CLASS3, --自定义分类
       ITEM_ORG.ITEM_CLASS4, --分类4,来源ITEM_CLASS
       ITEM_ORG.ITEM_CLASS5, --分类5,来源ITEM_CLASS
       ITEM_ORG.ITEM_CLASS6,
       ITEM_ORG.ITEM_USABLE, --是否生效 1 否 2 是
       ITEM_ORG.SCRAP_PERCENT, --损耗率
       ITEM_ORG.DESC_TECH, --技术标准
       ITEM_ORG.STD_TYPE, --通用类型 STDTYPE  标准件1 通用件2 专用件3
       ITEM_ORG.GROSS_WEIGTH, --毛重
       ITEM_ORG.NET_WEIGTH, --净重
       ITEM_ORG.CUBAGE, --体积
       ITEM_ORG.PRODUCT_CLASS, --产品分类
       ITEM_ORG.PRICE_FROM, --订单价格来源 1 手工输入 2 采购价格表
       ITEM_ORG.QTY_UOM,
       ITEM_ORG.ENTORGID, --产品组织（词汇表）
       ITEM_ORG.ENTORGNAME, --CRM的产品组织名称
       ITEM_ORG.PRICE_TYPE, --产品属性（7为赠品，其他为正品）
       ITEM_ORG.COUNT_PERCASE, --单件包装数量
       ITEM_ORG.SPEC_QTY, --凑整数量
       ITEM_ORG.MAX_INV, --库存上限
       ITEM_ORG.MIN_INV, --  库存下限
       ITEM_ORG.OLD_ITEM_CODE, --  旧商品编码
       ITEM_ORG.OLD_ITEM_NAME, -- 旧商品名称
       ITEM_ORG.COLORBOX_SIZE, --  彩箱包装尺寸
       ITEM_ORG.INBOX_SIZE, -- 中箱包装尺寸
       ITEM_ORG.OUTBOX_SIZE, -- 外箱包装尺寸
       ITEM_ORG.OUTBOX_CUBAGE, -- 外箱包装体积
       ITEM_ORG.IS_SPECIAL_SUPPLY, -- 是否专供
       ITEM_ORG.WEIGHT, -- 重量
       ITEM_ORG.IS_CHECK, --是否质检：1 免检；2 必检；3 抽检
       ITEM_ORG.IS_SYSCREATE, -- 是否系统预设 1否 2是
       ITEM_ORG.IS_STOCK, --可采购否 1 否 2 是
       ITEM_ORG.IS_NEW, --  是否新品   1否 2是
       ITEM_ORG.IS_RETAIL, --  是否零售
       ITEM_ORG.IS_WL, --  是否物料1否2是
       ITEM_ORG.IS_BATCH_CTRL, --是否批次控制 1 否 2 是
       ITEM_ORG.IS_CONSIGN,
       ITEM_ORG.BAS_BRAND_ID, -- 商品品牌ID(来源BAS_BRAND)
       ITEM_ORG.DOC_ID, -- 存储CPCDOC表DOCID 产品图片
       ITEM_ORG.NOTE, -- 备注
       ITEM_ORG.CREATED_BY, -- 创建者
       ITEM_ORG.CREATION_DATE, --  创建日期
       ITEM_ORG.LAST_UPDATED_BY, --  最后修改人
       ITEM_ORG.LAST_UPDATE_DATE, -- 最后修改日期
       ITEM_ORG.ATTRIBUTE1, --  备用字段1
       ITEM_ORG.ATTRIBUTE2, --  备用字段2
       ITEM_ORG.ATTRIBUTE3, -- 备用字段3
       ITEM_ORG.ATTRIBUTE4, -- 备用字段4
       ITEM_ORG.ATTRIBUTE5 --  备用字段5
  FROM ITEM_ORG, ITEM, WAREHOUSE, UOM
 WHERE ITEM_ORG.ITEM_ID = ITEM.ITEM_ID
   AND ITEM_ORG.WAREHOUSE_ID = WAREHOUSE.WAREHOUSE_ID(+)
   AND ITEM.UOM_ID = UOM.UOM_ID(+)

  /*********************************************\
  * NAME(名称): BASE_VIEW_ITEM_ORG
  * PURPOSE(功能说明):  产品资料
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-04-23
  \*********************************************/
/

