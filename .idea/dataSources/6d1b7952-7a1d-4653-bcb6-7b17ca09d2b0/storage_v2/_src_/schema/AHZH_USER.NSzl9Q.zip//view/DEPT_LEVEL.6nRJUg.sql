create view DEPT_LEVEL as
select a.orgid as dept_id,a.superid pdept_id,
       case  when a.code is not null then
          a.code else a.orgname
       end as dept_code,
       orgname as DEPT_NAME,
       a.idpath,
       level deptlevel
       from cpcorg a
start with a.superid=0
connect by prior a.orgid=a.superid
/

