create view SUPPLIER as
select a.orgid supp_id,a.code supp_code,a.orgname supp_name,
  a.orgname short_name,a.orgid orgid,a.code org_code,a.orgname org_name,a.idpath, 3 Supp_Type,a.orgtype ,a.entid,
  '' Area_Code,'' Area_name,'' Area_id
    from cpcorg a where  a.orgtype=1
/

