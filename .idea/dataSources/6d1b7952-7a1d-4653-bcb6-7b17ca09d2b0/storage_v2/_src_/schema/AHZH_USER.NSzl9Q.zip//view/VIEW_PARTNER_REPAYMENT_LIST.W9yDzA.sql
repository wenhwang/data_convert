create view VIEW_PARTNER_REPAYMENT_LIST as
SELECT 2 BILL_TYPE, --业务单据金额
       ORDINAL_NO BILL_NO,
       PROJECT_ID,
       SUM(AMOUNT) AMOUNT
  FROM (SELECT HEAD.ORDINAL_NO,
               LINE.PROJECT_ID,
               NVL(LINE.AMOUNT * LINE.PLUS_MINUS, 0) AMOUNT
          FROM FIN_RECEIPT_VOUCHER_LINE LINE,
               FIN_RECEIPT_VOUCHER HEAD,
               FD_PAYMENT_TYPE
         WHERE HEAD.FIN_RECEIPT_VOUCHER_ID = LINE.FIN_RECEIPT_VOUCHER_ID
           AND HEAD.BUSINESS_TYPE = FD_PAYMENT_TYPE.FD_PAYMENT_TYPE_ID
           AND UPDATE_FIELD = 'BORROW_AMOUNT' --收到公司借支款
           AND HEAD.STAT = 5
           AND NVL(LINE.PROJECT_ID, 0) <> 0)
 GROUP BY ORDINAL_NO, PROJECT_ID

/*********************************************\
 * NAME(名称): VIEW_PARTNER_REPAYMENT_LIST
  * PURPOSE(功能说明):  合伙人还款明细(不计入项目往来余额)
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-04-17
\*********************************************/
/

