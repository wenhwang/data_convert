create view VIEW_BCS_WAREHOUSE as
Select Organization_Id Corp_Id,
       Warehouse_Id,
       Warehouse_Code,
       Warehouse_Name,
       Usable,
       Warehouse_Property,
       Is_End,
       Customer_Id,
       Warehouse_Pid,
       Created_By,
       Creation_Date,
       Last_Updated_By,
       Last_Update_Date,
       warehouse_idpath
From   Warehouse
/

