create trigger T_INV_WH_CHECK_HEAD_UPDATED
    after update
    on INV_WH_CHECK_HEAD
    for each row
declare
  v_count number := 0;
  head_id number := 0;
begin
  if updating then
    --查询是否配置帐套对照关系
    select count(1)
      into v_count
      from CCS_BMS_ORG_COMPARE c
     where nvl(c.usable, 0) = 2
       and c.organization_id = :new.organization_id;
    --存在则写入接口表
    if v_count = 1 then
      --调拨单审核时写入接口表
      if (:new.IS_AUDITING = 2) and (nvl(:old.IS_AUDITING, 0) <> 2) then
        --取序列
        select sq_inv_out_to_ccs__head.nextval into head_id from dual;

        --插入接口表
        insert into inv_out_to_ccs_head
          (INV_OUT_TO_CCS_HEAD_ID,
           ORGANIZATION_ID,
           SOURCE_HEAD_ID,
           INVBILLNO,
           WAREHOUSE_ID,
           WAREHOUSE_CODE,
           DATE_INVBILL,
           YEAR_MONTH,
           VENDOR_ID,
           VENDOR_CODE,
           CRM_ENTID,
           ENTORGID,
           DEPT_ID,
           DEPT_CODE,
           NOTE,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           ATTRIBUTE1,
           ATTRIBUTE2,
           ATTRIBUTE3,
           ATTRIBUTE4,
           ATTRIBUTE5,
           INV_OUT_TYPE,
           STATUS,
           ERROR_MES,
           BILL_TYPE,
           EMPLOYEE_NAME,
           EMPLOYEE_ID_WH,
           EMPLOYEE_NAME_WH)
          select head_id,
                 (select c.ccs_organization_id
                    from CCS_BMS_ORG_COMPARE c
                   where nvl(c.usable, 0) = 2
                     and c.organization_id = :new.organization_id) ORGANIZATION_ID,
                 :new.INV_WH_CHECK_HEAD_ID SOURCE_HEAD_ID,
                 :new.INVBILL_NO INVBILLNO,
                 :new.WAREHOUSE_ID WAREHOUSE_ID,
                 (select w.warehouse_code
                    from warehouse w
                   where w.warehouse_id = :new.WAREHOUSE_ID
                     and w.organization_id = :new.organization_id
                     and rownum = 1) WAREHOUSE_CODE,
                 :new.DATE_INVBILL DATE_INVBILL,
                 :new.YEAR_MONTH,
                 0 VENDOR_ID,
                 '' VENDOR_CODE,
                 :new.CRM_ENTID,
                 :new.entorgid,
                 :new.DEPT_ID DEPT_ID,
                 (select d.dept_code
                    from dept d
                   where d.dept_id = :new.DEPT_ID) DEPT_CODE,
                 :new.NOTE NOTE,
                 :new.CREATED_BY,
                 :new.CREATION_DATE,
                 'admin' LAST_UPDATED_BY,
                 sysdate LAST_UPDATE_DATE,
                 :new.ATTRIBUTE1,
                 :new.ATTRIBUTE2,
                 :new.ATTRIBUTE3,
                 :new.ATTRIBUTE4,
                 :new.ATTRIBUTE5,
                 :new.CHECK_TYPE INV_OUT_TYPE,
                 0 STATUS,
                 '' ERROR_MES,
                 11 BILL_TYPE,
                 :new.EMPLOYEE_ID_CHECK,
                 :new.WHEMPLOYEE_ID,
                 (select e.EMPLOYEE_NAME
                    from erpemployee e
                   where e.employee_id = :new.WHEMPLOYEE_ID) EMPLOYEE_NAME_WH
            from dual;

        --插入明细接口表
        insert into inv_out_to_ccs_line
          (INV_OUT_TO_CCS_LINE_ID,
           INV_OUT_TO_CCS_HEAD_ID,
           SOURCE_HEAD_ID,
           SOURCE_LINE_ID,
           LINENO,
           ITEM_ID,
           ITEM_CODE,
           QTY_BILL,
           BCS_QTY_ZM,
           BCS_QTY_ACTUAL,
           PRICE_BILL_F,
           AMOUNT_BILL_F,
           REMARK,
           CREATED_BY,
           CREATION_DATE,
           LAST_UPDATED_BY,
           LAST_UPDATE_DATE,
           ATTRIBUTE11,
           ATTRIBUTE21,
           ATTRIBUTE31,
           ATTRIBUTE41,
           ATTRIBUTE51,
           WTPRICEC_BILL_F,
           WTAMOUNT_BILL_F)
          select sq_inv_out_to_ccs_line.nextval INV_OUT_TO_CCS_LINE_ID,
                 head_id INV_OUT_TO_CCS_HEAD_ID,
                 bl.INV_WH_CHECK_HEAD_ID SOURCE_HEAD_ID,
                 bl.INV_WH_CHECK_LINE_ID SOURCE_LINE_ID,
                 bl.LINE_NO LINENO,
                 bl.ITEM_ID,
                 (select i.item_code
                    from item i
                   where i.item_id = bl.item_id) ITEM_CODE,
                 bl.QTY_CHECK QTY_BILL,
                 bl.qty_account,
                 bl.QTY_PROFITLOSS,
                 bl.PRICE PRICE_BILL_F,
                 bl.AMOUNT_PL AMOUNT_BILL_F,
                 bl.NOTE REMARK,
                 bl.CREATED_BY,
                 bl.CREATION_DATE,
                 'admin' LAST_UPDATED_BY,
                 sysdate LAST_UPDATE_DATE,
                 bl.ATTRIBUTE1,
                 bl.ATTRIBUTE2,
                 bl.ATTRIBUTE3,
                 bl.ATTRIBUTE4,
                 bl.attribute5,
                 bl.PRICE WTPRICEC_BILL_F,
                 bl.AMOUNT_PL WTAMOUNT_BILL_F
            from inv_wh_check_line bl
           where bl.inv_wh_check_head_id = :old.inv_wh_check_head_id;

      end if;
    end if;
  end if;
end;
/

