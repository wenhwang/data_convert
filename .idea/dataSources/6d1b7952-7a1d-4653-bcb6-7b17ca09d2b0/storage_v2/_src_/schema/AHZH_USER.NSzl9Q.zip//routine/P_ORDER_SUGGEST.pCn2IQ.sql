create Procedure           p_Order_Suggest Is
  tempname varchar2(100);
  sqlstr   varchar2(8000);
Begin
  --？？缓涓存？琛?
  select 'TEMP' || lpad(sq_gettemptable.nextval, 9, '0')
    into tempname
    from dual;
  sqlstr := 'create table ' || tempname ||
            ' as select * from Sa_Ordery_Sum Where Nvl(Is_Mrp, 1) = 1';
  Execute Immediate sqlstr;
  --？？？链？？？？？姹?
  -- Delete From Mes_Mrp_Result;

  --？？？？？姹？？？?
  sqlstr := 'Insert Into Mes_Mrp_Result' || '  (Mes_Mrp_Result_Id, ' ||
            '   Organization_Id, ' || '   Item_Id, ' || '   Mpsbatch_No,' ||
            '   Date_Due,' || '   Date_Due_Order_Ss,' || '   Record_Type,' ||
            '   Qty,' || '   Remainqty,' || '   Pmcode,' || '   Mo_Type)' ||
            '  Select Sq_Mes_Mrp_Result.Nextval,' ||
            '         t.organization_id,' || '         t.Item_Id,' ||
            '         t.Bill_No,' || '        t.Date_Need,' ||
            '         t.Date_Need,' || '         3,' ||
            '         t.Qty_Chk,' || '         t.Qty_Chk,' ||
            '         t.Pm_Code,' || '         1' ||
            '    From (Select Bb.Item_Id,' ||
            '                 Io.organization_id,' ||
            '                 '''' Bill_No,' ||
            '                 Soh.Date_Need,' ||
            '                 Sum(Soh.Qty_Chk *' ||
            '                     (Bb.Bom_Qty + Bb.Bom_Scrap_Percent / 100)) Qty_Chk,' ||
            '                 Io.Pm_Code' || '            From ' ||
            tempname || ' Soh, Bas_Bom Bb, Item_Org Io' ||
            '           Where Nvl(Soh.Is_Mrp, 1) = 1' ||
            '             And Soh.organization_id = Io.organization_id' ||
            '             And Soh.Item_Id = Bb.Ite_Item_Id' ||
            '             And Bb.Item_Id = Io.Item_Id ' ||
            '           Group By Bb.Item_Id,' ||
            '                    Io.organization_id,' ||
            '                    soh.Date_Need,' ||
            '                    Io.Pm_Code) t';

  Execute Immediate sqlstr;

  --镟存？宸查？姹？？寮？镄？？？?
  sqlstr := 'Update Sa_Ordery_Sum Sol Set Sol.Is_Mrp = 2 Where sol.Sa_Ordery_Sum_id in (select Sa_Ordery_Sum_id from ' ||
            tempname || ')';
  Execute Immediate sqlstr;
  sqlstr := 'Drop table ' || tempname;
  Execute Immediate sqlstr;
  Commit;

End p_Order_Suggest;
/

