create view VIEW_DINGTALK_BUILDERUSE as
SELECT "PROJECT_CODE","PROJECT_NAME","RESOURCE_IDENTIFIER","RESOURCE_NAME","PROFESSIONAL_CATEGORY","EMPLOYEE_NAME","LOAN_DATE","RETURN_DATE"
          FROM (SELECT PROJECT_CODE,
                       PROJECT_NAME,
                       RESOURCE_IDENTIFIER,
                       RESOURCE_NAME,
                       PROFESSIONAL_CATEGORY,
                       EMPLOYEE_NAME,
                       LINE.LOAN_DATE,
                       LINE.RETURN_DATE
                  FROM EPM_RESOUCE_LOAN_RETURN_HEAD HEAD,
                       EPM_RESOUCE_LOAN_RETURN_LINE LINE,
                       EPM_PROJECT,
                       (SELECT RESOUCE_ARCHIVES_ID,
                               RESOURCE_IDENTIFIER,
                               RESOURCE_NAME,
                               PROFESSIONAL_CATEGORY,
                               EMPLOYEE.EMPLOYEE_NAME
                          FROM EPM_RESOUCE_ARCHIVES ARCHIVES,
                               EMPLOYEE_HEADER      EMPLOYEE
                         WHERE ARCHIVES.HR_EMPLOYEE_HEAD_ID = EMPLOYEE.EMPLOYEE_ID(+)) ARCHIVES
                 WHERE HEAD.RESOUCE_LOAN_RETURN_HEAD_ID =
                       LINE.RESOUCE_LOAN_RETURN_HEAD_ID
                   AND HEAD.LOAN_PROJECT_ID = EPM_PROJECT.PROJECT_ID(+)
                   AND LINE.RESOUCE_ARCHIVES_ID = ARCHIVES.RESOUCE_ARCHIVES_ID(+)
                   AND HEAD.STAT = 5
                   AND NVL(HEAD.LOAN_PROJECT_ID, 0) <> 0
                   AND LINE.RESOUCE_TYPE = 2
                   AND RESOUCE_CATEGORY_ID = 3)  WHERE 1 = 1

/*********************************************\
  * NAME(名称): VIEW_DINGTALK_BUILDERUSE
  * PURPOSE(功能说明):  钉钉智能报表-建造师使用
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-11-14
  \*********************************************/
/

