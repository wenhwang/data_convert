create TYPE "EPM_OPERATE_REPORT_ROW" AS OBJECT
(
  KEY_TYPE VARCHAR2(16), --类型编码
  KEY      VARCHAR2(128), --类型名称
  VALUE    VARCHAR2(512) --值
)

/*********************************************\
  * NAME(名称): EPM_OPERATE_REPORT_ROW
  * PURPOSE(功能说明):  运营报备类型
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2019-07-18
  \*********************************************/
/

