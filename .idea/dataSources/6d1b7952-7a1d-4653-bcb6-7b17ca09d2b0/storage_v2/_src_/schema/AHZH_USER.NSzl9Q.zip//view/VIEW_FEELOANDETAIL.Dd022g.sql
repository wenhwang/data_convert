create view VIEW_FEELOANDETAIL as
SELECT "LOAN_NO","PROJECT_CODE","PROJECT_NAME","CHAP_NAME","CREATE_TIME","REPAYMENT_DATE","BUSINESS_TYPE_NAME","LOAN_TYPE_NAME","ALLOW_AMT"
  FROM (SELECT HEAD.LOAN_NO,
               PROJECT_CODE,
               PROJECT_NAME,
               USERNAME CHAP_NAME,
               CREATE_TIME,
               REPAYMENT_DATE,
               FD_PAYMENT_TYPE.PAYMENT_TYPE_NAME BUSINESS_TYPE_NAME,
               DECODE(LINE.LOAN_TYPE,
                      1,
                      '公司借款',
                      2,
                      '业务借款',
                      3,
                      '差旅借款',
                      4,
                      '其他借款') LOAN_TYPE_NAME,
               LINE.ALLOW_AMT
          FROM MKT_LOAN_HEADER HEAD,
               MKT_LOAN_LINE LINE,
               EPM_PROJECT PROJECT,
               CPCUSER,
               FD_PAYMENT_TYPE
         WHERE HEAD.LOAN_ID = LINE.LOAN_ID(+)
           AND HEAD.PROJECT_ID = PROJECT.PROJECT_ID(+)
           AND HEAD.CHAP_ID = SYSUSERID(+)
           AND HEAD.BUSINESS_TYPE = FD_PAYMENT_TYPE.FD_PAYMENT_TYPE_ID(+)
           AND HEAD.STAT = 5)
 WHERE 1 = 1
/

