create view VIEW_WITHDRAWINGFINE as
SELECT "BILL_TYPE","PROJECT_CODE","PROJECT_NAME","APPLY_DATE","CHARGE_TYPE","APPROVED_AMOUNT"
          FROM (SELECT '项目扣款' BILL_TYPE,
                       PROJECT_CODE,
                       PROJECT_NAME,
                       APPLY_DATE,
                       DECODE(LINE.CHARGE_TYPE,
                              'WITHHOLD_YEAR_AMOUNT',
                              ' 年费',
                              'WITHHOLD_MANAGEMENT_AMOUNT',
                              ' 管理费',
                              'WITHHOLD_TAX_AMOUNT',
                              ' 税费',
                              'WITHHOLD_OTHER_AMOUNT',
                              ' 其他',
                              '') CHARGE_TYPE,
                       LINE.APPROVED_AMOUNT
                  FROM EPM_PROJECT_KK_APPLY_HEAD HEAD,
                       EPM_PROJECT_KK_APPLY_LINE LINE,
                       EPM_PROJECT
                 WHERE HEAD.PROJECT_KK_APPLY_HEAD_ID = LINE.PROJECT_KK_APPLY_HEAD_ID
                   AND HEAD.PROJECT_ID = EPM_PROJECT.PROJECT_ID
                   AND HEAD.STAT = 5          UNION ALL
                SELECT '项目罚款' BILL_TYPE,
                       PROJECT_CODE,
                       PROJECT_NAME,                APPLY_DATE,
                       '项目罚款' CHARGE_TYPE,
                       APPLY_AMOUNT
                  FROM EPM_PROJECT_FINE_APPLY HEAD, EPM_PROJECT
                 WHERE HEAD.PROJECT_ID = EPM_PROJECT.PROJECT_ID
                   AND HEAD.STAT = 5)  WHERE 1 = 1
/

