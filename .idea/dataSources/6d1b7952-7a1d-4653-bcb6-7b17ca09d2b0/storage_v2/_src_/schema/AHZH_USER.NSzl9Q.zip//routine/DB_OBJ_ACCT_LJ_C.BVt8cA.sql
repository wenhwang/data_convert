create Function           Db_Obj_Acct_Lj_C(P_KM_CODEs         Varchar2,
                                        P_GET_TYPE         VARCHAR2,
                                        P_YEAR_MONTH       VARCHAR2,
                                        P_Organization_Ids Varchar2,
                                   P_Object_Type      Varchar2,
                                   P_Object_Id        Integer)
  Return Number Is
  Result Number;
  /*l_str     VARCHAR2(1000) := P_KM_CODEs || '\';
  l_n       NUMBER;*/
  kmcodes        VARCHAR2(1000);
  orgids         VARCHAR2(300);
  Sqlwhere       VARCHAR2(2000);
  fieldname      VARCHAR2(300);
  intflag        number;
  S_YEAR_MONTH  VARCHAR2(7);
  E_YEAR_MONTH  VARCHAR2(7);
  /*
  銮峰？杈？？瀵硅薄浣？？？版？

  p_Organization_Id  浜у？缁？？ID
  P_KM_CODE           绉？？浠ｇ？,
  P_GET_TYPE  C 链？？？?JF ？？？？？？？?DF 璐锋？？？？？?Y 链？汤？?
  P_S_YEAR_MONTH    寮？濮？？浠?
  P_E_YEAR_MONTH   缁？？链？唤,
  p_Object_Type    瀵硅薄绫诲？:？？l_a_curr_account琛？？？？？涓昏？？?Crm_EntId？？ntOrgId
  P_Object_Id      瀵硅薄ID
  */

Begin

  --Sqlwhere := '';
  --？？？瀵瑰？链？唤镄？？骞?链？唤
  S_YEAR_MONTH := substr(P_YEAR_MONTH, 0, 4) || '-01';
  E_YEAR_MONTH:=P_YEAR_MONTH;
  --瑙ｆ？绉？？
  select replace(P_KM_CODEs, '\', ''',''') into kmcodes from dual;
  --瑙ｆ？缁？？
  select replace(P_Organization_Ids, '\', ',') into orgids from dual;

  --镙规？？？？？ゆ？？？？？ユ？ definecelltall Tall_Flag 1 gl_account_subject_balances 2 gl_account_subject_balance
  Sqlwhere := 'select Tall_Flag from definecelltall ' ||
              ' where organization_id in (' || orgids || ') and rownum = 1';
  execute immediate sqlwhere
    into intflag;

  --C 链？？ JF ？？？？？？？?DF璐锋？？？？？?Y链？汤
  if P_GET_TYPE = 'JF' then
    fieldname := 'gsb.amount_this_debit';
  elsif P_GET_TYPE = 'DF' then
    fieldname := 'gsb.amount_this_credit ';
  elsif P_GET_TYPE = 'Y' then
    fieldname := 'gsb.amount_end ';
  elsif P_GET_TYPE = 'JD' then
    fieldname := 'decode(gsb.km_property,1, gsb.Amount_Debit_f - gsb.Amount_Credit_f,gsb.Amount_Credit_f - gsb.Amount_Debit_f) ';
  end if;

  Sqlwhere := 'select  /*+ Rule */ nvl(sum(' || fieldname || '), 0) amount ' ||
              ' from (Select decode(gas.km_property, 1, gcl.Amount_Debit_f - gcl.Amount_Credit_f, gcl.Amount_Credit_f - gcl.Amount_Debit_f) As amount_this_credit,' ||
              ' decode(gas.km_property, 1, gcl.Amount_Debit_f - gcl.Amount_Credit_f, gcl.Amount_Credit_f - gcl.Amount_Debit_f) amount_this_debit,' ||
              ' 0 amount_first,' || '0 amount_end,gas.km_property, gcl.Amount_Credit_f, gcl.Amount_Debit_f ' ||
              ' From Gl_Credence_Head   Gch,' || 'Gl_Credence_Line   Gcl,' ||
              ' Gl_Account_Subject Gas' ||
              ' Where Gch.Gl_Credence_Head_Id = Gcl.Gl_Credence_Head_Id' ||
              ' And Gcl.Gl_Account_Subject_Id = Gas.Gl_Account_Subject_Id' ||
              ' And Gch.Organization_Id in (' || orgids || ')' ||
              ' And Gch.Year_Month between ''' || S_YEAR_MONTH ||
              ''' and ''' || E_YEAR_MONTH || '''' ||
              ' and Gch.Credence_Type <> 13';
  ---杩？处镙？？
  if (intflag is not null) and (intflag = 2) Then
    Sqlwhere := Sqlwhere || ' and Gch.Tally_Flag = 2 ';
  End If;

  -- 镙哥？瀵硅薄绫诲？:
  If (lower(P_Object_Type) = 'crm_entid') Then
     Sqlwhere := Sqlwhere || ' and Gcl.crm_entid = '||P_Object_Id;
  Elsif (lower(P_Object_Type) = 'entorgid') Then
     Sqlwhere := Sqlwhere || ' and Gcl.entorgid = '||P_Object_Id;
  Elsif (lower(P_Object_Type) = 'customer_id') Then
     Sqlwhere := Sqlwhere || ' and Gcl.customer_id = '||P_Object_Id;
  Elsif (lower(P_Object_Type) = 'vendor_id') Then
     Sqlwhere := Sqlwhere || ' and Gcl.vendor_id = '||P_Object_Id;
  Elsif (lower(P_Object_Type) = 'customer_id') Then
     Sqlwhere := Sqlwhere || ' and Gcl.customer_id = '||P_Object_Id;
  Elsif (lower(P_Object_Type) = 'dept_id') Then
     Sqlwhere := Sqlwhere || ' and Gcl.dept_id = '||P_Object_Id;
  End If;


  Sqlwhere := Sqlwhere ||
              ' And Gcl.Gl_Account_Subject_Id In (select distinct Gl_Account_Subject_Id' ||
              '     from Gl_Account_Subject' ||
              '     start with km_code in (''' || kmcodes || ''')' ||
              '    connect by prior gl_account_subject_id = gl_account_subject_pid)' ||
              ') gsb';

  --Dbms_Output.Put_Line('Sqlwhere:' || Sqlwhere);
  execute immediate sqlwhere
    into Result;

  Return Nvl(Result, 0);

End Db_Obj_Acct_Lj_C;
/

