create Procedure           Create_Ap_Invoice(p_inv_in_bill_head_id Number,
                                              p_Organization_Id      Number,
                                              p_Invoice_Bill_No      Varchar2) Is
  t_Ap_Invoice_Head_Id Number;
  t_Ap_Invoice_Line_Id Number;
  t_Dept_Id            Number;
  t_Customer_Id        Number;
  t_Bank               Varchar2(64);
  t_Bank_No            Varchar2(64);
  t_Invbillno          Varchar2(64);
  t_INVOICE_NO         Varchar2(300);
  t_Base_Currency_Id   Number;
  t_Tax_Rate           Number;
  t_Exch_Rate          Number;
  t_Date_Invbill       Date;
  t_Invoice_Line_No    Number := 0;
  t_amount_goods_f     Number;
  t_amount_tax_f       Number;
  t_amount_bill_f      Number;
  t_Note               Varchar2(500);
  t_created_by         varchar2(45);
  t_last_updated_by    varchar2(45);
  t_crm_entid          Number;
  t_entorgid           Number;
  --入库表明细游标
  -- 系统自动生成的发票，要同入库单
/**
 * Modified By: DingHua 2010.3.26
 * Description: 屏蔽 commit
 */
  Cursor Invoutbillline Is
       Select Sl.Srm_Po_Head_Id,
           Sl.Srm_Po_Line_Id,
           Il.Inv_In_Bill_Head_Id,
           Il.Inv_In_Bill_Line_Id,
           il.item_id,
           Il.Qty_Invbill as Qty_Bill,
           Il.price_bill_notax as Price_Bill_Notax_f,
           Il.Price_Bill,
           round(Il.price_bill_notax*Il.Qty_Invbill,2) as Amount_Bill_Notax_f,
           round(Il.price_bill*Il.Qty_Invbill,2) as Amount_Bill_f,
           round(Il.price_bill*Il.Qty_Invbill,2)-round(Il.price_bill_notax*Il.Qty_Invbill,2) as Tax_Amount
      From inv_in_bill_line Il, srm_po_line Sl
     Where Il.Srm_Po_Head_Id= Sl.Srm_Po_Head_Id(+)
       And Il.Srm_Po_Line_Id = Sl.Srm_Po_Line_Id(+)
       And Il.Inv_In_Bill_Head_Id = p_inv_in_bill_head_id;
Begin
   --查询入库单表头数据
  Select Sq_Ap_Invoice_Head.Nextval,
         Iobh.Dept_Id,
         Iobh.Vendor_Id,
         Iobh.Invbillno,
         iobh.ERP_ORDER_NO,
         Co.Bank,
         Co.Bank_Accno,
         Iobh.Base_Currency_Id,
         Iobh.Tax_Rate,
         Iobh.Exch_Rate,
         Iobh.Invbilldate,
         Iobh.Amount_Total,
       --  Iobh.Amount_Total/(1+Tax_Rate/100),
       --  Iobh.Amount_Total-Iobh.Amount_Total/(1+Tax_Rate/100)
         Iobh.Amount_Total-Iobh.Amount_Total/(1+Tax_Rate/100)*(Tax_Rate/100), -- 货款
         Iobh.Amount_Total/(1+Tax_Rate/100)*(Tax_Rate/100), -- 税款
         Iobh.Note,
         Iobh.Created_By,
         Iobh.Last_Updated_By,
         Iobh.Crm_Entid,
         Iobh.Entorgid
    Into t_Ap_Invoice_Head_Id,
         t_Dept_Id,
         t_Customer_Id,
         t_Invbillno,
         t_INVOICE_NO,
         t_Bank,
         t_Bank_No,
         t_Base_Currency_Id,
         t_Tax_Rate,
         t_Exch_Rate,
         t_Date_Invbill,
         t_amount_bill_f,
         t_amount_goods_f,
         t_amount_tax_f,
         t_Note,
         t_created_by,
         t_last_updated_by,
         t_crm_entid,
         t_entorgid
    From Inv_In_Bill_Head Iobh, Vendor_Org Co
   Where Iobh.Vendor_Id = Co.Vendor_Id(+)
     And Co.Organization_Id (+)= p_Organization_Id
     and rownum = 1
     And Iobh.Inv_In_Bill_Head_Id = p_inv_in_bill_head_id;
    --插入表头
  Insert Into Ap_Invoice_Head
    (Organization_Id,
     Ap_Invoice_Head_Id,
     Ordinal_No,
     refer_no,
     INVOICE_NO,
     Invoicet_Property,
     Bill_Type,
     Is_Apcancel_Conf_Flag,
     Is_Conf_Flag,
     Dept_Id,
     Vendor_Id,
     VENDOR_ID_RELATION,
     amount_bill_f,
     amount_goods_f,
     amount_tax_f,
     Base_Currency_Id,
     Tax_Rate,
     Exch_Rate,
     Date_Invoice,
     Date_Bill,
     is_credence,
     Year_Month,
     stat,
     wfid,
     WFFLAG,
     PROCID,
     WFRIGHT,
     IS_SYSTEM_GENRTATE,
     note,
     created_by,
     last_updated_by,
     crm_entid,
     entorgid,
     Sourcebilltype,
     sourcebillid)
  Values
    (p_Organization_Id,
     t_Ap_Invoice_Head_Id,
     p_Invoice_Bill_No,
     t_Invbillno,
     t_INVOICE_NO,
     3,
     1,
     2,
     2,
     t_Dept_Id,
     t_Customer_Id,
     t_Customer_Id,
     t_amount_bill_f,
     t_amount_goods_f,
     t_amount_tax_f,
     t_Base_Currency_Id,
     t_Tax_Rate,
     t_Exch_Rate,
     t_Date_Invbill,
     t_Date_Invbill,
     1,
     To_Char(t_Date_Invbill, 'YYYY-MM'),
     5,0,0,0,0,2,t_Note,
     t_created_by,
     t_last_updated_by,
     t_crm_entid,
     t_entorgid,
     1,
     p_inv_in_bill_head_id);
--  Commit;

 --循环插入明细
  For Rec In Invoutbillline Loop
    Select Sq_Ap_Invoice_Line.Nextval Into t_Ap_Invoice_Line_Id From Dual;
    t_Invoice_Line_No := t_Invoice_Line_No + 1;

    Insert Into Ap_Invoice_Line
      (Ap_Invoice_Line_Id,
       Ap_Invoice_Head_Id,
      -- Invoice_Line_No,
     --  Srm_Po_Head_Id,
   --    Srm_Po_Line_Id,
       Inv_In_Bill_Head_Id,
       Inv_In_Bill_Line_Id,
       Item_Id,
       QTY_MATCH,
       PRICE_NOTAX_FACT,
       price_n,
       Amount_Matching,
       amount_notax_fact,
       amount_nprice,
       price_fact,
       amount_fact,
       Tax_Amount,
       Is_Discount)
    Values
      (t_Ap_Invoice_Line_Id,
       t_Ap_Invoice_Head_Id,
   --    t_Invoice_Line_No,
     --  Rec.Srm_Po_Head_Id,
    --   Rec.Srm_Po_Line_Id,
       Rec.Inv_In_Bill_Head_Id,
       Rec.Inv_In_Bill_Line_Id,
       Rec.Item_Id,
       Rec.Qty_Bill,
       Rec.Price_Bill_Notax_f,
       Rec.Price_Bill,
       Rec.Amount_Bill_Notax_f,
       Rec.Amount_Bill_Notax_f,
       Rec.Amount_Bill_Notax_f,
       rec.price_bill,
       rec.amount_bill_f,
       rec.tax_amount,
       1);
    --更新入库
    Update inv_in_bill_line Iobl
       Set
       --Iobl.Qty_Cancel_Invoice         = Iobl.Qty_Bill,
           Iobl.QTY_MATCH_TOTAL       = Iobl.QTY_INVBILL,
           Iobl.AMOUNT_NOTAX_F_CANCEL = Iobl.PRICEC_BILL_NOTAX_F
     Where Iobl.INV_IN_BILL_LINE_ID = Rec.Inv_In_Bill_Line_Id;

  End Loop;
  -- Commit;

  --更新入库表头
  Update inv_in_bill_head Ih
     set Ih.Amount_Total_Notax_f_Cancel=Ih.AMOUNT_TOTAL_NOTAX_F,
         Ih.Iscredence=2,
         ih.is_send = 2,
         ih.attribute1 =p_Invoice_Bill_No
   where ih.inv_in_bill_head_id=p_inv_in_bill_head_id;
  -- Commit;

/*Exception
  When Others Then
    Rollback;
    Raise_Application_Error(-20001, Sqlerrm);*/

End Create_Ap_Invoice;
/

