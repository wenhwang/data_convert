create view VIEW_INVCURRENT as
Select Organization_Id,
       Item_Class_Name,
       Item_Code,
       Item_Name,
       Sum(Qty_Onhand) Qty_Onhand,
       Sum(Mcqty) Mcqty
  From (Select Ici.Organization_Id,
               Ic.Item_Class_Name,
               i.Item_Code,
               i.Item_Name,
               Sum(Ici.Qty_Onhand) Qty_Onhand,
               0 Mcqty
          From Inv_Current_Inv Ici,
               Item            i,
               Item_Class      Ic,
               Item_Org        Io,
               Warehouse       w
         Where Ici.Organization_Id = Io.Organization_Id
           And Ici.Item_Id = i.Item_Id
           And i.Item_Id = Io.Item_Id
           And Ic.Item_Class_Id (+)= Io.Item_Class2
           And Ici.Organization_Id = w.Organization_Id(+)
           And ici.Warehouse_Id=w.Warehouse_Id(+)
           And w.Warehouse_Property <> 4
         Group By Ici.Organization_Id,
                  Ic.Item_Class_Name,
                  i.Item_Code,
                  i.Item_Name
        Union
        Select Ici.Organization_Id,
               Ic.Item_Class_Name,
               i.Item_Code,
               i.Item_Name,
               0 Qty_Onhand,
               Sum(Ici.Qty_Onhand) Mcqty
          From Inv_Current_Inv Ici,
               Item            i,
               Item_Class      Ic,
               Item_Org        Io,
               Warehouse       w
         Where Ici.Organization_Id = Io.Organization_Id
           And Ici.Item_Id = i.Item_Id
           And i.Item_Id = Io.Item_Id
           And Ic.Item_Class_Id (+)= Io.Item_Class2
           And Ici.Organization_Id = w.Organization_Id(+)
           And w.Warehouse_Property = 4
           And ici.Warehouse_Id=w.Warehouse_Id(+)
         Group By Ici.Organization_Id,
                  Ic.Item_Class_Name,
                  i.Item_Code,
                  i.Item_Name,
                  w.Warehouse_Property)
 Group By Organization_Id, Item_Class_Name, Item_Code, Item_Name
/

