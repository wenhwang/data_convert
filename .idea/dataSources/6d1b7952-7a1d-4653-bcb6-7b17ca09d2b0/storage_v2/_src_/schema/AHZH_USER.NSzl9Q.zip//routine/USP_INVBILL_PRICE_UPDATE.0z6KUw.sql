create Procedure           Usp_Invbill_Price_Update(p_Org_Id Integer,
                                                     p_Yr_Mth Varchar2) Is
  /**
  * Author: DingHua
  * Written Date:2009.06.23
  * Description: 1.更新所有的出库单单价和金额为0；
  *              2.更新不参与成本核算的入库单为0;
  *              3.更新参与成本核算的出库单和委托代销出库单为结存价；
  *              4.更新生产入库(商贸企业不能用)和委托代销入库单为结存价；
  *              5.当参数设定用结存价来确定更新 调拨出入库单的价格和金额；
  *              6.用明细表的金额汇总更新主体表的金额
  */
  Type Ridarray Is Table Of Rowid Index By Binary_Integer;
  Type Itmarray Is Table Of Integer Index By Binary_Integer;
  Type Prcarray Is Table Of Number Index By Binary_Integer;
  Type Outlineidarray Is Table Of Integer Index By Binary_Integer;
  Type Inlineidarray Is Table Of Integer Index By Binary_Integer;
  Type Prc2array Is Table Of Number Index By Binary_Integer;

  v_Rowid      Ridarray;
  v_Item_Id    Itmarray;
  v_Price      Prcarray;
  v_Outline_Id Outlineidarray;
  v_Inline_Id  Inlineidarray;
  v_Price2     Prc2array;

  v_Invupdate Integer := 0;

  --     p_RowCount number:=0;  -- Total need to update rows count
  --     n_RowCount number:=0;  -- Yet needed to update rows count
  --     n_ExeCount number:=10000;  -- Every Times need to update rows count
Begin
  ---- Modified By: DingHua 2010.5.4
  ---- Description: 取已经结转成本凭证的出库ID
  Insert Into Artmp_Costcredence_Invbill
    (Bill_Type, Bill_Id, Line_Id)
    Select 1 Bill_Type, Ail.Inv_Out_Bill_Head_Id, Ail.Inv_Out_Bill_Line_Id
      From Ar_Invoice_Line Ail, Ar_Invoice_Head Aih
     Where Ail.Ar_Invoice_Head_Id = Aih.Ar_Invoice_Head_Id
       And Aih.Organization_Id = p_Org_Id
       And Aih.Year_Month >= p_Yr_Mth
       And Aih.Gl_Credence_Head_Id_Cb > 0
       And Ail.Inv_Out_Bill_Line_Id > 0;

  ---- 1. 更新所有出库单的单价和金额为0
  Update Inv_Out_Bill_Line Iol
     Set Iol.Price_Bill_f        = 0,
         Iol.Price_Bill_Notax_f  = 0,
         Iol.Price_Bill          = 0,
         Iol.Price_Bill_Notax    = 0,
         Iol.Amount_Bill_f       = 0,
         Iol.Amount_Bill_Notax_f = 0,
         Iol.Amount_Bill         = 0,
         Iol.Amount_Bill_Notax   = 0
   Where Not Exists (Select 'X'
            From Artmp_Costcredence_Invbill
           Where Line_Id = Iol.Inv_Out_Bill_Line_Id)
     And Iol.Inv_Out_Bill_Head_Id In
         (Select Inv_Out_Bill_Head_Id
            From Inv_Out_Bill_Head Ioh
           Where Ioh.Is_Auditing_Wh = 2
             And Nvl(Ioh.Gl_Credence_Head_Id, 0) = 0
             And Ioh.Is_Init_Bill <> 2
             And Ioh.Year_Month = p_Yr_Mth
             And Ioh.Organization_Id = p_Org_Id);
  /*
  Update Inv_Out_Bill_Head Ioh
     Set Ioh.Amount_Total_Notax   = 0,
         Ioh.Amount_Total_Notax_f = 0,
         Ioh.Amount_Total         = 0,
         Ioh.Amount_Total_f       = 0
   Where Ioh.Billtypecode In
         (Select Billtypecode From Inv_Billtype Where Is_Run_Cost = 2)
     And Ioh.Year_Month = p_Yr_Mth
     And Ioh.Organization_Id = p_Org_Id; */

  ---- 2.1 更新所有不参与成本核算的入库单的单价和金额为0 (其他入库除外)
  Update Inv_In_Bill_Line Ibl
     Set Ibl.Price_Bill          = 0,
         Ibl.Price_Bill_Notax    = 0,
         Ibl.Pricec_Bill_f       = 0,
         Ibl.Pricec_Bill_Notax_f = 0,
         Ibl.Amount_Bill_f       = 0,
         Ibl.Amount_Bill_Notax_f = 0,
         Ibl.Amount_Bill         = 0,
         Ibl.Amount_Bill_Notax   = 0
   Where Ibl.Inv_In_Bill_Head_Id In
         (Select Inv_In_Bill_Head_Id
            From Inv_In_Bill_Head Ibh
           Where Ibh.Is_Auditing_Wh = 2
             And Ibh.Is_Init_Bill <> 2
             And Nvl(Ibh.Gl_Credence_Head_Id, 0) = 0
             And Ibh.Billtypecode In
                 (Select Billtypecode From Inv_Billtype Where Is_Run_Cost = 1)
             And Ibh.Billtypecode != '0199'
             And ibh.billtypecode != '0302'
                /*             And ((Ibh.Billtypecode In (Select Billtypecode From Inv_Billtype Where Is_Run_Cost = 1))
                Or (Ibh.Billtypecode = '0199' And Ibh.Billtype2code In (Select Billtype2code From Inv_Billtype2 Where Is_Run_Cost = 1)))*/
             And Ibh.Year_Month = p_Yr_Mth
             And Ibh.Organization_Id = p_Org_Id);

  ---- 2.2 更新所有不参与成本核算的入库单的单价和金额为0 (其他入库)
  Update Inv_In_Bill_Line Ibl
     Set Ibl.Price_Bill          = 0,
         Ibl.Price_Bill_Notax    = 0,
         Ibl.Pricec_Bill_f       = 0,
         Ibl.Pricec_Bill_Notax_f = 0,
         Ibl.Amount_Bill_f       = 0,
         Ibl.Amount_Bill_Notax_f = 0,
         Ibl.Amount_Bill         = 0,
         Ibl.Amount_Bill_Notax   = 0
   Where Ibl.Inv_In_Bill_Head_Id In
         (Select Inv_In_Bill_Head_Id
            From Inv_In_Bill_Head Ibh
           Where Ibh.Is_Auditing_Wh = 2
             And Nvl(Ibh.Gl_Credence_Head_Id, 0) = 0
             And Ibh.Is_Init_Bill <> 2
             And Ibh.Billtypecode = '0199'
             And Ibh.Billtype2code In
                 (Select Billtype2code
                    From Inv_Billtype2
                   Where Is_Run_Cost = 1)
             And Ibh.Year_Month = p_Yr_Mth
             And Ibh.Organization_Id = p_Org_Id);

  ---- 3.1 更新所有参与成本计算的出库单价格为结存价  (其它出库 除外)
  Select Inv_Out_Bill_Line_Id, Nvl(Isp.Price, 0) Price Bulk Collect
    Into v_Outline_Id, v_Price
    From Inv_Out_Bill_Line          Iol,
         Inv_Item_Stk_Price         Isp,
         Artmp_Costcredence_Invbill Cst,
         Inv_Out_Bill_Head          Ioh,
         Inv_Billtype               Ib
   Where Ioh.Inv_Out_Bill_Head_Id = Iol.Inv_Out_Bill_Head_Id
     And Iol.Inv_Out_Bill_Line_Id = Cst.Line_Id(+)
     And Cst.Line_Id Is Null
     And Ioh.Is_Auditing_Wh = 2
     And Ioh.Is_Init_Bill <> 2
     And Isp.Item_Id = Iol.Item_Id
     And Ioh.Billtypecode = Ib.Billtypecode
     And Ioh.Billtypecode <> '0299'
     And Nvl(Ioh.Gl_Credence_Head_Id, 0) = 0
     And Ib.Is_Run_Cost = 2
     And Isp.Year_Month = p_Yr_Mth
     And Isp.Organization_Id = p_Org_Id
     And Ioh.Year_Month = p_Yr_Mth
     And Ioh.Organization_Id = p_Org_Id;

  -- To Update
  Forall i In 1 .. v_Outline_Id.Count
    Update Inv_Out_Bill_Line Iol
       Set Iol.Price_Bill_f        = v_Price(i),
           Iol.Price_Bill_Notax_f  = v_Price(i),
           Iol.Price_Bill          = v_Price(i),
           Iol.Price_Bill_Notax    = v_Price(i),
           Iol.Amount_Bill_f       = Iol.Qty_Bill * v_Price(i),
           Iol.Amount_Bill_Notax_f = Iol.Qty_Bill * v_Price(i),
           Iol.Amount_Bill         = Iol.Qty_Bill * v_Price(i),
           Iol.Amount_Bill_Notax   = Iol.Qty_Bill * v_Price(i)
     Where Iol.Inv_Out_Bill_Line_Id = v_Outline_Id(i);

  ---- 3.2 更新所有参与成本计算的其它出库单和代销单价格为结存价  (其它出库 和 代销单)
  Select Inv_Out_Bill_Line_Id, Nvl(Isp.Price, 0) Price Bulk Collect
    Into v_Outline_Id, v_Price
    From Inv_Out_Bill_Line  Iol,
         Inv_Item_Stk_Price Isp,
         Inv_Out_Bill_Head  Ioh,
         Inv_Billtype2      Ib2
   Where Ioh.Inv_Out_Bill_Head_Id = Iol.Inv_Out_Bill_Head_Id
     And Ioh.Is_Auditing_Wh = 2
     And Isp.Item_Id = Iol.Item_Id
     And Ioh.Is_Init_Bill <> 2
     And Ioh.Billtype2code = Ib2.Billtype2code
     And Ioh.Billtypecode = '0299'
     And Nvl(Ioh.Gl_Credence_Head_Id, 0) = 0
     And (Ib2.Billtype2code = '062' Or Ib2.Is_Run_Cost = 2)
     And Isp.Year_Month = p_Yr_Mth
     And Isp.Organization_Id = p_Org_Id
     And Ioh.Year_Month = p_Yr_Mth
     And Ioh.Organization_Id = p_Org_Id;

  -- To Update
  Forall i In 1 .. v_Outline_Id.Count
    Update Inv_Out_Bill_Line Iol
       Set Iol.Price_Bill_f        = v_Price(i),
           Iol.Price_Bill_Notax_f  = v_Price(i),
           Iol.Price_Bill          = v_Price(i),
           Iol.Price_Bill_Notax    = v_Price(i),
           Iol.Amount_Bill_f       = Iol.Qty_Bill * v_Price(i),
           Iol.Amount_Bill_Notax_f = Iol.Qty_Bill * v_Price(i),
           Iol.Amount_Bill         = Iol.Qty_Bill * v_Price(i),
           Iol.Amount_Bill_Notax   = Iol.Qty_Bill * v_Price(i)
     Where Iol.Inv_Out_Bill_Line_Id = v_Outline_Id(i);

  ----  4.1 更新 生产入库(商贸企业不能用)为结存价；
  Select Iibl.Inv_In_Bill_Line_Id, Nvl(Price, 0) Price Bulk Collect
    Into v_Inline_Id, v_Price2
    From Sc_Pincost Sp, Inv_In_Bill_Line Iibl, Inv_In_Bill_Head Iibh
   Where Iibh.Inv_In_Bill_Head_Id = Iibl.Inv_In_Bill_Head_Id
     And Order_Id = Iibl.Inv_In_Bill_Line_Id
     And Iibh.Is_Auditing_Wh = 2
     And Iibh.Is_Init_Bill <> 2
     And Nvl(Iibh.Gl_Credence_Head_Id, 0) = 0
     And Sp.Year_Month = p_Yr_Mth
     And Sp.Organization_Id = p_Org_Id
     And Iibh.Organization_Id = p_Org_Id
     And Billtypecode In ('0104', '0105')
     And Iibh.Year_Month = p_Yr_Mth;

  -- To execute
  Forall i In 1 .. v_Inline_Id.Count
    Update Inv_In_Bill_Line Iol
       Set Iol.Pricec_Bill_Notax_f = v_Price2(i),
           Iol.Pricec_Bill_f       = v_Price2(i),
           Iol.Price_Bill_Notax    = v_Price2(i),
           Iol.Price_Bill          = v_Price2(i),
           Iol.Amount_Bill         = Iol.Qty_Invbill * v_Price2(i),
           Iol.Amount_Bill_Notax   = Iol.Qty_Invbill * v_Price2(i),
           Iol.Amount_Bill_f       = Iol.Qty_Invbill * v_Price2(i),
           Iol.Amount_Bill_Notax_f = Iol.Qty_Invbill * v_Price2(i)
     Where Iol.Inv_In_Bill_Line_Id = v_Inline_Id(i);

  ----  4.2 更新委托代销的入库单为结存价；
  Select Iibl.Inv_In_Bill_Line_Id, Nvl(Iisp.Price, 0) Price Bulk Collect
    Into v_Inline_Id, v_Price2
    From Inv_Item_Stk_Price Iisp,
         Inv_In_Bill_Line   Iibl,
         Inv_In_Bill_Head   Iibh
   Where Iibh.Inv_In_Bill_Head_Id = Iibl.Inv_In_Bill_Head_Id
     And Iisp.Item_Id = Iibl.Item_Id
     And Iibh.Is_Auditing_Wh = 2
     And Iibh.Is_Init_Bill <> 2
     And Nvl(Iibh.Gl_Credence_Head_Id, 0) = 0
     And Iisp.Year_Month = p_Yr_Mth
     And Iisp.Organization_Id = p_Org_Id
     And Iibh.Organization_Id = p_Org_Id
     And Billtypecode = '0199'
     And Billtype2code = '061'
     And Iibh.Year_Month = p_Yr_Mth;

  -- To execute
  Forall i In 1 .. v_Inline_Id.Count
    Update Inv_In_Bill_Line Iol
       Set Iol.Pricec_Bill_Notax_f = v_Price2(i),
           Iol.Pricec_Bill_f       = v_Price2(i),
           Iol.Price_Bill_Notax    = v_Price2(i),
           Iol.Price_Bill          = v_Price2(i),
           Iol.Amount_Bill         = Iol.Qty_Invbill * v_Price2(i),
           Iol.Amount_Bill_Notax   = Iol.Qty_Invbill * v_Price2(i),
           Iol.Amount_Bill_f       = Iol.Qty_Invbill * v_Price2(i),
           Iol.Amount_Bill_Notax_f = Iol.Qty_Invbill * v_Price2(i)
     Where Iol.Inv_In_Bill_Line_Id = v_Inline_Id(i);

  ---- 更新委外入库耗料单的结存价(1201)
  Select Inv_Out_Bill_Line_Id, Nvl(Isp.Price, 0) Price Bulk Collect
    Into v_Outline_Id, v_Price
    From Inv_Out_Bill_Line  Iol,
         Inv_Item_Stk_Price Isp,
         Inv_Out_Bill_Head  Ioh
   Where Ioh.Inv_Out_Bill_Head_Id = Iol.Inv_Out_Bill_Head_Id
     And Ioh.Is_Auditing_Wh = 2
     And Isp.Item_Id = Iol.Item_Id
     And Ioh.Is_Init_Bill <> 2
     And Ioh.Billtypecode = '1201'
     And Nvl(Ioh.Gl_Credence_Head_Id, 0) = 0
     And Isp.Year_Month = p_Yr_Mth
     And Isp.Organization_Id = p_Org_Id
     And Ioh.Year_Month = p_Yr_Mth
     And Ioh.Organization_Id = p_Org_Id;

  -- To Update
  Forall i In 1 .. v_Outline_Id.Count
    Update Inv_Out_Bill_Line Iol
       Set Iol.Price_Bill_f        = v_Price(i),
           Iol.Price_Bill_Notax_f  = v_Price(i),
           Iol.Price_Bill          = v_Price(i),
           Iol.Price_Bill_Notax    = v_Price(i),
           Iol.Amount_Bill_f       = Iol.Qty_Bill * v_Price(i),
           Iol.Amount_Bill_Notax_f = Iol.Qty_Bill * v_Price(i),
           Iol.Amount_Bill         = Iol.Qty_Bill * v_Price(i),
           Iol.Amount_Bill_Notax   = Iol.Qty_Bill * v_Price(i)
     Where Iol.Inv_Out_Bill_Line_Id = v_Outline_Id(i);

  --更新委外入库明细中的耗料成本金额(0103)
  update inv_in_bill_line iibl
     set iibl.amount_out_material =
         (select nvl(sum(iobl.Amount_Bill_f),0) Amount_Bill_f
            from inv_out_bill_line iobl, inv_out_bill_head iobh
           where iobh.inv_out_bill_head_id = iobl.inv_out_bill_head_id
             and iobh.parentbillid = iibl.inv_in_bill_line_id
             and iobh.billtypecode = '1201'
             and iobh.is_auditing_wh = 2
             and iobh.year_month = p_Yr_Mth
             and iobh.organization_id = p_Org_Id)
   where exists
   (select 1
            from inv_in_bill_head iibh
           where iibh.inv_in_bill_head_id = iibl.inv_in_bill_head_id
             and iibh.billtypecode = '0103'
             and iibh.is_auditing_wh = 2
             And Nvl(iibh.gl_credence_head_id, 0) = 0
             and iibh.year_month = p_Yr_Mth
             and iibh.organization_id = p_Org_Id);

  ---- 5.根据参数设定用结存价来更新 调拨出入库单的价格和金额；
  Select Nvl(Param_Value, 1)
    Into v_Invupdate
    From Sc_Param
   Where Param_Code = 'INV_OTHER_UPDATE_PRICE'
     And Organization_Id = p_Org_Id;

  If v_Invupdate Is Null Then
    v_Invupdate := 0;
  End If;

  If v_Invupdate = 2 Then
    --更新调拨入库单价
    Select Iibl.Inv_In_Bill_Line_Id, Nvl(Iisp.Price, 0) Price Bulk Collect
      Into v_Inline_Id, v_Price2
      From Inv_Item_Stk_Price Iisp,
           Inv_In_Bill_Line   Iibl,
           Inv_In_Bill_Head   Iibh
     Where Iibh.Inv_In_Bill_Head_Id = Iibl.Inv_In_Bill_Head_Id
       And Iisp.Item_Id = Iibl.Item_Id
       And Iibh.Is_Auditing_Wh = 2
       And Iibh.Is_Init_Bill <> 2
       And Nvl(Iibh.Gl_Credence_Head_Id, 0) = 0
       And Iisp.Year_Month = p_Yr_Mth
       And Iisp.Organization_Id = p_Org_Id
       And Iibh.Organization_Id = p_Org_Id
       And Billtypecode In ('0197', '0198')
       And Iibh.Year_Month = p_Yr_Mth;

    -- To execute
    Forall i In 1 .. v_Inline_Id.Count
      Update Inv_In_Bill_Line Iol
         Set Iol.Pricec_Bill_Notax_f = v_Price2(i),
             Iol.Pricec_Bill_f       = v_Price2(i),
             Iol.Price_Bill_Notax    = v_Price2(i),
             Iol.Price_Bill          = v_Price2(i),
             Iol.Amount_Bill         = Iol.Qty_Invbill * v_Price2(i),
             Iol.Amount_Bill_Notax   = Iol.Qty_Invbill * v_Price2(i),
             Iol.Amount_Bill_f       = Iol.Qty_Invbill * v_Price2(i),
             Iol.Amount_Bill_Notax_f = Iol.Qty_Invbill * v_Price2(i)
       Where Iol.Inv_In_Bill_Line_Id = v_Inline_Id(i);

    --更新调拨出库单价
    Select Inv_Out_Bill_Line_Id, Nvl(Isp.Price, 0) Price Bulk Collect
      Into v_Outline_Id, v_Price
      From Inv_Out_Bill_Line  Iol,
           Inv_Item_Stk_Price Isp,
           Inv_Out_Bill_Head  Ioh
     Where Ioh.Inv_Out_Bill_Head_Id = Iol.Inv_Out_Bill_Head_Id
       And Ioh.Is_Auditing_Wh = 2
       And Ioh.Is_Init_Bill <> 2
       And Isp.Item_Id = Iol.Item_Id
       And Ioh.Billtypecode In ('0297', '0298')
       And Nvl(Ioh.Gl_Credence_Head_Id, 0) = 0
       And Isp.Year_Month = p_Yr_Mth
       And Isp.Organization_Id = p_Org_Id
       And Ioh.Year_Month = p_Yr_Mth
       And Ioh.Organization_Id = p_Org_Id;

    -- To Update
    Forall i In 1 .. v_Outline_Id.Count
      Update Inv_Out_Bill_Line Iol
         Set Iol.Price_Bill_f        = v_Price(i),
             Iol.Price_Bill_Notax_f  = v_Price(i),
             Iol.Price_Bill          = v_Price(i),
             Iol.Price_Bill_Notax    = v_Price(i),
             Iol.Amount_Bill_f       = Iol.Qty_Bill * v_Price(i),
             Iol.Amount_Bill_Notax_f = Iol.Qty_Bill * v_Price(i),
             Iol.Amount_Bill         = Iol.Qty_Bill * v_Price(i),
             Iol.Amount_Bill_Notax   = Iol.Qty_Bill * v_Price(i)
       Where Iol.Inv_Out_Bill_Line_Id = v_Outline_Id(i);
  End If;

  ---- 6.用明细表的金额汇总更新主体表的金额
  ---- 6.1 入库单
  Update Inv_In_Bill_Head Iibh
     Set (Iibh.Amount_Total_Notax,
          Iibh.Amount_Total_Notax_f,
          Iibh.Amount_Total,
          Iibh.Amount_Total_f,
          Iibh.Amount_Out_Material) =
         (Select Nvl(Sum(Iibl.Amount_Bill_Notax), 0),
                 Nvl(Sum(Iibl.Amount_Bill_Notax_f), 0),
                 Nvl(Sum(Iibl.Amount_Bill), 0),
                 Nvl(Sum(Iibl.Amount_Bill_f), 0),
                 Nvl(Sum(Iibl.Amount_Out_Material), 0)
            From Inv_In_Bill_Line Iibl
           Where Iibh.Inv_In_Bill_Head_Id = Iibl.Inv_In_Bill_Head_Id)
   Where Iibh.Is_Auditing_Wh = 2
     And Iibh.Is_Init_Bill <> 2
     And Iibh.Organization_Id = p_Org_Id
     And Iibh.Year_Month = p_Yr_Mth
     And Nvl(Iibh.Gl_Credence_Head_Id, 0) = 0;

  ---- 6.2 出库单
  Update Inv_Out_Bill_Head Iobh
     Set (Iobh.Amount_Total_Notax,
          Iobh.Amount_Total_Notax_f,
          Iobh.Amount_Total,
          Iobh.Amount_Total_f) =
         (Select Nvl(Sum(Iobl.Amount_Bill_Notax), 0),
                 Nvl(Sum(Iobl.Amount_Bill_Notax_f), 0),
                 Nvl(Sum(Iobl.Amount_Bill), 0),
                 Nvl(Sum(Iobl.Amount_Bill_f), 0)
            From Inv_Out_Bill_Line Iobl
           Where Iobh.Inv_Out_Bill_Head_Id = Iobl.Inv_Out_Bill_Head_Id)
   Where Iobh.Is_Auditing_Wh = 2
     And Iobh.Is_Init_Bill <> 2
     And Iobh.Organization_Id = p_Org_Id
     And Iobh.Year_Month = p_Yr_Mth
     And Nvl(Iobh.Gl_Credence_Head_Id, 0) = 0;

  -----
  Update Gl_Account_Period Gap
     Set Gap.Attribute5 = 2
   Where Organization_Id = p_Org_Id
     And Gap.Year_Month = p_Yr_Mth;
  --exception
  -- when others then
  --   raise_application_error(-20001,'aaa');
  Commit;
End Usp_Invbill_Price_Update;
/

