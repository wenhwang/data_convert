create view V_INV_BILLTYPE_A3 as
select billtypecode,billtypename,billcolordesc,io from inv_billtype
/

