create view VIEW_CUSTOMER_ITEM_COST as
Select organization_id,
       Year_Month,
       c.Customer_Code,
       c.Customer_Name,
       i.Item_Code,
       i.Item_Name,
       Sum(Qtysum) Qtysum,
       Sum(Amount_tol) Amount_tol,
       Sum(Amount_tol_notax) Amount_tol_notax,
       Sum(Costamount) Costamount,
       Sum(Amount_tol_notax)-Sum(Costamount) As amount_ml
  From (Select Arh.Organization_Id,
               Arh.Customer_Id,
               Arh.Year_Month,
               Arl.Item_Id,
               Sum(Arl.Qty_Bill) Qtysum,
               Sum(arl.amount_bill) Amount_tol,
               Sum(arl.amount_notax) Amount_tol_Notax,
               Sum(Round(Arl.Qty_Bill * Iol.Price_Bill_Notax_f, 2)) Costamount
          From Ar_Invoice_Head   Arh,
               Ar_Invoice_Line   Arl,
               Inv_Out_Bill_Line Iol
         Where Arh.Ar_Invoice_Head_Id = Arl.Ar_Invoice_Head_Id
           And Arl.Inv_Out_Bill_Line_Id = Iol.Inv_Out_Bill_Line_Id
           and arh.is_auditing = 2
           and arh.bill_stat <> 2
         Group By Arh.Organization_Id,
                  Arh.Customer_Id,
                  Arh.Year_Month,
                  Arl.Item_Id
        Union All
        Select Arh.Organization_Id,
               Arh.Customer_Id,
               Arh.Year_Month,
               Arl.Item_Id,
               Sum(Arl.Qty_Bill) Qtysum,
               Sum(arl.amount_bill) Amount_tol,
               Sum(arl.amount_notax) Amount_tol_Notax,
               Sum(Round(Arl.Qty_Bill * Iil.Pricec_Bill_Notax_f, 2)) Costamount
          From Ar_Invoice_Head  Arh,
               Ar_Invoice_Line  Arl,
               Inv_In_Bill_Line Iil
         Where Arh.Ar_Invoice_Head_Id = Arl.Ar_Invoice_Head_Id
           And Arl.Inv_In_Bill_Line_Id = Iil.Inv_In_Bill_Line_Id
           and arh.is_auditing = 2
           and arh.bill_type <= 1
           and arh.bill_stat <> 2
         Group By Arh.Organization_Id,
                  Arh.Customer_Id,
                  Arh.Year_Month,
                  Arl.Item_Id
        Union All
        Select Arh.Organization_Id,
               Arh.Customer_Id,
               Arh.Year_Month,
               Arl.Item_Id,
               0 Qtysum,
               Sum(arl.amount_bill) Amount_tol,
               Sum(arl.amount_notax) Amount_tol_Notax,
               0 Costamount
          From Ar_Invoice_Head  Arh,
               Ar_Invoice_Line  Arl,
               item i,
               ar_param arp
         Where Arh.Ar_Invoice_Head_Id = Arl.Ar_Invoice_Head_Id
           and arh.is_auditing = 2
           and arh.bill_type <= 1
           and arh.bill_stat <> 2
           and arl.item_id = i.item_id
           and i.item_code = arp.param_value
           and arh.organization_id = arp.organization_id
           and arp.param_code = 'DISCOUNT_ITEM_CODE'
         Group By Arh.Organization_Id,
                  Arh.Customer_Id,
                  Arh.Year_Month,
                  Arl.Item_Id
                  ) Bb,
       Customer c,
       Item i
 Where Bb.Customer_Id = c.Customer_Id
   And Bb.Item_Id = i.Item_Id
 Group By organization_id,Year_Month,c.Customer_Code, c.Customer_Name, i.Item_Code, i.Item_Name
/

