create view VIEW_PROJECT_REPORT as
SELECT BASE.DEPT_NAME, --所属部门
       SALES_NAME, --业务员
       (SELECT FUN_GET_USERIDS_BY_ROLEID_DEPT('运营专员', BASE.DEPT_ID)
          FROM DUAL) OPERATER, --售前工程师
       BRAND_SALES, --项目经理
       BUSINESS, --项目会计
       BASE.PROJECT_ID, --项目
       BASE.PROJECT_CODE,
       BASE.PROJECT_NAME
  FROM EPM_PROJECT           PROJECT,
       VIEW_PROJECT_BASE     BASE,
       VIEW_BCS_CUSTOMER     CUSTOMER,
       VIEW_PROJECT_SALESMAN SALESMAN
 WHERE BASE.PROJECT_ID = PROJECT.PROJECT_ID(+)
   AND BASE.PARTNER_ID = CUSTOMER.CUSTOMER_ID(+)
   AND BASE.PROJECT_ID = SALESMAN.PROJECT_ID(+)
   /*********************************************\
   * NAME(名称): VIEW_PROJECT_REPORT
   * PURPOSE(功能说明):  系统报表-项目基本信息
   * AUTHOR(作者): NY
   * CREATE AT(创建时间): 2019-09-06
\*********************************************/
/

