create view VIEW_FIN_PAYING_CROSSWISE as
SELECT "PROJECT_ID",
       "PROJECT_OUT_MATERIAL",
       "PROJECT_OUT_LABOUR",
       "PROJECT_OUT_COST",
       "INVEST_OUT_MATERIAL",
       "INVEST_OUT_LABOUR",
       "INVEST_OUT_COST",
       "OUT_PARTNER_MARGIN_AMOUNT",
       "OUT_PARTNER_SECURITY_AMOUNT",
       "TRANSFER_OUT_AMOUNT",
       "RESTITUTION_BORROWING",
       "COMPANIES_BORROW",
       "OTHER_OUT_AMOUNT",
       "OUTPUT_INVOICE_AMOUNT",
       "OUTPUT_VAT_AMOUNT"
  FROM (SELECT PROJECT_ID, PAYMENT_TYPE_CODE, AMOUNT_CREDIT
          FROM FD_PAYMENT_TYPE,
               (SELECT PROJECT_ID,
                       BUSINESS_TYPE,
                       SUM(AMOUNT_CREDIT) AMOUNT_CREDIT
                  FROM FIN_PAYING_VOUCHER
                 WHERE STAT = 5
                 GROUP BY PROJECT_ID, BUSINESS_TYPE) PAYING
         WHERE FD_PAYMENT_TYPE_ID = PAYING.BUSINESS_TYPE(+)
           AND PAYMENT_IO = 2
        UNION ALL
        SELECT HEAD.PROJECT_ID,
               'F98' PAYMENT_TYPE_CODE,
               SUM(LINE.INVOICE_AMOUNT) AMOUNT_CREDIT
          FROM FD_OUTPUT_INVOICE_LIST LINE, FD_OUTPUT_INVOICE_APPLY HEAD
         WHERE HEAD.OUTPUT_INVOICE_APPLY_ID = LINE.OUTPUT_INVOICE_APPLY_ID
           AND HEAD.STAT = 5
           AND LINE.IS_USABLE = 2
         GROUP BY PROJECT_ID
        UNION ALL
        SELECT HEAD.PROJECT_ID,
               'F99' PAYMENT_TYPE_CODE,
               SUM(LINE.TAX_AMOUNT) AMOUNT_CREDIT
          FROM FD_OUTPUT_INVOICE_LIST LINE, FD_OUTPUT_INVOICE_APPLY HEAD
         WHERE HEAD.OUTPUT_INVOICE_APPLY_ID = LINE.OUTPUT_INVOICE_APPLY_ID
           AND HEAD.STAT = 5
           AND LINE.IS_USABLE = 2
         GROUP BY PROJECT_ID) PIVOT(SUM(AMOUNT_CREDIT) FOR PAYMENT_TYPE_CODE IN (

       'F01' PROJECT_OUT_MATERIAL, 'F02' PROJECT_OUT_LABOUR, 'F03' PROJECT_OUT_COST,

       'F04' INVEST_OUT_MATERIAL, 'F05' INVEST_OUT_LABOUR, 'F06' INVEST_OUT_COST,

       'F07' OUT_PARTNER_MARGIN_AMOUNT, 'F08' OUT_PARTNER_SECURITY_AMOUNT,

       'F09' TRANSFER_OUT_AMOUNT,

       'F10' RESTITUTION_BORROWING, 'F11' COMPANIES_BORROW,

       'F12' OTHER_OUT_AMOUNT,

       'F98' OUTPUT_INVOICE_AMOUNT,

       'F99' OUTPUT_VAT_AMOUNT))

/*********************************************\
  * NAME(名称): VIEW_FIN_PAYING_CROSSWISE
  * PURPOSE(功能说明):  付款合计横向列表
                                    F01 付材料-工程款 PROJECT_OUT_MATERIAL
                                    F02 付劳务-工程款 PROJECT_OUT_LABOUR
                                    F03 付费用-工程款 PROJECT_OUT_COST

                                    F04 付材料-投资款  INVEST_OUT_MATERIAL
                                    F05 付劳务-投资款 INVEST_OUT_LABOUR
                                    F06 付费用-投资款 INVEST_OUT_COST

                                    F07 付投标保证金 OUT_PARTNER_MARGIN_AMOUNT
                                    F08 付履约保证金 OUT_PARTNER_SECURITY_AMOUNT

                                    F09 付往来调拨款  TRANSFER_OUT_AMOUNT
                                    F10 归还公司借款 RESTITUTION_BORROWING

                                    F11 公司借支  COMPANIES_BORROW
                                    F12 付其他款项 OTHER_OUT_AMOUNT

                                    F98 累计开票 OUTPUT_INVOICE_AMOUNT,

                                    F99 销项票税额 OUTPUT_VAT_AMOUNT

  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2017-12-18
  \*********************************************/
/

