create Function           Fn_Hr_Round(leftNum varchar2,
                              rightNum Varchar2)
 Return varchar2 Is
  v_sql Varchar2(3000);

Begin

  v_sql := ' round('||leftNum||','||rightNum||') ';

  return v_sql;
End Fn_Hr_Round;
/

