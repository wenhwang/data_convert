create view V_BBS as
select "FDRNAME","BBSID","BBSTYPE","SUBJECT","CONTENT","MANAGER","DUEDATE","CREATOR","CREATETIME","UPDATOR","UPDATETIME"
  from (select fdr.fdrname,
               bbsid,
               bbstype,
               subject,
               content,
               manager,
               duedate,
               creator,
               substr(createtime,1,10) createtime,
               updator,
               updatetime
          from cpcbbs,
               (select cpcfdrref.refid, cpcfdr.fdrname
                  from cpcfdrref, cpcfdr
                 where cpcfdrref.fdrid = cpcfdr.fdrid
                   and reftype = 24) fdr
         where cpcbbs.bbsid = fdr.refid)
/

