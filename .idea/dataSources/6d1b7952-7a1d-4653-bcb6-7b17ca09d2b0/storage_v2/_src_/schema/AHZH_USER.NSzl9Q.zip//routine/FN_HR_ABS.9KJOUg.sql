create Function           Fn_Hr_Abs(Num Varchar2)
 Return varchar2 Is
  v_sql Varchar2(3000);

Begin

  v_sql := ' abs('||Num||') ';

  return v_sql;
End Fn_Hr_Abs;
/

