create view VIEW_PROJECT_BID_OPEN as
SELECT PROJECT_ID, --项目ID
       BID_OPEN_PRIMARY, --开标授权人
       BID_OPEN_ATTENDEE, --开标出场人（多选）
       BID_OPEN_METHOD, --开标方式(词汇值)
       BID_OPEN_TIME, --开标时间
       BID_OPEN_ADDRESS, --开标地点
       BID_OPEN_MAN --开标人
  FROM EPM_PROJECT_BID_OPEN

/*********************************************\
  * NAME(名称): VIEW_BASE_PROJECT
  * PURPOSE(功能说明):  现场开标
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2019-07-18
  \*********************************************/
/

