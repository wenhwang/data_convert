create view VIEW_RECEIPTVOUCHERDETAIL as
SELECT RECEIPT_VOUCHER."ORDINAL_NO",
       RECEIPT_VOUCHER."DATE_FUND",
       RECEIPT_VOUCHER."PAYMENT_TYPE_NAME",
       RECEIPT_VOUCHER."RECEIVER_NAME",
       RECEIPT_VOUCHER."BUSINESS_TYPE_NAME",
       RECEIPT_VOUCHER."FUND_ACCOUNT_NAME",
       RECEIPT_VOUCHER."PROJECT_ID",
       RECEIPT_VOUCHER."RECEIPT_AMOUNT",
       PROJECT_CODE,
       PROJECT_NAME
  FROM (SELECT ORDINAL_NO,
               DATE_FUND,
               PAYMENT_TYPE_NAME,
               RECEIVER_NAME,
               BUSINESS_TYPE_NAME,
               FUND_ACCOUNT_NAME,
               PROJECT_ID,
               NVL(SUM(RECEIPT_AMOUNT), 0) RECEIPT_AMOUNT
          FROM (SELECT HEAD.ORDINAL_NO,
                       HEAD.DATE_FUND,
                       DECODE(HEAD.PAYMENT_TYPE,
                              1,
                              '供应商',
                              2,
                              '业主/招标机构',
                              3,
                              '合伙人',
                              4,
                              '潜在客户',
                              5,
                              '个人') PAYMENT_TYPE_NAME,
                       RECEIVER_NAME,
                       FD_PAYMENT_TYPE.PAYMENT_TYPE_NAME BUSINESS_TYPE_NAME,
                       LINE.PROJECT_ID,
                       FUND_ACCOUNT_NAME,
                       (LINE.AMOUNT * LINE.PLUS_MINUS) RECEIPT_AMOUNT
                  FROM FIN_RECEIPT_VOUCHER_LINE LINE,
                       FIN_RECEIPT_VOUCHER HEAD,
                       FD_FUND_ACCOUNT,
                       FD_PAYMENT_TYPE
                 WHERE LINE.FIN_RECEIPT_VOUCHER_ID =
                       HEAD.FIN_RECEIPT_VOUCHER_ID
                   AND HEAD.FD_FUND_ACCOUNT_ID =
                       FD_FUND_ACCOUNT.FD_FUND_ACCOUNT_ID(+)
                   AND HEAD.BUSINESS_TYPE =
                       FD_PAYMENT_TYPE.FD_PAYMENT_TYPE_ID(+)
                   AND HEAD.STAT = 5)
         GROUP BY ORDINAL_NO,
                  DATE_FUND,
                  PAYMENT_TYPE_NAME,
                  RECEIVER_NAME,
                  BUSINESS_TYPE_NAME,
                  FUND_ACCOUNT_NAME,
                  PROJECT_ID) RECEIPT_VOUCHER,
       EPM_PROJECT
 WHERE RECEIPT_VOUCHER.PROJECT_ID = EPM_PROJECT.PROJECT_ID(+)
   AND 1 = 1
/*********************************************\
  * NAME(名称): VIEW_PURCONTRACTDETAIL
  * PURPOSE(功能说明):  钉钉智能报表-项目回款明细
  * AUTHOR(作者): NY
  * CREATE AT(创建时间): 2018-11-14
  \*********************************************/
/

