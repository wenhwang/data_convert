create procedure           pro_update_sequence is
  v_sql varchar2(1000) := '';
  n     number := 0;
begin
  --镆ヨ？褰揿？搴？？？?
  select SQ_SRM_PO_HAIER_NO_ID.Nextval into n from dual;
  --灏？？煎？璐？？涓？？
  n     := - n;
  --缁椤？？？？？？？？煎？搴?
  v_sql := 'alter sequence SQ_SRM_PO_HAIER_NO_ID INCREMENT BY' || n;
  execute immediate v_sql;
  --姹？？搴？？
  select SQ_SRM_PO_HAIER_NO_ID.Nextval into n from dual;
  --阅？？璧嫔？煎？？？？搴?
  v_sql := 'alter sequence SQ_SRM_PO_HAIER_NO_ID INCREMENT BY 1';
  execute immediate v_sql;
end pro_update_sequence;
/

