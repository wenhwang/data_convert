create FUNCTION           str_mult(p_str IN VARCHAR2) RETURN NUMBER AS
  l_str  VARCHAR2(1000) := p_str || '*';
  l_n    NUMBER;
  l_data NUMBER := 1;
BEGIN
  IF instr(l_str, '*') = 1 THEN
    l_str := SUBSTR(l_str, 2);
  END IF;
  LOOP
    l_n := instr(l_str, '*');
    EXIT WHEN(NVL(l_n, 0) = 0);
    l_data := l_data * TO_NUMBER(SUBSTR(l_str, 1, l_n - 1));
    l_str  := SUBSTR(l_str, l_n + 1);
  END LOOP;
  RETURN l_data;
END;
/

