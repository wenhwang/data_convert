create view VIEW_FEEBXDETAIL as
SELECT "BX_NO","CYEAR","CMONTH","PROJECT_CODE","PROJECT_NAME","BUD_TYPE_NAME","BUSINESS_TYPE_NAME","FEE_NAME","RECEIVER_TYPE_NAME","USEOBJECT_NAME","ORDINAL_NO","DATE_FUND","BALANCE_TYPE_NAME","FUND_ACCOUNT_NAME","APPLY_BX_AMT","CX_AMT","ALLOW_BX_AMT","AMOUNT_CREDIT"
  FROM (SELECT HEAD.BX_NO,
               CYEAR,
               CMONTH,
               PROJECT_CODE,
               PROJECT_NAME,
               BUD_TYPE_NAME,
               PAYMENT_TYPE_NAME BUSINESS_TYPE_NAME,
               LINE.FEE_NAME,
               DECODE(LINE.RECEIVER_TYPE,
                      1,
                      '供应商',
                      2,
                      '业主/招标机构',
                      3,
                      '合伙人',
                      4,
                      '潜在客户',
                      5,
                      '个人') RECEIVER_TYPE_NAME,
               LINE.USEOBJECT_NAME,
               ORDINAL_NO,
               DATE_FUND,
               BALANCE_TYPE_NAME,
               FUND_ACCOUNT_NAME,
               APPLY_BX_AMT,
               CX_AMT,
               ALLOW_BX_AMT,
               AMOUNT_CREDIT
          FROM FIN_FEE_BX_HEADER HEAD,
               FIN_FEE_BX_LINE LINE,
               (SELECT ORDINAL_NO,
                       BILL_ID,
                       BILL_NO,
                       HEAD.DATE_FUND,
                       BALANCE_TYPE_NAME,
                       FUND_ACCOUNT_NAME,
                       AMOUNT_CREDIT
                  FROM FIN_PAYING_VOUCHER HEAD,
                       FD_FUND_ACCOUNT,
                       BASE_BALANCE_TYPE
                 WHERE HEAD.FD_FUND_ACCOUNT_ID =
                       FD_FUND_ACCOUNT.FD_FUND_ACCOUNT_ID(+)
                   AND HEAD.BASE_BALANCE_TYPE_ID =
                       BASE_BALANCE_TYPE.BASE_BALANCE_TYPE_ID(+)
                   AND HEAD.SYSCREATE_TYPE = 4
                   AND HEAD.STAT = 5) PAYING,
               EPM_PROJECT,
               FD_PAYMENT_TYPE
         WHERE HEAD.BX_ID = LINE.BX_ID
           AND HEAD.BUSINESS_TYPE = FD_PAYMENT_TYPE.FD_PAYMENT_TYPE_ID(+)
           AND LINE.BX_LINE_ID = PAYING.BILL_ID(+)
           AND HEAD.PROJECT_ID = EPM_PROJECT.PROJECT_ID(+)
           AND HEAD.STAT = 5)
 WHERE 1 = 1
/

